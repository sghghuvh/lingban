extends RefCounted
# 桌宠物语：界面工具（主题、按钮、输入框、手绘图标）。

const BG := Color("#14162a")
const PANEL := Color("#1d2036")
const CARD := Color("#282c4a")
const CARD2 := Color("#333858")
const FIELD := Color("#171a2e")
const TXT := Color("#f2efff")
const MUTED := Color("#a6a3c8")
const LINE := Color("#3b4066")
const GOOD := Color("#62d39a")
const WARN := Color("#f2b45a")
const BAD := Color("#ef6b78")

static var accent := Color("#8f7cf6")
static var font: Font
static var bold: Font

static func sb(col: Color, r := 18, pad := 12, bw := 0, bcol := Color(0, 0, 0, 0), padv := -1) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(r)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad if padv < 0 else padv
	s.content_margin_bottom = pad if padv < 0 else padv
	if bw > 0:
		s.set_border_width_all(bw)
		s.border_color = bcol
	s.anti_aliasing = true
	s.corner_detail = 6
	return s

static func readable_accent(c: Color) -> Color:
	var a := c
	if a.get_luminance() > 0.72:
		a = a.darkened(0.35)
	elif a.get_luminance() < 0.22:
		a = a.lightened(0.35)
	if a.s < 0.15:
		a = Color("#8f7cf6").lerp(a, 0.4)
	return a

static func make_theme() -> Theme:
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 26
	var e := StyleBoxEmpty.new()
	# 按钮
	th.set_stylebox("normal", "Button", sb(CARD, 18, 16, 0, Color(), 10))
	th.set_stylebox("hover", "Button", sb(CARD2, 18, 16, 0, Color(), 10))
	th.set_stylebox("pressed", "Button", sb(accent.darkened(0.25), 18, 16, 0, Color(), 10))
	th.set_stylebox("disabled", "Button", sb(Color(CARD, 0.5), 18, 16, 0, Color(), 10))
	th.set_stylebox("focus", "Button", e)
	th.set_color("font_color", "Button", TXT)
	th.set_color("font_hover_color", "Button", TXT)
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	th.set_color("font_focus_color", "Button", TXT)
	th.set_color("font_disabled_color", "Button", MUTED)
	# 输入框
	for cls in ["LineEdit", "TextEdit"]:
		th.set_stylebox("normal", cls, sb(FIELD, 16, 14, 2, LINE))
		th.set_stylebox("focus", cls, sb(FIELD, 16, 14, 2, accent))
		th.set_stylebox("read_only", cls, sb(FIELD, 16, 14, 2, LINE))
		th.set_color("font_color", cls, TXT)
		th.set_color("font_placeholder_color", cls, MUTED)
		th.set_color("caret_color", cls, accent)
		th.set_color("selection_color", cls, Color(accent, 0.4))
	th.set_stylebox("panel", "PanelContainer", sb(PANEL, 24, 18))
	th.set_stylebox("panel", "Panel", sb(PANEL, 24, 0))
	th.set_color("font_color", "Label", TXT)
	th.set_stylebox("panel", "ScrollContainer", e)
	th.set_stylebox("scroll", "VScrollBar", sb(Color(0, 0, 0, 0), 4, 2))
	th.set_stylebox("grabber", "VScrollBar", sb(LINE, 5, 3))
	th.set_stylebox("grabber_highlight", "VScrollBar", sb(MUTED, 5, 3))
	th.set_stylebox("grabber_pressed", "VScrollBar", sb(accent, 5, 3))
	th.set_stylebox("scroll", "HScrollBar", sb(Color(0, 0, 0, 0), 4, 2))
	th.set_stylebox("grabber", "HScrollBar", sb(Color(LINE, 0.6), 4, 2))
	# 下拉
	th.set_stylebox("normal", "OptionButton", sb(FIELD, 16, 14, 2, LINE, 10))
	th.set_stylebox("hover", "OptionButton", sb(FIELD, 16, 14, 2, accent, 10))
	th.set_stylebox("pressed", "OptionButton", sb(FIELD, 16, 14, 2, accent, 10))
	th.set_stylebox("focus", "OptionButton", e)
	th.set_color("font_color", "OptionButton", TXT)
	th.set_stylebox("panel", "PopupMenu", sb(CARD, 14, 10, 2, LINE))
	th.set_stylebox("hover", "PopupMenu", sb(CARD2, 10, 8))
	th.set_color("font_color", "PopupMenu", TXT)
	th.set_color("font_hover_color", "PopupMenu", TXT)
	th.set_font_size("font_size", "PopupMenu", 26)
	th.set_constant("v_separation", "PopupMenu", 14)
	th.set_color("font_color", "CheckButton", TXT)
	th.set_color("font_hover_color", "CheckButton", TXT)
	th.set_color("font_pressed_color", "CheckButton", TXT)
	th.set_stylebox("focus", "CheckButton", e)
	th.set_icon("checked", "CheckButton", switch_tex(true))
	th.set_icon("unchecked", "CheckButton", switch_tex(false))
	th.set_icon("checked_disabled", "CheckButton", switch_tex(true))
	th.set_icon("unchecked_disabled", "CheckButton", switch_tex(false))
	th.set_stylebox("slider", "HSlider", sb(LINE, 4, 0, 0, Color(), 3))
	th.set_stylebox("grabber_area", "HSlider", sb(accent, 4, 0, 0, Color(), 3))
	th.set_stylebox("grabber_area_highlight", "HSlider", sb(accent.lightened(0.2), 4, 0, 0, Color(), 3))
	th.set_stylebox("panel", "TooltipPanel", sb(CARD2, 10, 10))
	th.set_color("font_color", "TooltipLabel", TXT)
	return th

# 开关图标（药丸形）
static func switch_tex(on: bool) -> ImageTexture:
	var w := 84
	var h := 46
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var bg: Color = accent if on else Color("#4a4f75")
	var r := h * 0.5 - 1.0
	var kx := w - h * 0.5 if on else h * 0.5
	for y in h:
		for x in w:
			var cx := clampf(float(x), r + 1.0, float(w) - r - 1.0)
			var d := Vector2(float(x) + 0.5, float(y) + 0.5).distance_to(Vector2(cx, h * 0.5))
			var a := clampf(r - d + 0.5, 0.0, 1.0)
			var col := Color(bg, a)
			var dk := Vector2(float(x) + 0.5, float(y) + 0.5).distance_to(Vector2(kx, h * 0.5))
			var ka := clampf((r - 5.0) - dk + 0.5, 0.0, 1.0)
			if ka > 0.0:
				col = col.lerp(Color(1, 1, 1, 1), ka)
				col.a = maxf(a, ka)
			img.set_pixel(x, y, col)
	return ImageTexture.create_from_image(img)

# ---------------------------------------------------------------- 小部件
static func label(t: String, size := 26, col := TXT, wrap := false, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = align
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

static func title(t: String, size := 36, col := TXT) -> Label:
	var l := label(t, size, col)
	if bold != null:
		l.add_theme_font_override("font", bold)
	return l

static func btn(t: String, cb: Callable, kind := "normal", size := 26) -> Button:
	var b := Button.new()
	b.text = t
	b.add_theme_font_size_override("font_size", size)
	b.focus_mode = Control.FOCUS_NONE
	match kind:
		"primary":
			b.add_theme_stylebox_override("normal", sb(accent, 20, 22, 0, Color(), 12))
			b.add_theme_stylebox_override("hover", sb(accent.lightened(0.1), 20, 22, 0, Color(), 12))
			b.add_theme_stylebox_override("pressed", sb(accent.darkened(0.2), 20, 22, 0, Color(), 12))
			b.add_theme_stylebox_override("disabled", sb(Color(accent, 0.4), 20, 22, 0, Color(), 12))
			b.add_theme_color_override("font_color", Color.WHITE)
			if bold != null:
				b.add_theme_font_override("font", bold)
		"ghost":
			b.add_theme_stylebox_override("normal", sb(Color(0, 0, 0, 0), 18, 16, 2, LINE, 10))
			b.add_theme_stylebox_override("hover", sb(Color(1, 1, 1, 0.05), 18, 16, 2, MUTED, 10))
			b.add_theme_stylebox_override("pressed", sb(Color(1, 1, 1, 0.1), 18, 16, 2, accent, 10))
		"danger":
			b.add_theme_stylebox_override("normal", sb(Color(BAD, 0.18), 18, 16, 2, Color(BAD, 0.6), 10))
			b.add_theme_stylebox_override("hover", sb(Color(BAD, 0.3), 18, 16, 2, BAD, 10))
			b.add_theme_stylebox_override("pressed", sb(Color(BAD, 0.45), 18, 16, 2, BAD, 10))
			b.add_theme_color_override("font_color", Color("#ffd5da"))
		"chip":
			b.add_theme_stylebox_override("normal", sb(Color(CARD2, 0.9), 22, 18, 0, Color(), 8))
			b.add_theme_stylebox_override("hover", sb(CARD2.lightened(0.08), 22, 18, 0, Color(), 8))
			b.add_theme_stylebox_override("pressed", sb(accent.darkened(0.2), 22, 18, 0, Color(), 8))
			b.add_theme_font_size_override("font_size", 23)
		"tab_on":
			b.add_theme_stylebox_override("normal", sb(accent, 16, 14, 0, Color(), 8))
			b.add_theme_stylebox_override("hover", sb(accent, 16, 14, 0, Color(), 8))
			b.add_theme_stylebox_override("pressed", sb(accent, 16, 14, 0, Color(), 8))
			b.add_theme_color_override("font_color", Color.WHITE)
		"tab_off":
			b.add_theme_stylebox_override("normal", sb(FIELD, 16, 14, 0, Color(), 8))
			b.add_theme_stylebox_override("hover", sb(CARD, 16, 14, 0, Color(), 8))
			b.add_theme_stylebox_override("pressed", sb(CARD2, 16, 14, 0, Color(), 8))
			b.add_theme_color_override("font_color", MUTED)
	if cb.is_valid():
		b.pressed.connect(cb)
	return b

static func icon_btn(icon: String, cb: Callable, sz := 64, kind := "normal") -> Button:
	var b := IconBtn.new()
	b.icon_kind = icon
	b.custom_minimum_size = Vector2(sz, sz)
	b.focus_mode = Control.FOCUS_NONE
	var r := int(sz / 2)
	match kind:
		"primary":
			b.add_theme_stylebox_override("normal", sb(accent, r, 0))
			b.add_theme_stylebox_override("hover", sb(accent.lightened(0.1), r, 0))
			b.add_theme_stylebox_override("pressed", sb(accent.darkened(0.2), r, 0))
			b.fg = Color.WHITE
		"flat":
			b.add_theme_stylebox_override("normal", sb(Color(0, 0, 0, 0), r, 0))
			b.add_theme_stylebox_override("hover", sb(Color(1, 1, 1, 0.08), r, 0))
			b.add_theme_stylebox_override("pressed", sb(Color(1, 1, 1, 0.15), r, 0))
		"danger":
			b.add_theme_stylebox_override("normal", sb(BAD, r, 0))
			b.add_theme_stylebox_override("hover", sb(BAD.lightened(0.1), r, 0))
			b.add_theme_stylebox_override("pressed", sb(BAD.darkened(0.2), r, 0))
			b.fg = Color.WHITE
		_:
			b.add_theme_stylebox_override("normal", sb(CARD, r, 0))
			b.add_theme_stylebox_override("hover", sb(CARD2, r, 0))
			b.add_theme_stylebox_override("pressed", sb(accent.darkened(0.25), r, 0))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	if cb.is_valid():
		b.pressed.connect(cb)
	return b

static func hb(sep := 12) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h

static func vb(sep := 12) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v

static func panel(col := PANEL, r := 24, pad := 18) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", sb(col, r, pad))
	return p

static func margin(n: Control, l: int, t: int, r: int, b: int) -> MarginContainer:
	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", l)
	m.add_theme_constant_override("margin_top", t)
	m.add_theme_constant_override("margin_right", r)
	m.add_theme_constant_override("margin_bottom", b)
	if n != null:
		m.add_child(n)
	return m

static func le(ph: String, txt := "", secret := false) -> LineEdit:
	var l := LineEdit.new()
	l.placeholder_text = ph
	l.text = txt
	l.secret = secret
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size.y = 64
	l.add_theme_font_size_override("font_size", 25)
	return l

static func te(ph: String, txt := "", h := 140) -> TextEdit:
	var t := TextEdit.new()
	t.placeholder_text = ph
	t.text = txt
	t.custom_minimum_size = Vector2(0, h)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	t.add_theme_font_size_override("font_size", 25)
	return t

static func gap(h := 8, w := 0) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(w, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c

static func grow(n: Control) -> Control:
	n.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return n

static func opt(items: Array, sel: int, cb: Callable) -> OptionButton:
	var o := OptionButton.new()
	for it in items:
		o.add_item(String(it))
	if sel >= 0 and sel < items.size():
		o.select(sel)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	o.custom_minimum_size.y = 62
	o.focus_mode = Control.FOCUS_NONE
	o.add_theme_font_size_override("font_size", 25)
	o.item_selected.connect(cb)
	return o

static func tog(t: String, on: bool, cb: Callable) -> HBoxContainer:
	var h := hb(10)
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var l := label(t, 24, TXT, true)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(l)
	var c := CheckButton.new()
	c.button_pressed = on
	c.focus_mode = Control.FOCUS_NONE
	c.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var e := StyleBoxEmpty.new()
	for st in ["normal", "hover", "pressed", "hover_pressed", "focus", "disabled"]:
		c.add_theme_stylebox_override(st, e)
	c.toggled.connect(cb)
	h.add_child(c)
	return h

static func sld(minv: float, maxv: float, step: float, val: float, cb: Callable) -> HSlider:
	var s := HSlider.new()
	s.min_value = minv
	s.max_value = maxv
	s.step = step
	s.value = val
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.custom_minimum_size.y = 48
	s.focus_mode = Control.FOCUS_NONE
	s.value_changed.connect(cb)
	return s

# 分段选择：opts = [[值, 文字], ...]
static func seg(opts: Array, cur, cb: Callable, size := 23) -> HFlowContainer:
	var h := HFlowContainer.new()
	h.add_theme_constant_override("h_separation", 8)
	h.add_theme_constant_override("v_separation", 8)
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var btns: Array = []
	for o in opts:
		var b := btn(String(o[1]), Callable(), "tab_on" if o[0] == cur else "tab_off", size)
		btns.append(b)
		h.add_child(b)
	for i in btns.size():
		var val = opts[i][0]
		(btns[i] as Button).pressed.connect(func():
			for j in btns.size():
				var on: bool = j == i
				var bb: Button = btns[j]
				var k := "tab_on" if on else "tab_off"
				var tmp := btn("x", Callable(), k)
				for st in ["normal", "hover", "pressed"]:
					bb.add_theme_stylebox_override(st, tmp.get_theme_stylebox(st))
				bb.add_theme_color_override("font_color", Color.WHITE if on else MUTED)
				tmp.free()
			cb.call(val))
	return h

static func row(lbl: String, ctrl: Control, lw := 170) -> HBoxContainer:
	var h := hb(14)
	var l := label(lbl, 24, MUTED)
	l.custom_minimum_size.x = lw
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(l)
	ctrl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(ctrl)
	return h

static func hint(t: String, size := 21) -> Label:
	return label(t, size, MUTED, true)

# ---------------------------------------------------------------- 手绘图标按钮
class IconBtn extends Button:
	var icon_kind := "mic"
	var fg := Color("#f2efff")
	var pulse := false

	func _process(_d: float) -> void:
		if pulse:
			queue_redraw()

	func _draw() -> void:
		var c := size * 0.5
		var s := minf(size.x, size.y) * 0.5
		if pulse:
			var k := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 160.0)
			draw_arc(c, s * (0.95 + 0.12 * k), 0, TAU, 32, Color(1, 0.4, 0.45, 0.7 - 0.5 * k), 4.0, true)
		var w := maxf(s * 0.11, 2.5)
		var col := fg
		match icon_kind:
			"mic":
				var r := s * 0.2
				draw_rect(Rect2(c.x - r, c.y - s * 0.42, r * 2, s * 0.5), col)
				draw_circle(Vector2(c.x, c.y - s * 0.42), r, col)
				draw_circle(Vector2(c.x, c.y + s * 0.08), r, col)
				draw_arc(Vector2(c.x, c.y - s * 0.05), s * 0.36, 0.15, PI - 0.15, 16, col, w, true)
				draw_line(Vector2(c.x, c.y + s * 0.31), Vector2(c.x, c.y + s * 0.48), col, w, true)
				draw_line(Vector2(c.x - s * 0.2, c.y + s * 0.48), Vector2(c.x + s * 0.2, c.y + s * 0.48), col, w, true)
			"waves":
				var hs := [0.25, 0.55, 0.85, 0.55, 0.25]
				var k := 0.0
				if pulse:
					k = Time.get_ticks_msec() / 180.0
				for i in 5:
					var hh: float = s * (hs[i] * (0.75 + 0.25 * sin(k + i * 1.3)) if pulse else hs[i]) * 0.8
					var x := c.x + (i - 2) * s * 0.2
					draw_line(Vector2(x, c.y - hh * 0.5), Vector2(x, c.y + hh * 0.5), col, s * 0.12, true)
					draw_circle(Vector2(x, c.y - hh * 0.5), s * 0.06, col)
					draw_circle(Vector2(x, c.y + hh * 0.5), s * 0.06, col)
			"stop":
				draw_rect(Rect2(c - Vector2(s * 0.3, s * 0.3), Vector2(s * 0.6, s * 0.6)), col)
			"send":
				var p := PackedVector2Array([c + Vector2(-s * 0.45, -s * 0.42), c + Vector2(s * 0.5, 0), c + Vector2(-s * 0.45, s * 0.42), c + Vector2(-s * 0.25, 0)])
				draw_colored_polygon(p, col)
			"phone":
				var hp := PackedVector2Array()
				for i in 15:
					var a := lerpf(PI * 0.62, PI * 1.38, float(i) / 14.0)
					hp.append(c + Vector2(s * 0.18, 0) + Vector2(cos(a), sin(a)) * s * 0.42)
				var rot := PackedVector2Array()
				for v in hp:
					rot.append((v - c).rotated(-PI * 0.25) + c)
				draw_polyline(rot, col, w * 1.6, true)
				for e2 in [rot[0], rot[rot.size() - 1]]:
					var dd: Vector2 = (e2 - c).normalized()
					draw_colored_polygon(PackedVector2Array([e2 + dd.orthogonal() * s * 0.1 - dd * s * 0.02, e2 - dd.orthogonal() * s * 0.1 - dd * s * 0.02, e2 - dd.orthogonal() * s * 0.1 + dd * s * 0.12, e2 + dd.orthogonal() * s * 0.1 + dd * s * 0.12]), col)
			"gear":
				for i in 8:
					var a2 := TAU * float(i) / 8.0
					var d := Vector2(cos(a2), sin(a2))
					var nrm := Vector2(-d.y, d.x)
					var q := PackedVector2Array([c + d * s * 0.28 - nrm * s * 0.09, c + d * s * 0.46 - nrm * s * 0.07, c + d * s * 0.46 + nrm * s * 0.07, c + d * s * 0.28 + nrm * s * 0.09])
					draw_colored_polygon(q, col)
				draw_arc(c, s * 0.24, 0, TAU, 28, col, s * 0.15, true)
			"people":
				draw_circle(c + Vector2(-s * 0.16, -s * 0.18), s * 0.16, col)
				draw_arc(c + Vector2(-s * 0.16, s * 0.32), s * 0.28, PI, TAU, 14, col, w * 1.6, true)
				draw_circle(c + Vector2(s * 0.2, -s * 0.12), s * 0.13, Color(col, 0.75))
				draw_arc(c + Vector2(s * 0.22, s * 0.32), s * 0.22, PI * 1.05, TAU, 12, Color(col, 0.75), w * 1.4, true)
			"tasks":
				for i in 3:
					var y := c.y - s * 0.3 + i * s * 0.3
					draw_line(Vector2(c.x - s * 0.42, y), Vector2(c.x - s * 0.3, y + s * 0.1), col, w, true)
					draw_line(Vector2(c.x - s * 0.3, y + s * 0.1), Vector2(c.x - s * 0.12, y - s * 0.1), col, w, true)
					draw_line(Vector2(c.x, y), Vector2(c.x + s * 0.42, y), col, w, true)
			"back":
				draw_line(c + Vector2(s * 0.12, -s * 0.36), c + Vector2(-s * 0.24, 0), col, w * 1.2, true)
				draw_line(c + Vector2(-s * 0.24, 0), c + Vector2(s * 0.12, s * 0.36), col, w * 1.2, true)
			"fwd":
				draw_line(c + Vector2(-s * 0.12, -s * 0.36), c + Vector2(s * 0.24, 0), col, w * 1.2, true)
				draw_line(c + Vector2(s * 0.24, 0), c + Vector2(-s * 0.12, s * 0.36), col, w * 1.2, true)
			"close":
				draw_line(c + Vector2(-s * 0.28, -s * 0.28), c + Vector2(s * 0.28, s * 0.28), col, w * 1.2, true)
				draw_line(c + Vector2(s * 0.28, -s * 0.28), c + Vector2(-s * 0.28, s * 0.28), col, w * 1.2, true)
			"plus":
				draw_line(c + Vector2(-s * 0.32, 0), c + Vector2(s * 0.32, 0), col, w * 1.3, true)
				draw_line(c + Vector2(0, -s * 0.32), c + Vector2(0, s * 0.32), col, w * 1.3, true)
			"edit":
				draw_line(c + Vector2(-s * 0.28, s * 0.28), c + Vector2(s * 0.24, -s * 0.24), col, w * 1.8, true)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.36, s * 0.36), c + Vector2(-s * 0.32, s * 0.18), c + Vector2(-s * 0.18, s * 0.32)]), col)
			"speaker":
				draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.4, -s * 0.14), c + Vector2(-s * 0.2, -s * 0.14), c + Vector2(s * 0.05, -s * 0.36), c + Vector2(s * 0.05, s * 0.36), c + Vector2(-s * 0.2, s * 0.14), c + Vector2(-s * 0.4, s * 0.14)]), col)
				draw_arc(c + Vector2(s * 0.05, 0), s * 0.22, -0.9, 0.9, 10, col, w, true)
				draw_arc(c + Vector2(s * 0.05, 0), s * 0.38, -0.9, 0.9, 12, col, w, true)
			"sparkle":
				var sp := PackedVector2Array()
				for i in 8:
					var rr := s * (0.45 if i % 2 == 0 else 0.13)
					var a3 := -PI / 2.0 + PI * float(i) / 4.0
					sp.append(c + Vector2(cos(a3), sin(a3)) * rr)
				draw_colored_polygon(sp, col)
			"heart":
				var hp := PackedVector2Array()
				for i in 30:
					var tt := TAU * float(i) / 30.0
					hp.append(c + Vector2(16.0 * pow(sin(tt), 3), -(13.0 * cos(tt) - 5.0 * cos(2.0 * tt) - 2.0 * cos(3.0 * tt) - cos(4.0 * tt))) * (s * 0.42 / 17.0))
				draw_colored_polygon(hp, col)
			"keyboard":
				draw_rect(Rect2(c.x - s * 0.42, c.y - s * 0.26, s * 0.84, s * 0.52), col, false, w)
				for i in 4:
					draw_rect(Rect2(c.x - s * 0.32 + i * s * 0.18, c.y - s * 0.14, s * 0.1, s * 0.08), col)
				draw_line(Vector2(c.x - s * 0.22, c.y + s * 0.12), Vector2(c.x + s * 0.22, c.y + s * 0.12), col, w, true)
