package com.godot.game.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * 灵伴：桌面悬浮服务。
 * 在所有应用上层显示伙伴（透明背景），可以拖动、会自己走动、点一下弹出聊天框。
 * 图片和配置由 Godot 端写在应用私有目录里（config.json + 若干 png），本服务只负责显示和聊天。
 * 只有用户手动授权“显示在其他应用上层”后才会工作；窗口只有角色那么大，其余区域的点击都会直接穿透。
 */
public class OverlayService extends Service {
    private static final String CHANNEL = "lingban_overlay";
    private static final int NOTI_ID = 4107;
    private static final String ACTION_STOP = "com.godot.game.overlay.STOP";

    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private float dp = 1f;

    private JSONObject cfg;
    private File dir;
    private final Map<String, Bitmap> frames = new HashMap<>();

    private CharView charView;
    private WindowManager.LayoutParams charLp;
    private TextView bubble;
    private WindowManager.LayoutParams bubLp;
    private boolean bubbleShown = false;
    private long bubbleUntil = 0;

    private LinearLayout panel;
    private WindowManager.LayoutParams panLp;
    private TextView replyView;
    private EditText input;
    private boolean panelShown = false;

    private int screenW = 0, screenH = 0;
    private int cw = 0, ch = 0;           // 角色窗口大小（像素）
    private boolean running = false;

    // 状态
    private String emotion = "neutral";
    private long emoUntil = 0;
    private long speakUntil = 0;
    private boolean sleeping = false;
    private long lastTouch = 0;
    private long nextBlink = 0, blinkEnd = 0;
    private long nextAction = 0;
    private float walkTargetX = Float.NaN;
    private boolean facingLeft = false;
    private long hopStart = 0;
    private long nextIdleLine = 0;
    private boolean dragging = false;
    private boolean wander = true;

    private MediaPlayer player;
    private TextToSpeech sysTts;
    private boolean sysTtsReady = false;
    private int ttsGen = 0;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private Button micBtn;

    static volatile OverlayService instance;
    private final ArrayList<JSONObject> history = new ArrayList<>();
    private boolean thinking = false;

    // ------------------------------------------------------------------ 生命周期
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            teardown();
            stopSelf();
            return START_NOT_STICKY;
        }
        instance = this;
        startForegroundCompat();
        String d = intent != null ? intent.getStringExtra("dir") : null;
        if (d == null) {
            d = getFilesDir().getAbsolutePath() + "/overlay";
        }
        if (!canDraw()) {
            Toast.makeText(this, "灵伴：还没有“显示在其他应用上层”的权限", Toast.LENGTH_LONG).show();
            teardown();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            teardown();
            dir = new File(d);
            cfg = new JSONObject(readFile(new File(dir, "config.json")));
            loadFrames();
            buildViews();
            running = true;
            h.post(tick);
        } catch (Throwable e) {
            Toast.makeText(this, "灵伴悬浮启动失败：" + e, Toast.LENGTH_LONG).show();
            teardown();
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private boolean canDraw() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private Notification buildNoti(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "桌面悬浮", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent openPi = null;
        if (open != null) {
            openPi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        }
        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setContentTitle(title);
        b.setContentText(text);
        b.setSmallIcon(getApplicationInfo().icon);
        b.setOngoing(true);
        if (openPi != null) {
            b.setContentIntent(openPi);
        }
        b.addAction(new Notification.Action.Builder(null, "关闭悬浮", stopPi).build());
        return b.build();
    }

    private void startForegroundCompat() {
        Notification n = buildNoti("灵伴正在桌面上陪着你", "点这里打开灵伴；点“关闭悬浮”让它回家");
        if (Build.VERSION.SDK_INT >= 34) {
            // FOREGROUND_SERVICE_TYPE_SPECIAL_USE = 1 << 30
            startForeground(NOTI_ID, n, 0x40000000);
        } else {
            startForeground(NOTI_ID, n);
        }
    }

    private void teardown() {
        running = false;
        stopObserve(false);
        h.removeCallbacksAndMessages(null);
        stopSpeech();
        try {
            if (sysTts != null) {
                sysTts.shutdown();
            }
        } catch (Throwable ignored) {
        }
        sysTts = null;
        sysTtsReady = false;
        try {
            if (recognizer != null) {
                recognizer.destroy();
            }
        } catch (Throwable ignored) {
        }
        recognizer = null;
        listening = false;
        removeQuiet(charView);
        removeQuiet(bubble);
        removeQuiet(panel);
        charView = null;
        bubble = null;
        panel = null;
        bubbleShown = false;
        panelShown = false;
        frames.clear();
    }

    private void removeQuiet(View v) {
        if (v == null || wm == null) {
            return;
        }
        try {
            wm.removeView(v);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ 载入
    private static String readFile(File f) throws Exception {
        InputStream in = new FileInputStream(f);
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append('\n');
        }
        br.close();
        return sb.toString();
    }

    private void loadFrames() throws Exception {
        JSONObject fr = cfg.getJSONObject("frames");
        java.util.Iterator<String> it = fr.keys();
        while (it.hasNext()) {
            String k = it.next();
            Bitmap bm = BitmapFactory.decodeFile(new File(dir, fr.getString(k)).getAbsolutePath());
            if (bm != null) {
                frames.put(k, bm);
            }
        }
        if (!frames.containsKey("e_neutral")) {
            throw new Exception("缺少角色图片");
        }
    }

    // ------------------------------------------------------------------ 窗口
    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void measureScreen() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    private void buildViews() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        dp = getResources().getDisplayMetrics().density;
        measureScreen();
        wander = cfg.optBoolean("wander", true);
        int sizeDp = cfg.optInt("size_dp", 150);
        int fw = cfg.optInt("fw", 200), fh = cfg.optInt("fh", 300);
        ch = Math.round(sizeDp * dp);
        cw = Math.max(1, Math.round(ch * (fw / (float) fh)));

        charView = new CharView(this);
        charLp = new WindowManager.LayoutParams(cw, ch, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        charLp.gravity = Gravity.TOP | Gravity.START;
        charLp.x = Math.max(0, screenW - cw - Math.round(24 * dp));
        charLp.y = Math.max(0, screenH - ch - Math.round(110 * dp));
        wm.addView(charView, charLp);

        bubble = new TextView(this);
        bubble.setTextColor(Color.parseColor("#2b2b3a"));
        bubble.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        bubble.setPadding(Math.round(12 * dp), Math.round(8 * dp), Math.round(12 * dp), Math.round(8 * dp));
        bubble.setMaxWidth(Math.round(Math.min(screenW * 0.6f, 300 * dp)));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#F4F1FA"));
        bg.setCornerRadius(16 * dp);
        bg.setStroke(Math.round(1.5f * dp), Color.parseColor("#7C6FB0"));
        bubble.setBackground(bg);
        bubble.setVisibility(View.GONE);
        bubLp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubLp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(bubble, bubLp);

        buildPanel();

        long now = System.currentTimeMillis();
        lastTouch = now;
        nextBlink = now + 2500;
        nextAction = now + 3000;
        nextIdleLine = now + 90000 + rnd.nextInt(120000);
        emotion = "neutral";
        // 刚出现时打个招呼
        String greet = cfg.optString("greet", "");
        if (greet.length() > 0) {
            h.postDelayed(() -> say(greet, "happy"), 600);
        }
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(12 * dp);
        panel.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#F2201F33"));
        bg.setCornerRadius(20 * dp);
        bg.setStroke(Math.round(1.5f * dp), Color.parseColor("#7C6FB0"));
        panel.setBackground(bg);

        replyView = new TextView(this);
        replyView.setTextColor(Color.parseColor("#EDEAF8"));
        replyView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        replyView.setText(cfg.optString("name", "伙伴") + "：点一下输入框，和我说点什么吧");
        replyView.setMaxLines(10);
        panel.addView(replyView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("说点什么…");
        input.setHintTextColor(Color.parseColor("#9A96B8"));
        input.setTextColor(Color.WHITE);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendChat();
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(input, ilp);
        micBtn = makeBtn("说话", v -> toggleListen());
        row.addView(micBtn);
        obsBtn = makeBtn("陪看", v -> toggleObserve());
        row.addView(obsBtn);
        row.addView(makeBtn("发送", v -> sendChat()));
        row.addView(makeBtn("打开", v -> openApp()));
        row.addView(makeBtn("×", v -> hidePanel()));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Math.round(8 * dp);
        panel.addView(row, rlp);

        int pw = Math.round(Math.min(screenW * 0.92f, 560 * dp));
        panLp = new WindowManager.LayoutParams(pw, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        panLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        panLp.y = Math.round(24 * dp);
        panLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE;
        panel.setVisibility(View.GONE);
        wm.addView(panel, panLp);
    }

    private Button makeBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(Math.round(10 * dp), 0, Math.round(10 * dp), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#7C6FB0"));
        bg.setCornerRadius(14 * dp);
        b.setBackground(bg);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, Math.round(40 * dp));
        lp.leftMargin = Math.round(6 * dp);
        b.setLayoutParams(lp);
        return b;
    }

    private void showPanel() {
        if (panel == null) {
            return;
        }
        panelShown = true;
        panel.setVisibility(View.VISIBLE);
        walkTargetX = Float.NaN;
        input.requestFocus();
    }

    private void hidePanel() {
        if (panel == null) {
            return;
        }
        panelShown = false;
        try {
            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
            }
        } catch (Throwable ignored) {
        }
        panel.setVisibility(View.GONE);
    }

    private void openApp() {
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (open != null) {
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(open);
        }
        hidePanel();
    }

    // ------------------------------------------------------------------ 角色视图
    private class CharView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Matrix mx = new Matrix();
        Bitmap bmp;
        boolean flip = false;
        float bob = 0f;      // 像素
        float tilt = 0f;     // 度
        float lift = 0f;     // 跳起高度（像素）
        float downX, downY, startX, startY;
        long downT;
        final int slop;

        CharView(Context c) {
            super(c);
            slop = ViewConfiguration.get(c).getScaledTouchSlop();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (bmp == null) {
                return;
            }
            float sx = getWidth() / (float) bmp.getWidth();
            float sy = getHeight() / (float) bmp.getHeight();
            float s = Math.min(sx, sy) * 0.98f;
            mx.reset();
            mx.postScale(flip ? -s : s, s);
            float w = bmp.getWidth() * s;
            float hgt = bmp.getHeight() * s;
            float left = (getWidth() - w) / 2f + (flip ? w : 0f);
            float top = getHeight() - hgt - lift + bob;
            mx.postTranslate(left, top);
            mx.postRotate(tilt, getWidth() / 2f, getHeight());
            canvas.drawBitmap(bmp, mx, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = charLp.x;
                    startY = charLp.y;
                    downT = System.currentTimeMillis();
                    dragging = false;
                    lastTouch = downT;
                    if (sleeping) {
                        sleeping = false;
                        react("surprised", 1500);
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                        dragging = true;
                        walkTargetX = Float.NaN;
                        react("surprised", 60000);
                    }
                    if (dragging) {
                        charLp.x = clamp(Math.round(startX + dx), 0, Math.max(0, screenW - cw));
                        charLp.y = clamp(Math.round(startY + dy), 0, Math.max(0, screenH - ch));
                        updateLayoutQuiet(charView, charLp);
                        if (Math.abs(dx) > slop) {
                            flip = dx > 0 ? false : true;
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging) {
                        dragging = false;
                        react("happy", 1800);
                        hopStart = System.currentTimeMillis();
                    } else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                        onTap();
                    }
                    return true;
                default:
                    return super.onTouchEvent(e);
            }
        }
    }

    private void onTap() {
        lastTouch = System.currentTimeMillis();
        if (panelShown) {
            hidePanel();
            return;
        }
        // 轻轻戳一下：有一半概率先说一句触碰台词，同时展开聊天框
        JSONArray tl = cfg.optJSONArray("touch_lines");
        if (tl != null && tl.length() > 0 && rnd.nextInt(2) == 0) {
            JSONArray one = tl.optJSONArray(rnd.nextInt(tl.length()));
            if (one != null) {
                say(one.optString(0, ""), one.optString(1, "happy"));
            }
        } else {
            react("happy", 1500);
        }
        showPanel();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void updateLayoutQuiet(View v, WindowManager.LayoutParams lp) {
        try {
            wm.updateViewLayout(v, lp);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ 表情 / 说话
    private void react(String emo, long ms) {
        emotion = emo;
        emoUntil = System.currentTimeMillis() + ms;
    }

    private void say(String text, String emo) {
        if (text == null || text.trim().isEmpty() || bubble == null) {
            return;
        }
        long now = System.currentTimeMillis();
        react(emo, Math.max(2500, Math.min(9000, text.length() * 220L)));
        speakUntil = now + Math.min(7000, text.length() * 170L);
        bubble.setText(text);
        bubble.setVisibility(View.VISIBLE);
        bubbleShown = true;
        bubbleUntil = now + Math.max(3500, Math.min(11000, text.length() * 260L));
        positionBubble();
        speakOut(text);
    }

    private void positionBubble() {
        if (bubble == null || charLp == null) {
            return;
        }
        bubble.measure(View.MeasureSpec.makeMeasureSpec(screenW, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(screenH, View.MeasureSpec.AT_MOST));
        int bw = bubble.getMeasuredWidth(), bh = bubble.getMeasuredHeight();
        int x = charLp.x + cw / 2 - bw / 2;
        int y = charLp.y - bh - Math.round(4 * dp);
        if (y < 0) {
            y = charLp.y + ch / 4;
        }
        bubLp.x = clamp(x, 0, Math.max(0, screenW - bw));
        bubLp.y = Math.max(0, y);
        updateLayoutQuiet(bubble, bubLp);
    }

    // ------------------------------------------------------------------ 每帧
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running || charView == null) {
                return;
            }
            try {
                step();
            } catch (Throwable ignored) {
            }
            h.postDelayed(this, 40);
        }
    };

    private long lastStep = 0;

    private void step() {
        long now = System.currentTimeMillis();
        float dt = lastStep == 0 ? 0.04f : Math.min(0.2f, (now - lastStep) / 1000f);
        lastStep = now;

        // 屏幕方向变化
        int ow = screenW, oh = screenH;
        measureScreen();
        if (ow != screenW || oh != screenH) {
            charLp.x = clamp(charLp.x, 0, Math.max(0, screenW - cw));
            charLp.y = clamp(charLp.y, 0, Math.max(0, screenH - ch));
            updateLayoutQuiet(charView, charLp);
            panLp.width = Math.round(Math.min(screenW * 0.92f, 560 * dp));
            updateLayoutQuiet(panel, panLp);
        }

        if (emoUntil != 0 && now > emoUntil && !dragging) {
            emotion = "neutral";
            emoUntil = 0;
        }
        if (bubbleShown && now > bubbleUntil) {
            bubble.setVisibility(View.GONE);
            bubbleShown = false;
        }

        // 太久没人理就睡觉
        if (!sleeping && !panelShown && !dragging && now - lastTouch > 8 * 60 * 1000L) {
            sleeping = true;
            walkTargetX = Float.NaN;
        }

        // 走动
        boolean walking = false;
        if (!sleeping && !dragging && !panelShown && wander) {
            if (Float.isNaN(walkTargetX)) {
                if (now > nextAction) {
                    int r = rnd.nextInt(10);
                    if (r < 5) {
                        walkTargetX = rnd.nextInt(Math.max(1, screenW - cw));
                    } else if (r < 7) {
                        hopStart = now;
                        react("happy", 1200);
                    } else if (r < 8) {
                        react(rnd.nextBoolean() ? "thinking" : "smug", 2200);
                    }
                    nextAction = now + 2500 + rnd.nextInt(6000);
                }
            } else {
                float speed = 70f * dp;   // 像素/秒
                float dx = walkTargetX - charLp.x;
                if (Math.abs(dx) < 4) {
                    walkTargetX = Float.NaN;
                } else {
                    float step = Math.min(Math.abs(dx), speed * dt);
                    charLp.x += Math.round(Math.signum(dx) * step);
                    facingLeft = dx < 0;
                    charView.flip = facingLeft;
                    walking = true;
                    updateLayoutQuiet(charView, charLp);
                }
            }
        }

        // 偶尔自己说一句
        if (!sleeping && !panelShown && !thinking && now > nextIdleLine) {
            nextIdleLine = now + 120000 + rnd.nextInt(240000);
            JSONArray il = cfg.optJSONArray("idle_lines");
            if (il != null && il.length() > 0) {
                say(il.optString(rnd.nextInt(il.length())), "happy");
            }
        }

        // 选图
        String name;
        boolean speaking = now < speakUntil;
        if (sleeping) {
            name = "sleep";
        } else if (speaking) {
            boolean open = ((now / 140) % 2) == 0;
            name = (open ? "t_" : "e_") + emotion;
        } else if (emotion.equals("neutral") && now > nextBlink && now < blinkEnd + 1) {
            name = "blink";
        } else {
            name = "e_" + emotion;
        }
        if (emotion.equals("neutral") && !speaking && !sleeping) {
            if (now > nextBlink && blinkEnd < nextBlink) {
                blinkEnd = now + 140;
            }
            if (now <= blinkEnd && now > nextBlink) {
                name = "blink";
            } else if (now > blinkEnd && blinkEnd >= nextBlink) {
                nextBlink = now + 2200 + rnd.nextInt(3500);
            }
        }
        Bitmap bm = frames.get(name);
        if (bm == null) {
            bm = frames.get("e_neutral");
        }
        charView.bmp = bm;

        // 动作：呼吸 / 走路颠簸 / 跳
        float t = now / 1000f;
        float bob = (float) Math.sin(t * 2.2) * 2.5f * dp;
        float tilt = 0f;
        float lift = 0f;
        if (walking) {
            bob = (float) Math.abs(Math.sin(t * 9f)) * -5f * dp;
            tilt = (float) Math.sin(t * 9f) * 3f;
        }
        if (sleeping) {
            bob = (float) Math.sin(t * 1.2) * 2f * dp;
        }
        if (hopStart != 0) {
            float k = (now - hopStart) / 520f;
            if (k >= 1f) {
                hopStart = 0;
            } else {
                lift = (float) Math.sin(k * Math.PI) * 26f * dp;
            }
        }
        charView.bob = bob;
        charView.tilt = tilt;
        charView.lift = lift;
        charView.invalidate();

        if (bubbleShown) {
            positionBubble();
        }
    }

    // ------------------------------------------------------------------ 声音
    private void toastShort(String m) {
        try {
            Toast.makeText(this, m, Toast.LENGTH_LONG).show();
        } catch (Throwable ignored) {
        }
    }

    private static String cleanForSpeech(String t) {
        String s = t.replaceAll("[（(][^）)]{0,30}[）)]", "").replaceAll("[*_#`~>]+", "");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (cp >= 0x1F000 || (cp >= 0x2600 && cp < 0x2800 && "★☆♥♡♪♫".indexOf(cp) < 0)) {
                continue;
            }
            sb.appendCodePoint(cp);
        }
        String r = sb.toString().trim();
        return r.length() > 300 ? r.substring(0, 300) : r;
    }

    private void stopSpeech() {
        ttsGen++;
        try {
            if (player != null) {
                player.stop();
                player.release();
            }
        } catch (Throwable ignored) {
        }
        player = null;
        try {
            if (sysTts != null) {
                sysTts.stop();
            }
        } catch (Throwable ignored) {
        }
    }

    private void speakOut(final String text) {
        final JSONObject t = cfg == null ? null : cfg.optJSONObject("tts");
        if (t == null) {
            return;
        }
        final String mode = t.optString("mode", "off");
        if ("off".equals(mode)) {
            return;
        }
        final String clean = cleanForSpeech(text);
        if (clean.isEmpty() || clean.equals("……")) {
            return;
        }
        stopSpeech();
        final int gen = ttsGen;
        if ("api".equals(mode)) {
            new Thread(() -> {
                try {
                    final File f = fetchTts(t, clean, gen);
                    h.post(() -> {
                        if (gen == ttsGen && running) {
                            playFile(f, t.optInt("volume", 80));
                        }
                    });
                } catch (Throwable e) {
                    final String m = String.valueOf(e.getMessage());
                    h.post(() -> {
                        if (gen == ttsGen && running) {
                            toastShort("语音合成失败：" + m + "（改用系统语音）");
                            sysSpeak(clean, t);
                        }
                    });
                }
            }).start();
        } else {
            sysSpeak(clean, t);
        }
    }

    private static String trimSlash(String b) {
        String r = b.trim();
        while (r.endsWith("/")) {
            r = r.substring(0, r.length() - 1);
        }
        return r;
    }

    private static byte[] readAll(InputStream is) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) {
            bo.write(buf, 0, n);
        }
        return bo.toByteArray();
    }

    private File fetchTts(JSONObject t, String text, int gen) throws Exception {
        String base = trimSlash(t.optString("base", ""));
        String key = t.optString("key", "");
        boolean ds = t.optBoolean("dashscope", false);
        JSONObject body = new JSONObject();
        String url;
        String ext;
        if (ds) {
            String model = t.optString("model", "cosyvoice-v3-flash");
            JSONObject in = new JSONObject();
            if (model.startsWith("cosyvoice")) {
                url = base + "/services/audio/tts/SpeechSynthesizer";
                in.put("text", text.length() > 500 ? text.substring(0, 500) : text);
                in.put("voice", t.optString("voice", ""));
                in.put("format", "wav");
                in.put("sample_rate", 24000);
            } else {
                // Qwen3-TTS 走旧版地址
                url = base + "/services/aigc/multimodal-generation/generation";
                in.put("text", text.length() > 580 ? text.substring(0, 580) : text);
                in.put("voice", t.optString("voice", ""));
                in.put("language_type", "Auto");
            }
            body.put("model", model);
            body.put("input", in);
            ext = ".wav";
        } else {
            url = base.endsWith("/audio/speech") ? base : base + "/audio/speech";
            body.put("model", t.optString("model", ""));
            body.put("input", text);
            body.put("voice", t.optString("voice", ""));
            body.put("response_format", "mp3");
            ext = ".mp3";
        }
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(40000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + key);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        os.close();
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        byte[] data = is == null ? new byte[0] : readAll(is);
        c.disconnect();
        if (code < 200 || code >= 300) {
            String m = new String(data, StandardCharsets.UTF_8);
            throw new Exception("错误 " + code + (m.length() > 100 ? m.substring(0, 100) : m));
        }
        if (ds) {
            JSONObject j = new JSONObject(new String(data, StandardCharsets.UTF_8));
            String au = j.getJSONObject("output").getJSONObject("audio").optString("url", "");
            if (au.isEmpty()) {
                throw new Exception("没有返回声音");
            }
            if (au.startsWith("http://")) {
                au = "https://" + au.substring(7);
            }
            HttpURLConnection d = (HttpURLConnection) new URL(au).openConnection();
            d.setConnectTimeout(15000);
            d.setReadTimeout(40000);
            data = readAll(d.getInputStream());
            d.disconnect();
        }
        if (data.length < 100) {
            throw new Exception("声音数据太短");
        }
        File f = new File(getCacheDir(), "tts_" + (gen % 4) + ext);
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(data);
        fo.close();
        return f;
    }

    private void playFile(File f, int vol) {
        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            float v = Math.max(0.05f, Math.min(1f, vol / 100f));
            mp.setVolume(v, v);
            mp.setOnCompletionListener(m -> {
                try {
                    m.release();
                } catch (Throwable ignored) {
                }
                if (player == m) {
                    player = null;
                }
                speakUntil = 0;
            });
            mp.setOnErrorListener((m, w, e) -> {
                toastShort("播放声音失败");
                return true;
            });
            mp.prepare();
            player = mp;
            speakUntil = System.currentTimeMillis() + mp.getDuration() + 150L;
            mp.start();
        } catch (Throwable e) {
            toastShort("播放声音失败：" + e.getMessage());
        }
    }

    private void sysSpeak(final String text, final JSONObject t) {
        final int gen = ttsGen;
        final float rate = (float) t.optDouble("rate", 1.0);
        final float pitch = (float) t.optDouble("pitch", 1.0);
        final float vol = Math.max(0.05f, Math.min(1f, t.optInt("volume", 80) / 100f));
        final Runnable go = () -> {
            if (gen != ttsGen || sysTts == null || !sysTtsReady) {
                return;
            }
            try {
                sysTts.setSpeechRate(Math.max(0.5f, Math.min(2f, rate)));
                sysTts.setPitch(Math.max(0.5f, Math.min(2f, pitch)));
                Bundle b = new Bundle();
                b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol);
                sysTts.speak(text, TextToSpeech.QUEUE_FLUSH, b, "ov" + gen);
            } catch (Throwable ignored) {
            }
        };
        if (sysTts != null && sysTtsReady) {
            go.run();
            return;
        }
        if (sysTts == null) {
            sysTts = new TextToSpeech(this, status -> {
                sysTtsReady = status == TextToSpeech.SUCCESS;
                if (sysTtsReady) {
                    try {
                        sysTts.setLanguage(Locale.CHINA);
                    } catch (Throwable ignored) {
                    }
                    h.post(go);
                } else {
                    toastShort("系统语音不可用，所以听不到声音。可在灵伴里设置阿里云语音");
                }
            });
        }
    }


    // ------------------------------------------------------------------ 陪看屏幕
    private static final String OBS_CHAT_NOTE = "\n【陪看模式】你正坐在用户旁边，和他一起看着他的手机屏幕；用户这句话附带了他此刻屏幕的画面。像朋友一样结合画面回答，可以直接指出画面里的东西，不要说“截图”。仍然只返回 JSON。";
    private boolean observing = false;
    private Button obsBtn;
    private MediaProjection mproj;
    private VirtualDisplay vdisp;
    private ImageReader ireader;
    private int shotW = 0, shotH = 0;
    private int[] lastSig = null, commentedSig = null;
    private long lastComment = 0;
    private final ArrayList<Long> commentTimes = new ArrayList<>();
    private final ArrayList<String> obsLog = new ArrayList<>();
    private boolean obsBusy = false;

    private boolean visionOk() {
        JSONObject vc = cfg == null ? null : cfg.optJSONObject("vision");
        return vc != null && vc.optBoolean("on", false) && !vc.optString("key", "").isEmpty();
    }

    private String visBase(JSONObject vc) {
        String base = vc.optString("base", "").trim();
        while (base.endsWith("/")) {
            base = base.substring(0, base.length() - 1);
        }
        if (!base.contains("/compatible-mode")) {
            int ai = base.indexOf("/api/");
            base = (ai >= 0 ? base.substring(0, ai) : base) + "/compatible-mode/v1";
        }
        return base;
    }

    private String visWorking = null;

    private String callVision(JSONObject vc, JSONArray msgs) throws Exception {
        String base = visBase(vc);
        String key = vc.optString("key", "");
        ArrayList<String> tries = new ArrayList<>();
        if (visWorking != null) {
            tries.add(visWorking);
        }
        String first = visModel(vc);
        if (!tries.contains(first)) {
            tries.add(first);
        }
        for (String m : new String[]{"qwen-vl-plus", "qwen-vl-max", "qwen3-vl-plus", "qwen3-vl-flash", "qwen2.5-vl-72b-instruct"}) {
            if (!tries.contains(m)) {
                tries.add(m);
            }
        }
        StringBuilder log = new StringBuilder();
        Exception last = null;
        for (String m : tries) {
            try {
                String r = callChat(base, key, m, 0.9, msgs, false);
                visWorking = m;
                return r;
            } catch (Exception e) {
                last = e;
                String em = String.valueOf(e.getMessage());
                log.append(m).append(" → ").append(em.length() > 60 ? em.substring(0, 60) : em).append("\n");
                if (!(em.contains("404") || em.contains("Model") || em.contains("model"))) {
                    break;
                }
            }
        }
        String host = base.replace("https://", "");
        throw new Exception("视觉模型都不可用 @" + host + "\n" + log);
    }

    private String visModel(JSONObject vc) {
        String m = vc.optString("model", "").trim();
        return m.isEmpty() || m.contains("/") ? "qwen3-vl-flash" : m;
    }

    private void toggleObserve() {
        if (observing) {
            stopObserve(true);
            return;
        }
        if (!visionOk()) {
            replyView.setText("先在灵伴“设置 → 屏幕陪看”里打开，并确认有阿里云 Key，再重新开启悬浮。");
            return;
        }
        replyView.setText("请在弹出的授权框里选“整个屏幕”并允许，我才能陪你一起看。");
        try {
            Intent it = new Intent(this, ProjectionActivity.class);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(it);
        } catch (Throwable e) {
            replyView.setText("打不开屏幕授权：" + e.getMessage());
        }
    }

    void onProjectionDenied(String why) {
        h.post(() -> {
            if (replyView != null) {
                replyView.setText(why);
            }
        });
    }

    void onProjection(final int code, final Intent data) {
        h.post(() -> {
            try {
                Notification vn = buildNoti("灵伴正在陪你看屏幕", "在悬浮窗点“看着”可以停止；也可以点“关闭悬浮”");
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(NOTI_ID, vn, 0x40000000 | 0x00000020);
                } else if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTI_ID, vn, 0x00000020);
                }
                MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                mproj = mpm.getMediaProjection(code, data);
                mproj.registerCallback(new MediaProjection.Callback() {
                    @Override
                    public void onStop() {
                        h.post(() -> stopObserve(true));
                    }
                }, h);
                DisplayMetrics dm = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(dm);
                float sc = 1100f / Math.max(dm.widthPixels, dm.heightPixels);
                if (sc > 1f) {
                    sc = 1f;
                }
                shotW = Math.max(2, Math.round(dm.widthPixels * sc));
                shotH = Math.max(2, Math.round(dm.heightPixels * sc));
                ireader = ImageReader.newInstance(shotW, shotH, PixelFormat.RGBA_8888, 2);
                vdisp = mproj.createVirtualDisplay("lingban", shotW, shotH, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ireader.getSurface(), null, h);
                observing = true;
                lastSig = null;
                commentedSig = null;
                lastComment = System.currentTimeMillis();
                if (obsBtn != null) {
                    obsBtn.setText("看着");
                }
                replyView.setText("好，我陪你一起看。想让我停就再点一次“看着”。");
                say("我在旁边陪你看着呢。", "happy");
                h.postDelayed(obsTick, 3000);
            } catch (Throwable e) {
                stopObserve(false);
                replyView.setText("开启陪看失败：" + e.getMessage());
            }
        });
    }

    private void stopObserve(boolean tell) {
        boolean was = observing;
        observing = false;
        h.removeCallbacks(obsTick);
        try {
            if (vdisp != null) {
                vdisp.release();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (ireader != null) {
                ireader.close();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (mproj != null) {
                mproj.stop();
            }
        } catch (Throwable ignored) {
        }
        vdisp = null;
        ireader = null;
        mproj = null;
        if (obsBtn != null) {
            obsBtn.setText("陪看");
        }
        if (tell && was && replyView != null) {
            replyView.setText("好，不看了。");
        }
    }

    // 取当前屏幕：返回缩小后的位图（可能为 null）
    private Bitmap grabBitmap() {
        ImageReader r = ireader;
        if (r == null) {
            return null;
        }
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) {
                return null;
            }
            Image.Plane pl = img.getPlanes()[0];
            int rs = pl.getRowStride();
            int ps = pl.getPixelStride();
            Bitmap full = Bitmap.createBitmap(rs / ps, shotH, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(pl.getBuffer());
            Bitmap out = Bitmap.createBitmap(full, 0, 0, shotW, shotH);
            if (out != full) {
                full.recycle();
            }
            return out;
        } catch (Throwable e) {
            return null;
        } finally {
            if (img != null) {
                img.close();
            }
        }
    }

    private volatile Bitmap keepBmp = null;

    private String captureB64() {
        Bitmap b = panelShown ? keepBmp : grabBitmap();
        if (b == null) {
            b = keepBmp;
        }
        if (b == null) {
            return null;
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 65, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private static int[] sigOf(Bitmap b) {
        Bitmap s = Bitmap.createScaledBitmap(b, 24, 24, true);
        int[] o = new int[576];
        for (int y = 0; y < 24; y++) {
            for (int x = 0; x < 24; x++) {
                int c = s.getPixel(x, y);
                o[y * 24 + x] = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10;
            }
        }
        s.recycle();
        return o;
    }

    private static double sigDiff(int[] a, int[] b) {
        if (a == null || b == null) {
            return 999;
        }
        long t = 0;
        for (int i = 0; i < a.length; i++) {
            t += Math.abs(a[i] - b[i]);
        }
        return t / (double) a.length;
    }

    private final Runnable obsTick = new Runnable() {
        @Override
        public void run() {
            if (!observing || !running) {
                return;
            }
            h.postDelayed(this, 3000);
            if (obsBusy || thinking || listening || recording || panelShown) {
                return;
            }
            final Bitmap b = grabBitmap();
            if (b == null) {
                return;
            }
            Bitmap old = keepBmp;
            keepBmp = b;
            if (old != null && old != b) {
                old.recycle();
            }
            int[] sig = sigOf(b);
            double moving = sigDiff(sig, lastSig);
            lastSig = sig;
            JSONObject vc = cfg.optJSONObject("vision");
            String freq = vc == null ? "normal" : vc.optString("freq", "normal");
            long gap = "lively".equals(freq) ? 12000 : ("quiet".equals(freq) ? 50000 : 24000);
            int perHour = "lively".equals(freq) ? 60 : ("quiet".equals(freq) ? 12 : 30);
            long now = System.currentTimeMillis();
            // 用户还在滑动（画面在变）就等一等；画面停稳了、且和上次评论时不一样，才开口
            if (moving > 3.0) {
                return;
            }
            if (now - lastComment < gap || sigDiff(sig, commentedSig) < 9.0) {
                return;
            }
            while (!commentTimes.isEmpty() && now - commentTimes.get(0) > 3600000L) {
                commentTimes.remove(0);
            }
            if (commentTimes.size() >= perHour) {
                return;
            }
            obsBusy = true;
            final int[] fsig = sig;
            new Thread(() -> observeOnce(fsig)).start();
        }
    };

    private void observeOnce(final int[] sig) {
        String say = null;
        String emo = "happy";
        try {
            String shot = captureB64();
            JSONObject vc = cfg.getJSONObject("vision");
            if (shot == null) {
                return;
            }
            StringBuilder prev = new StringBuilder();
            for (String s : obsLog) {
                prev.append("- ").append(s).append("\n");
            }
            String ask = "这是用户此刻的手机屏幕。你像坐在他旁边一起看手机的朋友，自然地搭话。\n"
                    + "规则：\n1. 只有画面里有值得说的东西（好看的、有趣的、划算或可疑的、用户可能需要建议的）才开口；平淡就把 say 填空字符串。\n"
                    + "2. 一两句口语，别复述屏幕上的文字，别用“截图”“图片”这类词，当作自己亲眼在看。\n"
                    + "3. 别重复之前说过的话。\n"
                    + "4. 涉及密码、验证码、银行卡号、私人聊天内容或隐私照片，不评论，say 填空字符串。\n"
                    + "5. 画面里如果有你自己（悬浮的小人），忽略它。\n"
                    + (prev.length() > 0 ? "你之前说过：\n" + prev : "")
                    + "只返回 JSON：{\"say\":\"...\",\"emotion\":\"neutral|happy|excited|love|shy|sad|angry|surprised|thinking|smug\"}";
            JSONArray msgs = new JSONArray();
            msgs.put(new JSONObject().put("role", "system").put("content", cfg.optString("system", "")));
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject().put("url", "data:image/jpeg;base64," + shot)));
            parts.put(new JSONObject().put("type", "text").put("text", ask));
            msgs.put(new JSONObject().put("role", "user").put("content", parts));
            String content = callVision(vc, msgs);
            String clean = content.trim();
            int a = clean.indexOf('{');
            int bb = clean.lastIndexOf('}');
            if (a >= 0 && bb > a) {
                JSONObject o = new JSONObject(clean.substring(a, bb + 1));
                say = o.optString("say", "");
                emo = o.optString("emotion", "happy");
            }
        } catch (Throwable e) {
            final String m = String.valueOf(e.getMessage());
            h.post(() -> {
                obsBusy = false;
                lastComment = System.currentTimeMillis();
                if (replyView != null) {
                    replyView.setText("陪看出错：" + m);
                }
            });
            return;
        }
        final String fs = say;
        final String fe = emo;
        h.post(() -> {
            obsBusy = false;
            long now = System.currentTimeMillis();
            lastComment = now;
            commentedSig = sig;
            if (!observing || !running || fs == null || fs.trim().isEmpty() || thinking || panelShown) {
                return;
            }
            commentTimes.add(now);
            obsLog.add(fs);
            while (obsLog.size() > 5) {
                obsLog.remove(0);
            }
            try {
                JSONObject am = new JSONObject();
                am.put("role", "assistant");
                am.put("content", fs);
                history.add(am);
                while (history.size() > 14) {
                    history.remove(0);
                }
            } catch (Throwable ignored) {
            }
            say(fs, validEmo(fe));
        });
    }

    // ------------------------------------------------------------------ 听（API 录音识别，优先）
    private volatile boolean recording = false;
    private AudioRecord rec;

    private void toggleListen() {
        JSONObject st = cfg == null ? null : cfg.optJSONObject("stt");
        if (st == null || !st.optBoolean("api", false) || st.optString("key", "").isEmpty()) {
            toggleListenSys();
            return;
        }
        if (recording) {
            recording = false;
            return;
        }
        if (thinking || listening) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
            replyView.setText("还没有麦克风权限。先打开灵伴，在里面点一次麦克风并允许，再回来。");
            return;
        }
        stopSpeech();
        final int rate = 16000;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        try {
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                rec = null;
                replyView.setText("麦克风打不开（可能被别的应用占用），先用键盘打字吧。");
                return;
            }
            rec.startRecording();
        } catch (Throwable e) {
            replyView.setText("麦克风启动失败：" + e.getMessage());
            return;
        }
        recording = true;
        setListening(true);
        replyView.setText("在听…说完再点一次“听…”");
        react("thinking", 40000);
        final AudioRecord r = rec;
        new Thread(() -> {
            ByteArrayOutputStream pcm = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            long t0 = System.currentTimeMillis();
            try {
                while (recording && System.currentTimeMillis() - t0 < 45000) {
                    int n = r.read(buf, 0, buf.length);
                    if (n > 0) {
                        pcm.write(buf, 0, n);
                    } else if (n < 0) {
                        break;
                    }
                }
            } catch (Throwable ignored) {
            }
            recording = false;
            try {
                r.stop();
            } catch (Throwable ignored) {
            }
            try {
                r.release();
            } catch (Throwable ignored) {
            }
            rec = null;
            final byte[] data = pcm.toByteArray();
            h.post(() -> {
                setListening(false);
                if (data.length < rate * 2 / 3) {
                    react("neutral", 100);
                    replyView.setText("没录到声音，再试一次？");
                    return;
                }
                replyView.setText("识别中…");
                new Thread(() -> asrApi(data, rate)).start();
            });
        }).start();
    }

    private void asrApi(byte[] pcm, int rate) {
        String err = null;
        String text = "";
        try {
            JSONObject st = cfg.getJSONObject("stt");
            ByteArrayOutputStream wav = new ByteArrayOutputStream();
            int len = pcm.length;
            byte[] hd = new byte[44];
            String riff = "RIFF";
            for (int i = 0; i < 4; i++) {
                hd[i] = (byte) riff.charAt(i);
            }
            putInt(hd, 4, 36 + len);
            String wf = "WAVEfmt ";
            for (int i = 0; i < 8; i++) {
                hd[8 + i] = (byte) wf.charAt(i);
            }
            putInt(hd, 16, 16);
            hd[20] = 1;
            hd[22] = 1;
            putInt(hd, 24, rate);
            putInt(hd, 28, rate * 2);
            hd[32] = 2;
            hd[34] = 16;
            hd[36] = 'd';
            hd[37] = 'a';
            hd[38] = 't';
            hd[39] = 'a';
            putInt(hd, 40, len);
            wav.write(hd);
            wav.write(pcm);
            String b64 = Base64.encodeToString(wav.toByteArray(), Base64.NO_WRAP);
            String base = st.optString("base", "").trim();
            while (base.endsWith("/")) {
                base = base.substring(0, base.length() - 1);
            }
            int ci = base.indexOf("/compatible-mode");
            if (ci < 0) {
                int ai = base.indexOf("/api/");
                base = (ai >= 0 ? base.substring(0, ai) : base) + "/compatible-mode/v1";
            }
            String model = st.optString("model", "");
            if (model.isEmpty() || model.contains("/")) {
                model = "qwen3-asr-flash";
            }
            JSONObject ia = new JSONObject().put("data", "data:audio/wav;base64," + b64);
            JSONObject part = new JSONObject().put("type", "input_audio").put("input_audio", ia);
            JSONObject msg = new JSONObject().put("role", "user").put("content", new JSONArray().put(part));
            JSONObject body = new JSONObject().put("model", model).put("stream", false).put("messages", new JSONArray().put(msg));
            HttpURLConnection c = (HttpURLConnection) new URL(base + "/chat/completions").openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(40000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + st.optString("key", ""));
            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            os.close();
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while (is != null && (n = is.read(b)) > 0) {
                bo.write(b, 0, n);
            }
            String resp = bo.toString("UTF-8");
            if (code >= 400) {
                err = "识别失败 " + code + "｜" + resp.replace("\n", " ");
                if (err.length() > 160) {
                    err = err.substring(0, 160);
                }
            } else {
                text = new JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "").trim();
            }
        } catch (Throwable e) {
            err = "识别出错：" + e.getMessage();
        }
        final String fe = err;
        final String ft = text;
        h.post(() -> {
            if (fe != null) {
                react("sad", 2000);
                replyView.setText(fe);
            } else if (ft.isEmpty()) {
                react("neutral", 100);
                replyView.setText("没听清，再说一次？");
            } else {
                input.setText(ft);
                sendChat();
            }
        });
    }

    private static void putInt(byte[] a, int o, int v) {
        a[o] = (byte) (v & 255);
        a[o + 1] = (byte) ((v >> 8) & 255);
        a[o + 2] = (byte) ((v >> 16) & 255);
        a[o + 3] = (byte) ((v >> 24) & 255);
    }

    // ------------------------------------------------------------------ 听（点“说话”，说完自动发送）
    private void toggleListenSys() {
        if (listening) {
            try {
                if (recognizer != null) {
                    recognizer.stopListening();
                }
            } catch (Throwable ignored) {
            }
            return;
        }
        if (thinking) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) {
            replyView.setText("还没有麦克风权限。先打开灵伴，在里面点一次麦克风并允许，再回来。");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            replyView.setText("这台设备没有可用的语音识别服务，先用键盘打字吧。");
            return;
        }
        stopSpeech();
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(new RecognitionListener() {
                    public void onReadyForSpeech(Bundle p) {
                        replyView.setText("在听…说完会自动发送");
                        react("thinking", 30000);
                    }

                    public void onBeginningOfSpeech() {
                    }

                    public void onRmsChanged(float rms) {
                    }

                    public void onBufferReceived(byte[] b) {
                    }

                    public void onEndOfSpeech() {
                    }

                    public void onError(int e) {
                        setListening(false);
                        react("neutral", 100);
                        replyView.setText(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "没听清，再说一次？" : "这台设备在悬浮窗里用不了语音识别（" + e + "）。请点输入框，用键盘上的话筒按钮说话。");
                    }

                    public void onResults(Bundle r) {
                        setListening(false);
                        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (l != null && !l.isEmpty() && !l.get(0).trim().isEmpty()) {
                            input.setText(l.get(0).trim());
                            sendChat();
                        } else {
                            replyView.setText("没听清，再说一次？");
                        }
                    }

                    public void onPartialResults(Bundle r) {
                        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (l != null && !l.isEmpty()) {
                            replyView.setText("听到：" + l.get(0));
                        }
                    }

                    public void onEvent(int t, Bundle b) {
                    }
                });
            }
            Intent it = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            it.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            it.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN");
            it.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            setListening(true);
            recognizer.startListening(it);
        } catch (Throwable e) {
            setListening(false);
            replyView.setText("语音识别启动失败：" + e.getMessage());
        }
    }

    private void setListening(boolean on) {
        listening = on;
        if (micBtn != null) {
            micBtn.setText(on ? "听…" : "说话");
        }
    }

    // ------------------------------------------------------------------ 聊天
    private void sendChat() {
        if (thinking || input == null) {
            return;
        }
        final String text = input.getText().toString().trim();
        if (text.isEmpty()) {
            return;
        }
        input.setText("");
        final String key = cfg.optString("key", "");
        if (key.isEmpty()) {
            replyView.setText("还没有设置 AI 的 Key。先打开灵伴，在“设置 → AI 模型”里填好，再回来找我。");
            react("sad", 3000);
            return;
        }
        stopSpeech();
        lastTouch = System.currentTimeMillis();
        sleeping = false;
        thinking = true;
        replyView.setText("……");
        react("thinking", 60000);
        final String sys = cfg.optString("system", "") + (observing ? OBS_CHAT_NOTE : "");
        final boolean useVis = observing && visionOk();
        final JSONObject vc = cfg.optJSONObject("vision");
        final String base = useVis ? visBase(vc) : cfg.optString("base", "");
        final String key2 = useVis ? vc.optString("key", "") : key;
        final String model = useVis ? visModel(vc) : cfg.optString("model", "");
        final double temp = cfg.optDouble("temp", 0.9);
        final boolean jsonMode = useVis ? false : cfg.optBoolean("json", true);
        final ArrayList<JSONObject> snapshot;
        try {
            JSONObject um = new JSONObject();
            um.put("role", "user");
            um.put("content", text);
            history.add(um);
            while (history.size() > 14) {
                history.remove(0);
            }
            snapshot = new ArrayList<>(history);
        } catch (Throwable e) {
            thinking = false;
            return;
        }
        new Thread(() -> {
            String say = null;
            String emo = "neutral";
            String err = null;
            try {
                JSONArray msgs = new JSONArray();
                JSONObject sm = new JSONObject();
                sm.put("role", "system");
                sm.put("content", sys);
                msgs.put(sm);
                String shot = useVis ? captureB64() : null;
                for (int mi = 0; mi < snapshot.size(); mi++) {
                    JSONObject m = snapshot.get(mi);
                    if (shot != null && mi == snapshot.size() - 1 && "user".equals(m.optString("role"))) {
                        JSONArray parts = new JSONArray();
                        parts.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject().put("url", "data:image/jpeg;base64," + shot)));
                        parts.put(new JSONObject().put("type", "text").put("text", m.optString("content")));
                        msgs.put(new JSONObject().put("role", "user").put("content", parts));
                    } else {
                        msgs.put(m);
                    }
                }
                String content = useVis ? callVision(vc, msgs) : callChat(base, key2, model, temp, msgs, jsonMode);
                String clean = content.trim();
                int a = clean.indexOf('{');
                int b = clean.lastIndexOf('}');
                if (a >= 0 && b > a) {
                    try {
                        JSONObject o = new JSONObject(clean.substring(a, b + 1));
                        say = o.optString("say", "");
                        emo = o.optString("emotion", "neutral");
                    } catch (Throwable ignored) {
                    }
                }
                if (say == null || say.isEmpty()) {
                    say = clean.length() > 300 ? clean.substring(0, 300) : clean;
                }
            } catch (Throwable e) {
                err = String.valueOf(e.getMessage());
            }
            final String fs = say;
            final String fe = emo;
            final String ferr = err;
            h.post(() -> {
                thinking = false;
                if (!running) {
                    return;
                }
                if (ferr != null || fs == null) {
                    replyView.setText("连不上 AI：" + ferr);
                    react("sad", 3500);
                    return;
                }
                try {
                    JSONObject am = new JSONObject();
                    am.put("role", "assistant");
                    am.put("content", fs);
                    history.add(am);
                } catch (Throwable ignored) {
                }
                replyView.setText(cfg.optString("name", "伙伴") + "：" + fs);
                say(fs, validEmo(fe));
            });
        }).start();
    }

    private String validEmo(String e) {
        String[] ok = {"neutral", "happy", "excited", "love", "shy", "sad", "angry", "surprised", "thinking", "sleepy", "smug", "scared"};
        for (String s : ok) {
            if (s.equals(e)) {
                return e;
            }
        }
        return "happy";
    }

    private String callChat(String base, String key, String model, double temp, JSONArray msgs, boolean jsonMode) throws Exception {
        String b = base.trim();
        while (b.endsWith("/")) {
            b = b.substring(0, b.length() - 1);
        }
        String url = b.endsWith("/chat/completions") ? b : b + "/chat/completions";
        for (int attempt = 0; attempt < 2; attempt++) {
            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("messages", msgs);
            body.put("temperature", temp);
            body.put("max_tokens", 2000);
            body.put("stream", false);
            boolean useJson = jsonMode && attempt == 0;
            if (useJson) {
                body.put("response_format", new JSONObject().put("type", "json_object"));
            }
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + key);
            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            os.close();
            int code = c.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                br.close();
            }
            c.disconnect();
            if (code == 400 && useJson) {
                continue;   // 有的服务商不支持 JSON 模式，关掉再试一次
            }
            if (code < 200 || code >= 300) {
                String msg = sb.toString();
                if (code == 401 || code == 403) {
                    throw new Exception("Key 无效或没有权限（" + code + "）");
                }
                if (code == 402) {
                    throw new Exception("账户余额不足（402）");
                }
                throw new Exception("请求失败（" + code + "）" + (msg.length() > 80 ? msg.substring(0, 80) : msg));
            }
            JSONObject j = new JSONObject(sb.toString());
            JSONArray ch = j.getJSONArray("choices");
            String content = ch.getJSONObject(0).getJSONObject("message").optString("content", "");
            if (content.isEmpty()) {
                throw new Exception("AI 没有返回内容");
            }
            return content;
        }
        throw new Exception("AI 没有返回内容");
    }
}
