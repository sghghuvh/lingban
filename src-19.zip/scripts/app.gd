extends Control
# 桌宠物语 桌宠物语 —— 可定制的 AI 电子伙伴
# 主程序：界面、聊天流程、触碰反应、主动互动、权限确认。

const SP = preload("res://scripts/species.gd")
const CR = preload("res://scripts/creature.gd")
const UI = preload("res://scripts/ui.gd")
const Store = preload("res://scripts/store.gd")
const LLMScript = preload("res://scripts/llm.gd")
const BrainScript = preload("res://scripts/brain.gd")
const VoiceScript = preload("res://scripts/voice.gd")
const DeviceScript = preload("res://scripts/device.gd")
const TasksScript = preload("res://scripts/tasks.gd")
const OverlayScript = preload("res://scripts/overlay.gd")
const StageScript = preload("res://scripts/stage.gd")
const ART = preload("res://scripts/art.gd")
const LIFE = preload("res://scripts/life.gd")
const SoundScript = preload("res://scripts/sound.gd")

const VERSION := "0.6.0"

var store
var llm
var brain
var voice
var device
var tasks
var floater
var font: Font
var fbold: Font
var rng := RandomNumberGenerator.new()

# 图层
var screen_root: Control
var overlay: CanvasLayer
var ov_root: Control
var top: CanvasLayer
var top_root: Control
var creature
var snd
var _pending_sick := ""
var bubble: PanelContainer
var bubble_lbl: Label
var _bubble_t := 0.0

var screen := ""
var layout := ""
var _kb_pad := -1.0
var modal: Control = null

# 聊天界面引用
var stage: Control
var chat_scroll: ScrollContainer
var chat_box: VBoxContainer
var input: LineEdit
var mic_btn: Button
var call_btn: Button
var send_btn: Button
var name_lbl: Label
var sub_lbl: Label
var status_lbl: Label
var typing_row: Control = null
var busy := false
var _placed := false

# 计时
var last_input := 0.0
var last_proactive := 0.0
var _ai_pro_times: Array = []
var _save_t := 0.0
var _greeted := false

# 创建界面状态
var cr_spec: Dictionary = {}
var cr_edit_id := ""
var cr_preview
var cr_info: VBoxContainer
var cr_busy := false
var cr_desc := ""
var cr_art_on := true
var art_busy := false

func _now() -> float:
	return Time.get_ticks_msec() / 1000.0

func _unix() -> int:
	return int(Time.get_unix_time_from_system())

# ================================================================== 启动
func _ready() -> void:
	rng.randomize()
	font = load("res://fonts/sans_sc.otf") as Font
	if font == null:
		font = ThemeDB.fallback_font
	var fv := FontVariation.new()
	fv.base_font = font
	fv.variation_embolden = 0.7
	fbold = fv
	UI.font = font
	UI.bold = fbold
	store = Store.new()
	if OS.get_environment("LINGBAN_DIR") != "":
		store.DIR = OS.get_environment("LINGBAN_DIR")
	store.load_all()
	llm = LLMScript.new()
	llm.name = "LLM"
	add_child(llm)
	llm.setup(store)
	brain = BrainScript.new()
	add_child(brain)
	brain.setup(self)
	voice = VoiceScript.new()
	add_child(voice)
	voice.setup(self)
	device = DeviceScript.new()
	add_child(device)
	device.setup(self)
	floater = OverlayScript.new()
	add_child(floater)
	floater.setup(self)
	tasks = TasksScript.new()
	add_child(tasks)
	tasks.setup(self)
	tasks.task_done.connect(_on_task_done)
	snd = SoundScript.new()
	add_child(snd)
	snd.setup()
	snd.on = bool(store.settings.behavior.get("sfx", true))
	UI.fscale = float(store.settings.behavior.get("font_scale", 1.0))
	voice.speaking_changed.connect(func(on: bool):
		if creature != null:
			creature.set_speaking(on))
	voice.heard.connect(_on_heard)
	voice.listen_state.connect(_on_listen_state)
	llm.usage_changed.connect(_refresh_top)
	_apply_accent()
	_build_layers()
	get_viewport().size_changed.connect(_on_resize)
	last_input = _now()
	last_proactive = _now()
	var now0 := _unix()
	var sick_ev := ""
	for c0 in store.companions:
		var e0: String = LIFE.catch_up(c0.state, now0, rng)
		if c0 == store.current() and e0 == "sick":
			sick_ev = e0
	_pending_sick = sick_ev
	if bool(store.settings.behavior.get("intro_anim", true)) and not store.companions.is_empty():
		show_screen("intro")
	else:
		_enter_after_intro()
	if OS.get_environment("LINGBAN_TEST") != "" and ResourceLoader.exists("res://tests/runner.gd"):
		var tr = load("res://tests/runner.gd").new()
		add_child(tr)
		tr.run(self)

func _apply_accent() -> void:
	var c = store.current()
	var acc := Color("#8f7cf6")
	if c != null:
		acc = UI.readable_accent(Color(String(c.spec.colors.main)))
	UI.accent = acc
	theme = UI.make_theme()
	if ov_root != null:
		ov_root.theme = theme
		top_root.theme = theme

func _build_layers() -> void:
	var bg := ColorRect.new()
	bg.color = UI.BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	screen_root = Control.new()
	screen_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(screen_root)
	overlay = CanvasLayer.new()
	overlay.layer = 5
	add_child(overlay)
	ov_root = Control.new()
	ov_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	ov_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ov_root.theme = theme
	overlay.add_child(ov_root)
	creature = CR.new()
	creature.font = font
	ov_root.add_child(creature)
	creature.touched.connect(_on_touched)
	bubble = BubbleBox.new()
	bubble.add_theme_stylebox_override("panel", UI.sb(Color("#fffdf8"), 22, 18, 0, Color(), 12))
	bubble.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bubble_lbl = UI.label("", 25, Color("#2b2340"), false)
	bubble_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bubble_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bubble.add_child(bubble_lbl)
	bubble.visible = false
	ov_root.add_child(bubble)
	top = CanvasLayer.new()
	top.layer = 10
	add_child(top)
	top_root = Control.new()
	top_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	top_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_root.theme = theme
	top.add_child(top_root)

class BubbleBox extends PanelContainer:
	func _draw() -> void:
		var c := Vector2(size.x * 0.5, size.y)
		draw_colored_polygon(PackedVector2Array([c + Vector2(-14, -2), c + Vector2(14, -2), c + Vector2(0, 18)]), Color("#fffdf8"))

# ================================================================== 布局
func _layout_mode() -> String:
	var forced := String(store.settings.behavior.get("ui_mode", "auto"))
	if forced == "mini":
		return "mini"
	var vs := get_viewport_rect().size
	if forced == "auto":
		var ws := DisplayServer.window_get_size()
		var ss := DisplayServer.screen_get_size()
		if OS.get_name() == "Android" and ss.x > 0 and ss.y > 0 and float(ws.x * ws.y) < 0.33 * float(ss.x * ss.y):
			return "mini"
		if OS.get_environment("LINGBAN_MINI") != "":
			return "mini"
	return "landscape" if vs.x > vs.y * 1.08 else "portrait"

func _on_resize() -> void:
	var m := _layout_mode()
	if screen == "chat" and m != layout:
		show_screen("chat")
	elif screen == "chat":
		_place_creature.call_deferred(false)

func _process(delta: float) -> void:
	# 输入法弹出时把界面顶上去
	var kb := float(DisplayServer.virtual_keyboard_get_height())
	var pad := 0.0
	if kb > 0.0:
		var wh := float(DisplayServer.window_get_size().y)
		if wh > 0.0:
			pad = kb * get_viewport_rect().size.y / wh
	if absf(pad - _kb_pad) > 1.0:
		_kb_pad = pad
		screen_root.offset_bottom = -pad
		if screen == "chat":
			_place_creature.call_deferred(false)
			_scroll_bottom.call_deferred()
	# 气泡跟随
	if bubble.visible:
		_bubble_t -= delta
		if _bubble_t <= 0.0 and not voice.is_speaking():
			bubble.visible = false
		else:
			_position_bubble()
	if screen == "chat":
		_tick_chat(delta)
	_life_tick(delta)
	_save_t += delta
	if _save_t > 60.0:
		_save_t = 0.0
		var c = store.current()
		if c != null:
			c.state.last_seen = _unix()
			store.save_companions()

func _input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.pressed or ev is InputEventKey:
		last_input = _now()
	if modal != null or screen != "chat" or not overlay.visible or creature == null or not creature.visible:
		return
	if creature.handle_input(ev):
		get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_WM_GO_BACK_REQUEST:
			_go_back()
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_WM_CLOSE_REQUEST:
			_save_all()
		NOTIFICATION_APPLICATION_RESUMED:
			_life_resume()
			last_input = _now()
			if screen == "chat":
				_greet()

func _go_back() -> void:
	if modal != null:
		close_modal()
		return
	if screen == "advanced":
		show_screen("settings")
		return
	if screen in ["settings", "list", "profile", "help"] and not store.companions.is_empty():
		show_screen("chat")
		return
	if screen == "create":
		if cr_edit_id != "":
			show_screen("profile")
		elif not store.companions.is_empty():
			show_screen("chat")
		else:
			show_screen("welcome")
		return
	_save_all()
	get_tree().quit()

func _save_all() -> void:
	var c = store.current()
	if c != null:
		c.state.last_seen = _unix()
		store.save_chat(c.id)
	store.save_companions()
	store.save_settings()
	store.save_tasks()

# ================================================================== 屏幕切换
func show_screen(name: String) -> void:
	if voice != null and voice.call_mode and name != "chat":
		voice.set_call_mode(false)
	for ch in screen_root.get_children():
		ch.queue_free()
	close_modal()
	screen = name
	typing_row = null
	stage = null
	bubble.visible = false
	overlay.visible = name == "chat"
	creature.cancel_touch()
	screen_root.modulate.a = 0.0
	create_tween().tween_property(screen_root, "modulate:a", 1.0, 0.22)
	match name:
		"intro":
			_build_intro()
		"welcome":
			_build_welcome()
		"chat":
			_build_chat()
		"create":
			_build_create()
		"settings":
			_build_settings()
		"list":
			_build_list()
		"profile":
			_build_profile()
		"help":
			_build_help()
		"advanced":
			_build_advanced()

func _full(c: Control) -> Control:
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen_root.add_child(c)
	return c

func _scroll_page(title: String, back_to: String) -> VBoxContainer:
	var root := UI.vb(0)
	_full(root)
	var bar := UI.hb(10)
	bar.custom_minimum_size.y = 96
	bar.add_child(UI.gap(1, 8))
	var back := UI.icon_btn("back", func(): show_screen(back_to), 64, "flat")
	bar.add_child(back)
	var tl := UI.title(title, 32)
	tl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bar.add_child(tl)
	root.add_child(bar)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var body := UI.vb(18)
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var vw := get_viewport_rect().size.x
	var side := 24
	if vw > 1000.0:
		side = int((vw - 920.0) * 0.5)
	var mc := UI.margin(body, side, 6, side, 60)
	mc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(mc)
	return body

func _section(parent: Control, title: String) -> VBoxContainer:
	var p := UI.panel(UI.PANEL, 24, 22)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := UI.vb(14)
	p.add_child(v)
	if title != "":
		v.add_child(UI.title(title, 28))
	parent.add_child(p)
	return v

# ================================================================== 欢迎页
func _build_welcome() -> void:
	var root := UI.vb(16)
	_full(root)
	root.alignment = BoxContainer.ALIGNMENT_CENTER
	var holder := StageScript.new()
	holder.custom_minimum_size = Vector2(0, 460)
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(UI.margin(holder, 28, 0, 28, 0))
	var c := CR.new()
	c.font = font
	c.set_spec(SP.default_spec())
	c.wander = false
	holder.add_child(c)
	holder.resized.connect(func():
		c.position = Vector2(holder.size.x * 0.5, holder.ground_y())
		c.home_y = c.position.y
		c.x_min = c.position.x
		c.x_max = c.position.x
		c.scale = Vector2.ONE * clampf(holder.size.y / 330.0, 0.8, 1.5))
	var cref: WeakRef = weakref(c)
	get_tree().create_timer(0.6).timeout.connect(func():
		var cc = cref.get_ref()
		if cc != null:
			cc.react("happy", "wave", 3.0))
	var t := UI.title("桌宠物语", 64)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(t)
	var st := UI.label("创造一个只属于你的电子伙伴\n它有自己的样子、性格和声音，会陪你聊天，帮你做事", 26, UI.MUTED, false, HORIZONTAL_ALIGNMENT_CENTER)
	root.add_child(st)
	root.add_child(UI.gap(10))
	var b1 := UI.btn("创造我的伙伴", func():
		cr_edit_id = ""
		cr_spec = {}
		show_screen("create"), "primary", 30)
	b1.custom_minimum_size = Vector2(420, 84)
	b1.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	root.add_child(b1)
	var b2 := UI.btn("先认识一下团子", func():
		store.add_companion(SP.default_spec())
		_apply_accent()
		show_screen("chat"), "ghost", 26)
	b2.custom_minimum_size = Vector2(420, 72)
	b2.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	root.add_child(b2)
	var b3 := UI.btn("导入朋友的伙伴码", func(): _import_dialog(), "ghost", 24)
	b3.custom_minimum_size = Vector2(420, 64)
	b3.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	root.add_child(b3)
	var b4 := UI.btn("使用教程 / 联系客服", func(): show_screen("help"), "ghost", 22)
	b4.custom_minimum_size = Vector2(420, 56)
	b4.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	root.add_child(b4)
	root.add_child(UI.label("不填 AI Key 也能用（离线模式）；在设置里填上自己的 Key 会聪明很多。", 21, UI.MUTED, false, HORIZONTAL_ALIGNMENT_CENTER))

# ================================================================== 开场动画
func _enter_after_intro() -> void:
	if store.companions.is_empty():
		show_screen("welcome")
		return
	show_screen("chat")
	if _pending_sick != "":
		add_note("你不在的时候，%s 生病了。点“照顾”和“喂食”能帮它好起来。" % store.current().spec.name)
		_pending_sick = ""
	if not bool(store.settings.get("seen_intro", false)):
		call_deferred("_first_run")

func _stage_bg_rect() -> Control:
	var sg: Dictionary = store.settings.get("stage", {})
	var p := String(sg.get("img", ""))
	if String(sg.get("mode", "sky")) == "image" and p != "" and FileAccess.file_exists(p):
		var img := Image.load_from_file(p)
		if img != null and not img.is_empty():
			var tr := TextureRect.new()
			tr.texture = ImageTexture.create_from_image(img)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			tr.set_anchors_preset(Control.PRESET_FULL_RECT)
			tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			return tr
	var g := ColorRect.new()
	g.set_anchors_preset(Control.PRESET_FULL_RECT)
	g.color = Color("#1a1430")
	g.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return g

func _build_intro() -> void:
	var root := _full(Control.new())
	root.add_child(_stage_bg_rect())
	var veil := ColorRect.new()
	veil.set_anchors_preset(Control.PRESET_FULL_RECT)
	veil.color = Color(0.06, 0.05, 0.12, 0.45)
	veil.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(veil)
	var comp = store.current()
	var c := CR.new()
	c.font = font
	if comp != null:
		c.set_spec(comp.spec)
		_apply_art(c, comp)
	else:
		c.set_spec(SP.default_spec())
	c.wander = false
	root.add_child(c)
	var title := UI.title("桌宠物语", 68)
	title.set_anchors_preset(Control.PRESET_CENTER)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(title)
	var tip := UI.label("轻触继续", 22, UI.MUTED, false, HORIZONTAL_ALIGNMENT_CENTER)
	tip.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	tip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(tip)
	var lay := func():
		var sz := get_viewport_rect().size
		c.position = Vector2(sz.x * 0.5, sz.y * 0.62)
		c.home_y = c.position.y
		c.x_min = c.position.x
		c.x_max = c.position.x
		c.scale = Vector2.ZERO
		title.position = Vector2(sz.x * 0.5 - title.size.x * 0.5, sz.y * 0.2)
		title.modulate.a = 0.0
		tip.position = Vector2(sz.x * 0.5 - tip.size.x * 0.5, sz.y - 90)
		tip.modulate.a = 0.0
	root.resized.connect(lay)
	lay.call()
	await get_tree().process_frame
	lay.call()
	if snd != null:
		snd.play("chime")
	var cref: WeakRef = weakref(c)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(c, "scale", Vector2.ONE * clampf(get_viewport_rect().size.y / 620.0, 0.8, 1.6), 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(title, "modulate:a", 1.0, 0.7).set_delay(0.3)
	tw.tween_property(tip, "modulate:a", 1.0, 0.6).set_delay(0.9)
	get_tree().create_timer(0.7).timeout.connect(func():
		var cc = cref.get_ref()
		if cc != null:
			cc.react("happy", "wave", 3.0))
	var done := {"v": false}
	var go := func():
		if done.v:
			return
		done.v = true
		if snd != null:
			snd.play("tap")
		_enter_after_intro()
	veil.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed:
			go.call())
	get_tree().create_timer(2.6).timeout.connect(func(): go.call())

# ================================================================== 表情包
func _stickers() -> Array:
	var d := DirAccess.open(store.DIR + "/stickers")
	if d == null:
		return []
	var out: Array = []
	for f in d.get_files():
		if f.get_extension().to_lower() in ["png", "jpg", "jpeg", "webp"]:
			out.append(store.DIR + "/stickers/" + f)
	out.sort()
	return out

func _sticker_panel() -> void:
	var v := _modal("表情包", 680.0)
	v.add_child(UI.hint("点一个表情发给伙伴；也可以从相册添加自己的表情（静态图片）。"))
	var grid := HFlowContainer.new()
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	var items := _stickers()
	for pth in items:
		var im := Image.load_from_file(pth)
		if im == null or im.is_empty():
			continue
		var b := Button.new()
		b.custom_minimum_size = Vector2(120, 120)
		b.add_theme_stylebox_override("normal", UI.sb(UI.CARD, 16, 4))
		b.add_theme_stylebox_override("hover", UI.sb(UI.CARD2, 16, 4))
		b.add_theme_stylebox_override("pressed", UI.sb(UI.accent.darkened(0.2), 16, 4))
		b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		var tr := TextureRect.new()
		tr.texture = ImageTexture.create_from_image(im)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.set_anchors_preset(Control.PRESET_FULL_RECT)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(tr)
		var sp: String = pth
		b.pressed.connect(func():
			close_modal()
			_send_sticker(sp))
		grid.add_child(b)
	if items.is_empty():
		v.add_child(UI.label("还没有表情，点下面从相册添加。", 22, UI.MUTED))
	else:
		v.add_child(grid)
	v.add_child(UI.btn("从相册添加表情", func(): _add_sticker(), "primary", 24))

func _add_sticker() -> void:
	DisplayServer.file_dialog_show("选择表情图片", "", "", false, DisplayServer.FILE_DIALOG_MODE_OPEN_FILE, PackedStringArray(["*.png,*.jpg,*.jpeg,*.webp;图片"]), func(ok: bool, paths: PackedStringArray, _f: int):
		if not ok or paths.is_empty():
			return
		var im := Image.load_from_file(paths[0])
		if im == null or im.is_empty():
			toast("读取失败")
			return
		var mx: int = maxi(im.get_width(), im.get_height())
		if mx > 512:
			var sc := 512.0 / float(mx)
			im.resize(int(im.get_width() * sc), int(im.get_height() * sc), Image.INTERPOLATE_LANCZOS)
		DirAccess.make_dir_recursive_absolute(store.DIR + "/stickers")
		im.save_png("%s/stickers/s_%d.png" % [store.DIR, _unix()])
		toast("已添加表情")
		close_modal()
		_sticker_panel())

func _send_sticker(pth: String) -> void:
	var comp = store.current()
	if comp == null:
		return
	if snd != null:
		snd.play("pop")
	add_msg({"role": "image", "path": pth, "text": "", "sticker": true})
	last_input = _now()
	creature.wake()
	creature.react("happy", "none", 3.0)

# ================================================================== 聊天页
func _build_chat() -> void:
	var comp = store.current()
	if comp == null:
		show_screen("welcome")
		return
	layout = _layout_mode()
	creature.set_spec(comp.spec)
	_apply_art(creature, comp)
	_apply_body_look(comp)
	creature.wander = true
	_placed = false
	stage = StageScript.new()
	stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stage.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_apply_stage_bg()
	var topbar := _make_topbar(layout == "mini")
	var panel := UI.panel(UI.PANEL, 28, 0)
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var pv := UI.vb(8)
	panel.add_child(UI.margin(pv, 14, 14, 14, 14))
	chat_scroll = ScrollContainer.new()
	chat_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	chat_box = UI.vb(12)
	chat_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_scroll.add_child(UI.margin(chat_box, 4, 4, 8, 4))
	(chat_scroll.get_child(0) as Control).size_flags_horizontal = Control.SIZE_EXPAND_FILL
	match layout:
		"landscape":
			var hb := UI.hb(0)
			_full(hb)
			stage.size_flags_stretch_ratio = 1.15
			hb.add_child(stage)
			var right := UI.vb(8)
			right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			right.size_flags_stretch_ratio = 1.0
			hb.add_child(right)
			right.add_child(topbar)
			right.add_child(UI.margin(panel, 10, 0, 14, 14))
			(right.get_child(1) as Control).size_flags_vertical = Control.SIZE_EXPAND_FILL
		"mini":
			var vb := UI.vb(0)
			_full(vb)
			vb.add_child(topbar)
			stage.compact = true
			vb.add_child(stage)
			chat_scroll.visible = false
		_:
			var vb2 := UI.vb(0)
			_full(vb2)
			vb2.add_child(topbar)
			stage.size_flags_stretch_ratio = 0.95
			vb2.add_child(stage)
			panel.size_flags_stretch_ratio = 1.05
			var pm := UI.margin(panel, 0, -24, 0, 0)
			pm.size_flags_vertical = Control.SIZE_EXPAND_FILL
			pm.size_flags_stretch_ratio = 1.05
			vb2.add_child(pm)
	pv.add_child(chat_scroll)
	if layout != "mini":
		pv.add_child(_make_chips())
		pv.add_child(_make_input_row(false))
	else:
		var vbm: VBoxContainer = screen_root.get_child(screen_root.get_child_count() - 1)
		var pin := UI.panel(UI.PANEL, 0, 10)
		pin.add_child(_make_input_row(true))
		vbm.add_child(pin)
		panel.queue_free()
		chat_scroll = null
		chat_box = null
	# 历史消息
	var hist: Array = store.chat_of(comp.id)
	if hist.is_empty():
		var tip := "小提示：摸摸%s的头、戳戳它、按住把它拎起来，它都会有反应。双击聊天气泡可以复制。" % comp.spec.name
		if not llm.has_chat():
			tip += "\n现在是离线模式（只能简单聊天）。点右上角的齿轮，填上自己的 AI Key，它就能真正听懂你、帮你做事。"
		hist.append({"role": "note", "text": tip, "t": _unix()})
	for m in hist.slice(maxi(0, hist.size() - 60)):
		_add_msg_ui(m, false)
	_refresh_top()
	await get_tree().process_frame
	await get_tree().process_frame
	_place_creature(true)
	_scroll_bottom()
	if not _greeted:
		_greeted = true
		get_tree().create_timer(0.8).timeout.connect(_greet)

func _make_topbar(mini: bool) -> Control:
	var comp = store.current()
	var bar := UI.hb(10)
	bar.custom_minimum_size.y = 76 if mini else 104
	bar.add_child(UI.gap(1, 10))
	var names := UI.vb(0)
	names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	names.alignment = BoxContainer.ALIGNMENT_CENTER
	name_lbl = UI.title(comp.spec.name, 28 if mini else 32)
	sub_lbl = UI.label("", 20, UI.MUTED)
	names.add_child(name_lbl)
	if not mini:
		names.add_child(sub_lbl)
	var nb := Button.new()
	nb.flat = true
	nb.focus_mode = Control.FOCUS_NONE
	for stn in ["normal", "hover", "pressed", "focus"]:
		nb.add_theme_stylebox_override(stn, StyleBoxEmpty.new())
	nb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	nb.custom_minimum_size.y = 80
	nb.add_child(names)
	names.set_anchors_preset(Control.PRESET_FULL_RECT)
	names.mouse_filter = Control.MOUSE_FILTER_IGNORE
	nb.pressed.connect(func(): show_screen("profile"))
	bar.add_child(nb)
	status_lbl = UI.label("", 20, UI.WARN)
	status_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bar.add_child(status_lbl)
	var sz := 56 if mini else 64
	if not mini:
		bar.add_child(UI.icon_btn("tasks", func(): _tasks_popup(), sz, "flat"))
		bar.add_child(UI.icon_btn("people", func(): show_screen("list"), sz, "flat"))
	bar.add_child(UI.icon_btn("gear", func(): show_screen("settings"), sz, "flat"))
	bar.add_child(UI.gap(1, 6))
	return bar

func _make_chips() -> Control:
	var sc := ScrollContainer.new()
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	sc.custom_minimum_size.y = 58
	var h := UI.hb(8)
	sc.add_child(h)
	var chips := [["摸摸头", "_pet"], ["喂食", "_feed"], ["照顾", "_care"], ["每日签到", "_checkin"], ["今日任务", "_tasks"], ["讲个笑话", "给我讲个笑话"], ["猜谜", "我们来猜谜吧"], ["跳个舞", "跳个舞给我看"], ["陪我聊聊", "陪我聊聊天吧"], ["你会做什么", "你能帮我做什么？"], ["表情包", "_sticker"], ["复制聊天", "_copy"], ["使用教程", "_help"], ["联系客服", "_support"]]
	for c in chips:
		var cmd: String = c[1]
		h.add_child(UI.btn(String(c[0]), func():
			if cmd == "_pet":
				_on_touched("head", "pet")
			elif cmd == "_tasks":
				_tasks_popup()
			elif cmd == "_checkin":
				_checkin()
			elif cmd == "_feed":
				_feed()
			elif cmd == "_care":
				_care()
			elif cmd == "_copy":
				_copy_chat()
			elif cmd == "_sticker":
				_sticker_panel()
			elif cmd == "_help":
				show_screen("help")
			elif cmd == "_support":
				_support_popup()
			else:
				send_text(cmd), "chip"))
	return sc

func _make_input_row(mini: bool) -> Control:
	var row := UI.hb(10)
	var sz := 64 if not mini else 60
	mic_btn = UI.icon_btn("mic", func(): _mic_pressed(), sz)
	row.add_child(mic_btn)
	input = UI.le("和%s说点什么…" % store.current().spec.name)
	input.custom_minimum_size.y = sz
	input.text_submitted.connect(func(t: String): send_text(t))
	row.add_child(input)
	row.add_child(UI.btn("图", func(): _pick_chat_image(), "ghost", 24))
	send_btn = UI.icon_btn("send", func(): send_text(input.text), sz, "primary")
	row.add_child(send_btn)
	call_btn = UI.icon_btn("waves", func(): _call_pressed(), sz)
	row.add_child(call_btn)
	_update_voice_btns()
	return row

func _refresh_top() -> void:
	if screen != "chat" or name_lbl == null or not is_instance_valid(name_lbl):
		return
	var comp = store.current()
	if comp == null:
		return
	name_lbl.text = comp.spec.name
	var aff := int(comp.state.get("affection", 25))
	var hearts := ""
	for i in 5:
		hearts += "♥" if aff >= (i + 1) * 20 - 10 else "♡"
	var dc: Array = tasks.done_count()
	sub_lbl.text = "%s %s · 心情%s · 任务 %d/%d" % [hearts, BrainScript.level_name(aff), SP.EMO_CN.get(String(comp.state.get("mood", "happy")), ""), dc[0], dc[1]]
	var bst := LIFE.status_text(comp.state)
	if bst != "":
		sub_lbl.text += " · " + bst
	if voice.call_mode:
		status_lbl.text = "通话中"
		status_lbl.add_theme_color_override("font_color", UI.GOOD)
	elif not llm.has_chat():
		status_lbl.text = "离线模式"
		status_lbl.add_theme_color_override("font_color", UI.WARN)
	else:
		status_lbl.text = ""

func _place_creature(first: bool) -> void:
	if stage == null or not is_instance_valid(stage) or stage.size.y < 10:
		return
	var r := stage.get_global_rect()
	var gy: float = r.position.y + stage.ground_y()
	var sc := clampf(r.size.y / 330.0, 0.55, 1.7)
	if layout == "mini":
		sc = clampf(r.size.y / 300.0, 0.55, 2.2)
	elif layout == "landscape":
		sc = clampf(minf(r.size.y / 420.0, r.size.x / 300.0), 0.6, 2.4)
	creature.scale = Vector2.ONE * sc
	creature.wander = bool(store.settings.behavior.get("roam", true))
	var x0 := r.position.x + 70.0 * sc
	var x1 := r.position.x + r.size.x - 70.0 * sc
	if first or not _placed:
		creature.position = Vector2((r.position.x + r.size.x * 0.5), gy)
		creature.airborne = false
		_placed = true
	creature.set_ground(gy, x0, maxf(x1, x0 + 1.0))
	creature.visible = true

func _scroll_bottom() -> void:
	if chat_scroll == null or not is_instance_valid(chat_scroll):
		return
	await get_tree().process_frame
	if is_instance_valid(chat_scroll):
		chat_scroll.scroll_vertical = int(chat_scroll.get_v_scroll_bar().max_value)

# ---------------------------------------------------------------- 消息
func _bubble_width() -> float:
	var w := chat_scroll.size.x if chat_scroll != null and is_instance_valid(chat_scroll) and chat_scroll.size.x > 50 else get_viewport_rect().size.x * 0.9
	return w * 0.8

func _text_label(t: String, col: Color, maxw: float, size := 25) -> Label:
	var l := UI.label(t, size, col)
	var tw := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x + 4.0
	if tw > maxw or t.find("\n") >= 0:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = maxw
	return l

func _add_msg_ui(m: Dictionary, anim := true) -> void:
	if chat_box == null or not is_instance_valid(chat_box):
		return
	var comp = store.current()
	var role := String(m.get("role", "note"))
	var maxw := _bubble_width()
	var row := UI.hb(0)
	match role:
		"user":
			row.add_child(UI.grow(UI.gap(1)))
			var p := UI.panel(UI.accent.darkened(0.12), 20, 14)
			p.add_child(_text_label(String(m.text), Color.WHITE, maxw))
			_copyable(p, String(m.text))
			row.add_child(p)
		"assistant":
			var p2 := UI.panel(UI.CARD, 20, 14)
			var v := UI.vb(4)
			v.add_child(UI.label(comp.spec.name if comp != null else "", 19, UI.MUTED))
			v.add_child(_text_label(String(m.text), UI.TXT, maxw))
			p2.add_child(v)
			_copyable(p2, String(m.text))
			row.add_child(p2)
			row.add_child(UI.grow(UI.gap(1)))
		"image":
			row.add_child(UI.grow(UI.gap(1)))
			var ip := UI.panel(UI.accent.darkened(0.12), 18, 8)
			var iv := UI.vb(6)
			var img := Image.load_from_file(String(m.get("path", "")))
			if img != null and not img.is_empty():
				var tr := TextureRect.new()
				tr.texture = ImageTexture.create_from_image(img)
				tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
				tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
				var iw: float = minf(maxw, 360.0)
				tr.custom_minimum_size = Vector2(iw, iw * minf(1.4, float(img.get_height()) / maxf(1.0, float(img.get_width()))))
				iv.add_child(tr)
			if String(m.get("text", "")) != "":
				iv.add_child(_text_label(String(m.text), Color.WHITE, minf(maxw, 360.0)))
			ip.add_child(iv)
			row.add_child(ip)
		"action":
			row.add_child(_action_card(m))
		_:
			var l := UI.label(String(m.get("text", "")), 20, UI.MUTED, true, HORIZONTAL_ALIGNMENT_CENTER)
			row.add_child(l)
	chat_box.add_child(row)
	if anim:
		row.modulate.a = 0.0
		create_tween().tween_property(row, "modulate:a", 1.0, 0.25)

func add_msg(m: Dictionary) -> void:
	var comp = store.current()
	if comp == null:
		return
	m["t"] = _unix()
	store.chat_of(comp.id).append(m)
	_add_msg_ui(m)
	_scroll_bottom()
	store.save_chat(comp.id)

func add_note(t: String) -> void:
	add_msg({"role": "note", "text": t})

func _show_typing(on: bool) -> void:
	if typing_row != null and is_instance_valid(typing_row):
		typing_row.queue_free()
		typing_row = null
	if on and chat_box != null and is_instance_valid(chat_box):
		var row := UI.hb(0)
		var p := UI.panel(UI.CARD, 20, 14)
		var l := UI.label("…", 28, UI.MUTED)
		p.add_child(l)
		row.add_child(p)
		row.add_child(UI.grow(UI.gap(1)))
		chat_box.add_child(row)
		typing_row = row
		var tw := create_tween().set_loops()
		tw.tween_callback(func(): l.text = "·")
		tw.tween_interval(0.3)
		tw.tween_callback(func(): l.text = "··")
		tw.tween_interval(0.3)
		tw.tween_callback(func(): l.text = "···")
		tw.tween_interval(0.3)
		row.tree_exiting.connect(func(): tw.kill())
		_scroll_bottom()

func show_bubble(t: String, secs := -1.0) -> void:
	var txt := t.strip_edges()
	if txt == "":
		return
	if layout == "mini" and screen == "chat":
		pass
	bubble_lbl.text = txt
	var maxw := minf(get_viewport_rect().size.x * 0.7, 460.0)
	var tw := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 25).x + 8.0
	bubble_lbl.custom_minimum_size.x = minf(tw, maxw)
	bubble.size = Vector2.ZERO
	bubble.reset_size()
	bubble.visible = true
	_bubble_t = secs if secs > 0.0 else clampf(2.0 + txt.length() * 0.12, 2.5, 9.0)
	_position_bubble()

func _position_bubble() -> void:
	if creature == null:
		return
	var vs := get_viewport_rect().size
	var head: Vector2 = creature.head_top_global()
	var sz := bubble.get_combined_minimum_size()
	bubble.size = sz
	var p := head - Vector2(sz.x * 0.5, sz.y + 22.0)
	var top_lim := 8.0
	if stage != null and is_instance_valid(stage):
		top_lim = stage.get_global_rect().position.y + 6.0
	p.x = clampf(p.x, 10.0, vs.x - sz.x - 10.0)
	p.y = clampf(p.y, top_lim, vs.y - sz.y - 10.0)
	bubble.position = p

# ---------------------------------------------------------------- 发送与回复
func send_text(t: String) -> void:
	var text := t.strip_edges()
	if text == "" or busy:
		return
	var comp = store.current()
	if comp == null:
		return
	if input != null and is_instance_valid(input):
		input.text = ""
	last_input = _now()
	creature.wake()
	voice.stop_speaking()
	add_msg({"role": "user", "text": text})
	comp.state.msgs = int(comp.state.get("msgs", 0)) + 1
	tasks.progress("chat")
	if text.length() >= 15:
		tasks.progress("long")
	if text.find("笑话") >= 0:
		tasks.progress("joke")
	if text.find("教我") >= 0 or text.find("知识") >= 0 or text.find("科普") >= 0:
		tasks.progress("learn")
	if text.find("跳舞") >= 0 or text.find("跳个舞") >= 0:
		tasks.progress("dance")
	busy = true
	if snd != null: snd.play("pop")
	creature.react("thinking", "none", 30.0)
	_show_typing(true)
	brain.chat(comp, text, func(r: Dictionary): _on_reply(comp, r))

func _on_reply(comp: Dictionary, r: Dictionary) -> void:
	busy = false
	_show_typing(false)
	if store.current() != comp:
		return
	if r.has("error"):
		add_note("AI 连接失败：%s（这次用离线模式回复）" % r.error)
	if r.get("riddle_done", false):
		tasks.progress("riddle")
	var say := String(r.say)
	if snd != null: snd.play("happy")
	add_msg({"role": "assistant", "text": say, "emo": r.emotion, "raw": String(r.get("raw", ""))})
	creature.react(String(r.emotion), String(r.gesture), 6.0)
	comp.state.mood = r.emotion if r.emotion != "neutral" else comp.state.get("mood", "happy")
	show_bubble(say)
	voice.speak(say, comp.spec)
	var rem := String(r.get("remember", ""))
	if rem != "":
		_remember(comp, rem)
	var da := int(r.get("affection", 0))
	if da != 0:
		comp.state.affection = clampi(int(comp.state.affection) + da, 0, 100)
	if r.get("action") != null and typeof(r.action) == TYPE_DICTIONARY:
		handle_action(r.action)
	comp.state.last_seen = _unix()
	store.save_companions()
	_refresh_top()
	if _pending_voice != "":
		var pv := _pending_voice
		_pending_voice = ""
		send_text.call_deferred(pv)

func _remember(comp: Dictionary, fact: String) -> void:
	var mem: Array = comp.state.memory
	for m in mem:
		var old := String(m.get("text", ""))
		if old == fact or old.find(fact) >= 0 or fact.find(old) >= 0 and old.length() > 4:
			m.text = fact if fact.length() > old.length() else old
			return
	mem.append({"t": _unix(), "text": fact})
	while mem.size() > 60:
		mem.pop_front()

# ---------------------------------------------------------------- 手机操作（权限）
func handle_action(a: Dictionary) -> void:
	var comp = store.current()
	var perm: String = device.perm_of(a)
	var cap: String = device.cap_of(String(a.get("type", "")))
	if cap == "":
		return
	if perm == "deny":
		add_note("%s想要%s，但你关闭了「%s」权限（可以在设置里打开）" % [comp.spec.name, device.describe(a), device.CAPS.get(cap, cap)])
		creature.react("sad", "shrug", 3.0)
		return
	if perm == "allow":
		_run_action(a)
		return
	add_msg({"role": "action", "action": a, "status": "pending"})

func _action_card(m: Dictionary) -> Control:
	var comp = store.current()
	var a: Dictionary = m.action
	var p := UI.panel(Color("#2a2547"), 20, 16)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := UI.vb(10)
	p.add_child(v)
	v.add_child(UI.label("%s 想要：%s" % [comp.spec.name if comp != null else "伙伴", device.describe(a)], 24, UI.TXT, true))
	var st := String(m.get("status", "pending"))
	if st == "pending":
		var h := UI.hb(10)
		var b_ok := UI.btn("允许", Callable(), "primary", 23)
		var b_always := UI.btn("总是允许", Callable(), "ghost", 23)
		var b_no := UI.btn("拒绝", Callable(), "ghost", 23)
		h.add_child(b_ok)
		h.add_child(b_always)
		h.add_child(b_no)
		v.add_child(h)
		var done := func(status: String):
			m.status = status
			if comp != null:
				store.save_chat(comp.id)
			h.queue_free()
			v.add_child(UI.label({"ok": "已允许", "always": "已允许（以后不再询问）", "no": "已拒绝"}[status], 21, UI.MUTED))
		b_ok.pressed.connect(func():
			done.call("ok")
			_run_action(a))
		b_always.pressed.connect(func():
			done.call("always")
			store.settings.perms[device.cap_of(String(a.type))] = "allow"
			store.save_settings()
			_run_action(a))
		b_no.pressed.connect(func():
			done.call("no")
			creature.react("sad", "none", 2.5)
			show_bubble(["好吧……", "那就算啦。", "哼，不让就不让。"][rng.randi() % 3]))
	else:
		v.add_child(UI.label({"ok": "已允许", "always": "已允许（以后不再询问）", "no": "已拒绝"}.get(st, st), 21, UI.MUTED))
	return p

func _run_action(a: Dictionary) -> void:
	var res: Dictionary = device.execute(a)
	if res.ok:
		add_note("✓ " + String(res.msg))
		creature.react("happy", "nod", 2.5)
	else:
		add_note("✕ " + String(res.msg))
		creature.react("sad", "shrug", 3.0)
		show_bubble("唔……没办成：" + String(res.msg))

# ---------------------------------------------------------------- 触碰反应
func _on_touched(zone: String, kind: String) -> void:
	var comp = store.current()
	if comp == null:
		return
	last_input = _now()
	var st: Dictionary = comp.state
	var today := Time.get_date_string_from_system()
	if String(st.get("pets_day", "")) != today:
		st.pets_day = today
		st.pets_today = 0
		st.spam_today = 0
	var key := zone
	var ges := "none"
	match kind:
		"pet":
			key = "head"
			ges = "none"
			tasks.progress("pet")
			if int(st.pets_today) < 15:
				st.pets_today = int(st.pets_today) + 1
				if int(st.pets_today) % 3 == 0:
					st.affection = clampi(int(st.affection) + 1, 0, 100)
			creature.emote("heart")
		"double":
			ges = "jump"
		"carry":
			key = "carry"
			tasks.progress("carry")
		"drop":
			key = "drop"
		"spam":
			key = "spam"
			ges = "pout" if SP.archetype(comp.spec) in ["tsundere", "genki"] else "shake"
			if int(st.spam_today) < 5:
				st.spam_today = int(st.spam_today) + 1
				st.affection = clampi(int(st.affection) - 1, 0, 100)
		"wake":
			key = "wake"
			ges = "stretch"
		_:
			if zone == "hand":
				ges = "wave"
			elif zone == "body":
				ges = "none"
	if not key in SP.ZONES:
		key = "body"
	var line: Array = SP.touch_line(comp.spec, key, rng)
	var emo: String = line[1]
	if kind == "pet":
		emo = "love" if SP.archetype(comp.spec) in ["gentle", "genki", "playful", "lazy"] else emo
	creature.react(emo, ges, 3.5)
	show_bubble(String(line[0]), 3.0)
	if bool(store.settings.behavior.get("touch_voice", true)) and not voice.is_speaking():
		voice.speak(String(line[0]), comp.spec)
	if OS.get_name() == "Android" and kind in ["tap", "pet", "carry"]:
		Input.vibrate_handheld(18)
	_refresh_top()

# ---------------------------------------------------------------- 主动互动
func ai_proactive_allowed() -> bool:
	var now := _now()
	_ai_pro_times = _ai_pro_times.filter(func(x): return now - float(x) < 3600.0)
	if _ai_pro_times.size() >= int(store.settings.behavior.get("ai_per_hour", 3)):
		return false
	_ai_pro_times.append(now)
	return true

func _greet() -> void:
	var comp = store.current()
	if comp == null or screen != "chat" or busy:
		return
	var st: Dictionary = comp.state
	var since := _unix() - int(st.get("last_seen", _unix()))
	var today := Time.get_date_string_from_system()
	var reason := ""
	if store.chat_of(comp.id).is_empty():
		reason = "greet"
	elif since > 4 * 3600:
		reason = "return"
	elif String(st.get("last_greet_day", "")) != today:
		reason = "greet"
	st.last_seen = _unix()
	if reason == "":
		return
	st.last_greet_day = today
	busy = true
	brain.proactive(comp, reason, func(r: Dictionary):
		busy = false
		_proactive_reply(comp, r))

func _proactive_reply(comp: Dictionary, r: Dictionary) -> void:
	if store.current() != comp or screen != "chat":
		return
	var say := String(r.say)
	add_msg({"role": "assistant", "text": say, "emo": r.emotion, "raw": String(r.get("raw", ""))})
	creature.wake()
	creature.react(String(r.emotion), String(r.gesture), 5.0)
	show_bubble(say)
	voice.speak(say, comp.spec)
	store.save_companions()

func _tick_chat(_delta: float) -> void:
	var comp = store.current()
	if comp == null or busy or modal != null:
		return
	var b: Dictionary = store.settings.behavior
	var idle := _now() - last_input
	var pm := int(b.get("proactive_min", 8))
	if pm > 0 and idle > pm * 60.0 and _now() - last_proactive > pm * 60.0 and not voice.is_speaking() and not voice.call_mode:
		last_proactive = _now()
		busy = true
		brain.proactive(comp, "idle", func(r: Dictionary):
			busy = false
			_proactive_reply(comp, r))
		return
	var sm := int(b.get("sleep_min", 20))
	if sm > 0 and idle > sm * 60.0 and not creature.sleeping and not voice.call_mode:
		creature.go_sleep()

func _on_task_done(it: Dictionary) -> void:
	var comp = store.current()
	if comp == null:
		return
	comp.state.affection = clampi(int(comp.state.affection) + 3, 0, 100)
	_refresh_top()
	if screen != "chat":
		return
	add_note("★ 完成任务：%s（好感 +3）" % tasks.label(it, comp.spec.name))
	creature.react("excited", "cheer", 3.0)
	if not busy:
		busy = true
		brain.proactive(comp, "task_done", func(r: Dictionary):
			busy = false
			_proactive_reply(comp, r), tasks.label(it, comp.spec.name))

# ---------------------------------------------------------------- 语音按钮
func _mic_pressed() -> void:
	last_input = _now()
	if voice.recording:
		voice.stop_listen(true)
		return
	if not voice.can_listen():
		toast("可以点输入框，用输入法键盘上的话筒说话；或去设置里开启“语音识别”")
		if input != null:
			input.grab_focus()
		return
	voice.start_listen()

func _call_pressed() -> void:
	last_input = _now()
	if voice.call_mode:
		voice.set_call_mode(false)
		creature.react("happy", "wave", 2.0)
	else:
		if not voice.can_listen():
			toast("通话模式需要先在设置里开启“语音识别”API")
			return
		voice.set_call_mode(true)
		creature.wake()
		creature.react("happy", "nod", 2.0)
		show_bubble("我在听，说吧~", 2.5)
	_update_voice_btns()
	_refresh_top()

func _update_voice_btns() -> void:
	if mic_btn == null or not is_instance_valid(mic_btn):
		return
	mic_btn.icon_kind = "stop" if voice.recording else "mic"
	mic_btn.pulse = voice.recording
	mic_btn.queue_redraw()
	call_btn.pulse = voice.call_mode
	call_btn.queue_redraw()

func _on_listen_state(state: String, info: String) -> void:
	_update_voice_btns()
	match state:
		"recording":
			if creature != null:
				creature.react("happy", "none", 2.0)
		"processing":
			if creature != null:
				creature.react("thinking", "none", 4.0)
		"error":
			toast(info)
			if voice.call_mode and info.find("权限") >= 0:
				voice.set_call_mode(false)
	_refresh_top()

var _pending_voice := ""
func _on_heard(text: String) -> void:
	tasks.progress("voice")
	if screen != "chat":
		return
	if busy:
		_pending_voice = text
		return
	send_text(text)

func notify_voice_error(t: String) -> void:
	toast(t)

# ================================================================== 今日任务
func _tasks_popup() -> void:
	var comp = store.current()
	if comp == null:
		return
	var v := _modal("今日任务")
	var dc: Array = tasks.done_count()
	v.add_child(UI.label("已完成 %d/%d · 连续完成 %d 天 · 每完成一个好感 +3" % [dc[0], dc[1], tasks.streak()], 22, UI.MUTED, true))
	for it in tasks.list():
		var row := UI.hb(12)
		var done: bool = it.done
		var mark := UI.label("✓" if done else "○", 30, UI.GOOD if done else UI.MUTED)
		row.add_child(mark)
		var txt: String = tasks.label(it, comp.spec.name)
		if int(it.goal) > 1 and not done:
			txt += "（%d/%d）" % [int(it.n), int(it.goal)]
		var l := UI.label(txt, 24, UI.MUTED if done else UI.TXT, true)
		row.add_child(l)
		if not done and String(it.kind) == "life":
			var tid := String(it.id)
			row.add_child(UI.btn("完成了", func():
				tasks.complete(tid)
				close_modal()
				_tasks_popup(), "primary", 22))
		v.add_child(row)
	v.add_child(UI.gap(6))
	if llm.has_chat():
		v.add_child(UI.btn("让%s给我出个新任务（AI）" % comp.spec.name, func():
			close_modal()
			add_note("正在请%s出题…" % comp.spec.name)
			brain.gen_task(comp, func(res, err: String):
				if res == null:
					add_note("出题失败：" + err)
					return
				tasks.add_custom(String(res.task))
				add_msg({"role": "assistant", "text": String(res.say) if String(res.say) != "" else "新任务：" + String(res.task), "emo": String(res.emotion)})
				creature.react(String(res.emotion) if String(res.emotion) in SP.EMOTIONS else "happy", "point", 3.0)
				show_bubble(String(res.say))
				voice.speak(String(res.say), comp.spec)
				_refresh_top()), "ghost", 23))

# ================================================================== 教程 / 客服 / 签到
const QQ_SERVICE := "2718825738"

func _first_run() -> void:
	store.settings.seen_intro = true
	store.save_settings()
	var v := _modal("欢迎来到桌宠物语")
	v.add_child(UI.label("• 摸头、戳戳、长按拎起来，它都会有反应\n• 设置里填好 AI Key，它就会变聪明\n• 想要桌面陪伴：设置里打开“桌面悬浮”\n• 每天来签到一次，好感会慢慢涨", 24, UI.TXT, true))
	var r := UI.hb(12)
	r.add_child(UI.btn("看使用教程", func():
		close_modal()
		show_screen("help"), "primary", 24))
	r.add_child(UI.btn("先玩玩", func(): close_modal(), "ghost", 24))
	v.add_child(r)

func _support_popup() -> void:
	var v := _modal("联系客服")
	v.add_child(UI.label("遇到问题、想提建议、Key 不会填，都可以找客服。\n客服 QQ：%s\n客服一般在晚上回复，请留言说明问题，附上截图会更快。" % QQ_SERVICE, 24, UI.TXT, true))
	var r := UI.hb(12)
	r.add_child(UI.btn("复制客服 QQ", func():
		DisplayServer.clipboard_set(QQ_SERVICE)
		toast("已复制客服 QQ：" + QQ_SERVICE), "primary", 24))
	r.add_child(UI.btn("打开 QQ 聊天", func():
		DisplayServer.clipboard_set(QQ_SERVICE)
		OS.shell_open("mqqwpa://im/chat?chat_type=wpa&uin=%s&version=1" % QQ_SERVICE)
		toast("已复制 QQ 号，没跳转的话请到 QQ 里搜索添加"), "ghost", 24))
	v.add_child(r)

func _checkin() -> void:
	var comp = store.current()
	if comp == null:
		return
	var st: Dictionary = comp.state
	var today := Time.get_date_string_from_system()
	var ck: Dictionary = st.get("checkin", {})
	if typeof(ck) != TYPE_DICTIONARY:
		ck = {}
	var last := String(ck.get("day", ""))
	var streak := int(ck.get("streak", 0))
	var nm: String = comp.spec.name
	if last == today:
		toast("今天已经签到过啦，连续 %d 天" % streak)
		creature.react("smug", "nod", 2.5)
		show_bubble("今天已经签过啦～明天再来哦！")
		return
	var yest := Time.get_date_string_from_unix_time(_unix() - 86400)
	streak = streak + 1 if last == yest else 1
	ck = {"day": today, "streak": streak, "total": int(ck.get("total", 0)) + 1}
	st.checkin = ck
	var gain := 2 + mini_bonus(streak)
	st.affection = clampi(int(st.affection) + gain, 0, 100)
	store.save_companions()
	var lines := ["签到成功！%s 好开心～" % nm, "又见面啦，今天也要一起加油！", "连续陪伴 %d 天了，%s 最喜欢你了！" % [streak, nm]]
	var say: String = lines[mini_bonus(streak) if mini_bonus(streak) < 3 else 2]
	creature.react("love" if streak >= 3 else "happy", "cheer", 4.0)
	show_bubble(say)
	voice.speak(say, comp.spec)
	toast("签到成功 · 连续 %d 天 · 好感 +%d" % [streak, gain])
	_refresh_top()

func mini_bonus(streak: int) -> int:
	return mini(streak / 3, 3)

func _help_card(parent: Control, title: String, body: String) -> void:
	var s := _section(parent, title)
	s.add_child(UI.label(body, 23, UI.TXT, true))

func _build_help() -> void:
	var body := _scroll_page("使用教程", "chat" if not store.companions.is_empty() else "welcome")
	_help_card(body, "1. 快速上手", "• 点“创造我的伙伴”，写一句话描述它的样子，或者直接选“先认识团子”。\n• 在聊天页打字或点麦克风和它说话。\n• 摸头、戳一戳、长按拎起来，它都会有不同反应。\n• 底部小按钮：每日签到、今日任务、讲笑话、猜谜、跳舞。")
	_help_card(body, "2. 让它变聪明（填 AI Key）", "设置 → AI 服务 → 填写 Key：填 DeepSeek Key（聊天）和阿里云百炼 Key（声音、听写、立绘、陪看），点“保存并测试”。不填也能用离线模式，但回答会简单。\nKey 只加密保存在你的设备上。想接别的平台或中转站：设置 → AI 服务 → 高级自定义。")
	_help_card(body, "2.5 它是活的", "它会饿、会困，偶尔还会生病，关掉 App 时也在慢慢变化。饿了点“喂食”，生病了点“照顾”，好感也会慢慢涨。")
	_help_card(body, "3. 精致二次元立绘", "进“伙伴详情页”，在“立绘要求”里写想要的样子（发色、衣服、气质），点“精致立绘”，等一分钟左右就会换成二次元角色。点“生成多表情”可以让它有更多表情。\n需要阿里云百炼的 Key（设置 → AI 画像）。")
	_help_card(body, "4. 桌面悬浮", "设置里打开“桌面悬浮”，按提示允许“显示在其他应用上层”。之后它会站在桌面上，可以拖动、点它聊天。立绘更新后需要关掉悬浮再打开。")
	_help_card(body, "5. 语音", "设置 → 语音合成：选阿里云并填百炼 Key，它就会用好听的声音说话；不填就用系统语音。\n麦克风按钮可语音输入。")
	_help_card(body, "6. 屏幕陪看（实验）", "设置里打开“屏幕陪看”，在悬浮窗点“陪看”并允许录屏，它会像坐在你旁边一样看着屏幕并自己搭话。银行、支付等页面系统会自动拦住。随时点“看着”可停止。")
	_help_card(body, "7. 常见问题", "• 语音/画图报“Arrearage / Access denied”：阿里云账户欠费，充值即可。\n• 报 404 / Model not exist：模型名不对，通常不用管，程序会自动换。\n• 悬浮没出现：检查“显示在其他应用上层”权限，并关闭省电限制。\n• 数据丢了？只要覆盖安装，聊天记录和设置都会保留。")
	var s := _section(body, "联系客服")
	s.add_child(UI.label("客服 QQ：%s（晚上回复）" % QQ_SERVICE, 24, UI.TXT, true))
	s.add_child(UI.btn("联系客服", func(): _support_popup(), "primary", 26))

# ================================================================== 生物特性（会饿、会困、会生病）
var _life_t := 0.0

func _apply_body_look(comp: Dictionary) -> void:
	if creature == null:
		return
	var st: Dictionary = comp.state
	creature.base_emotion = LIFE.base_emotion(st)
	creature.walk_speed = 70.0 if bool(LIFE.body(st).sick) else 110.0
	if creature.emo_timer <= 0.0:
		creature.emotion = creature.base_emotion

func _life_tick(delta: float) -> void:
	_life_t += delta
	if _life_t < 10.0:
		return
	var dt := _life_t
	_life_t = 0.0
	var comp = store.current()
	if comp == null or creature == null:
		return
	var before := LIFE.status_text(comp.state)
	var ev: String = LIFE.tick(comp.state, dt, creature.sleeping, rng)
	LIFE.body(comp.state).t = _unix()
	if ev != "":
		_life_event(comp, ev)
		store.save_companions()
		return
	var now_s := LIFE.status_text(comp.state)
	if now_s == before:
		return
	_apply_body_look(comp)
	_refresh_top()
	if screen != "chat" or voice.is_speaking():
		return
	var b: Dictionary = LIFE.body(comp.state)
	if float(b.hunger) < 40.0 and before.find("饿") < 0:
		show_bubble("肚子咕咕叫了……可以喂我吃点东西吗？")
	elif float(b.energy) < 30.0 and before.find("困") < 0 and before.find("累") < 0:
		show_bubble("呼啊……有点困了……")

func _life_resume() -> void:
	var comp = store.current()
	if comp == null:
		return
	var ev: String = LIFE.catch_up(comp.state, _unix(), rng)
	if ev != "":
		_life_event(comp, ev)
	else:
		_apply_body_look(comp)
		_refresh_top()
	store.save_companions()

func _life_event(comp: Dictionary, ev: String) -> void:
	_apply_body_look(comp)
	_refresh_top()
	if screen != "chat":
		return
	if ev == "sick":
		creature.react("sad", "none", 5.0)
		var s1 := "咳咳……我好像有点不舒服……可以照顾我一下吗？"
		show_bubble(s1)
		voice.speak(s1, comp.spec)
		add_note("%s 生病了。点“照顾”和“喂食”能帮它好起来。" % comp.spec.name)
	elif ev == "recover":
		creature.react("happy", "jump", 4.0)
		show_bubble("我感觉好多啦！")

func _body_react(comp: Dictionary, r: Dictionary) -> void:
	_apply_body_look(comp)
	creature.react(String(r.emo), String(r.ges), 4.0)
	show_bubble(String(r.say))
	voice.speak(String(r.say), comp.spec)
	_refresh_top()

# 喂食 / 照顾：每天前 4 次加一点好感（防刷）
func _care_affection(comp: Dictionary) -> void:
	var st: Dictionary = comp.state
	var today := Time.get_date_string_from_system()
	if String(st.get("care_day", "")) != today:
		st.care_day = today
		st.care_n = 0
	if int(st.get("care_n", 0)) < 4:
		st.care_n = int(st.get("care_n", 0)) + 1
		st.affection = clampi(int(st.affection) + 1, 0, 100)

func _feed() -> void:
	var comp = store.current()
	if comp == null:
		return
	var r: Dictionary = LIFE.feed(comp.state)
	if bool(r.ok):
		_care_affection(comp)
	store.save_companions()
	_body_react(comp, r)

func _care() -> void:
	var comp = store.current()
	if comp == null:
		return
	var r: Dictionary = LIFE.care(comp.state)
	_care_affection(comp)
	store.save_companions()
	_body_react(comp, r)
	if bool(r.get("cured", false)):
		add_note("%s 的病好了" % comp.spec.name)

# ================================================================== 舞台背景（默认天空 / 自定义图片）
func _apply_stage_bg() -> void:
	if stage == null or not is_instance_valid(stage):
		return
	var sg: Dictionary = store.settings.get("stage", {})
	if String(sg.get("mode", "sky")) == "image":
		var p := String(sg.get("img", ""))
		var img := Image.load_from_file(p) if p != "" and FileAccess.file_exists(p) else null
		if img != null and not img.is_empty():
			stage.set_background("image", ImageTexture.create_from_image(img))
			return
	stage.set_background("sky", null)

func _set_stage_image(img: Image) -> void:
	var p := "%s/stage_bg.png" % store.DIR
	img.save_png(p)
	store.settings.stage = {"mode": "image", "img": p}
	store.save_settings()
	_apply_stage_bg()

func _pick_stage_image() -> void:
	DisplayServer.file_dialog_show("选择背景图片", "", "", false, DisplayServer.FILE_DIALOG_MODE_OPEN_FILE, PackedStringArray(["*.png,*.jpg,*.jpeg,*.webp;图片"]), func(ok: bool, paths: PackedStringArray, _f: int):
		if not ok or paths.is_empty():
			return
		var im := Image.load_from_file(paths[0])
		if im == null or im.is_empty():
			toast("读取图片失败，换一张试试")
			return
		var mx: int = maxi(im.get_width(), im.get_height())
		if mx > 1600:
			var sc := 1600.0 / float(mx)
			im.resize(int(im.get_width() * sc), int(im.get_height() * sc), Image.INTERPOLATE_LANCZOS)
		_set_stage_image(im)
		toast("背景已更换"))

func _gen_stage_ai() -> void:
	if not llm.has_img():
		toast("AI 生成背景需要阿里云 Key（设置→AI 服务→填写 Key）", 4.0)
		return
	if art_busy:
		toast("正在生成中，请稍等")
		return
	var v := _modal("AI 生成背景", 620.0)
	v.add_child(UI.label("写一句你想要的场景，AI 会画一张竖版背景（约 30~60 秒）。", 22, UI.MUTED, true))
	var te := UI.te("例如：黄昏的海边，暖色的天空，温柔治愈的插画风", "", 120)
	v.add_child(te)
	v.add_child(UI.btn("开始生成", func():
		var desc := te.text.strip_edges()
		if desc == "":
			toast("先写一句场景描述")
			return
		close_modal()
		art_busy = true
		toast("正在生成背景…可以先去聊天", 5.0)
		var prompt := desc + "。竖版手机壁纸，风景background，治愈插画风格，柔和光影，画面干净，不要人物，不要文字。"
		var r: Dictionary = await _wait_call(func(cb): llm.image(prompt, cb, true))
		art_busy = false
		if not r.ok or r.img == null:
			toast("生成失败：" + String(r.err), 6.0)
			return
		_set_stage_image(r.img as Image)
		toast("背景已换成 AI 生成的啦", 4.0), "primary"))

# ================================================================== 发图片给 AI 看
func _pick_chat_image() -> void:
	if busy:
		return
	DisplayServer.file_dialog_show("选择图片发给伙伴", "", "", false, DisplayServer.FILE_DIALOG_MODE_OPEN_FILE, PackedStringArray(["*.png,*.jpg,*.jpeg,*.webp;图片"]), func(ok: bool, paths: PackedStringArray, _f: int):
		if not ok or paths.is_empty():
			return
		var im := Image.load_from_file(paths[0])
		if im == null or im.is_empty():
			toast("读取图片失败")
			return
		_send_image(im))

func _send_image(img: Image) -> void:
	var comp = store.current()
	if comp == null or busy:
		return
	if not llm.has_vision():
		toast("看图需要视觉模型 Key：设置→AI 服务里填好阿里云 Key 即可", 5.0)
		return
	var note := input.text.strip_edges() if input != null and is_instance_valid(input) else ""
	if input != null and is_instance_valid(input):
		input.text = ""
	var p := "%s/sent_%d.png" % [store.DIR, _unix()]
	img.save_png(p)
	add_msg({"role": "image", "path": p, "text": note})
	last_input = _now()
	creature.wake()
	busy = true
	creature.react("thinking", "none", 30.0)
	_show_typing(true)
	var ask := "你是用户的电子伙伴「%s」，性格：%s。用你的口吻、简短自然地回应用户发来的这张图片（1~3 句话，不要像在描述图片，而像朋友看到后的反应）。" % [comp.spec.name, String(comp.spec.personality.desc)]
	if note != "":
		ask += "用户还说：" + note
	llm.vision_chat(img, ask, func(ok: bool, text: String, err: String):
		busy = false
		_show_typing(false)
		if store.current() != comp:
			return
		if not ok:
			add_note("看图失败：" + err)
			creature.react("sad", "none", 3.0)
			return
		add_msg({"role": "assistant", "text": text, "emo": "happy"})
		creature.react("happy", "none", 5.0)
		show_bubble(text)
		voice.speak(text, comp.spec))

# ================================================================== 复制聊天
func _copyable(p: Control, txt: String) -> void:
	p.mouse_filter = Control.MOUSE_FILTER_PASS
	p.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed and ev.double_click:
			DisplayServer.clipboard_set(txt)
			toast("已复制这条消息"))

func _copy_chat() -> void:
	var comp = store.current()
	if comp == null:
		return
	var lines: Array = []
	for m in store.chat_of(comp.id):
		var role := String(m.get("role", ""))
		var t := String(m.get("text", "")).strip_edges()
		if t == "":
			continue
		if role == "user":
			lines.append("我：" + t)
		elif role == "assistant":
			lines.append("%s：%s" % [comp.spec.name, t])
	if lines.is_empty():
		toast("还没有聊天记录")
		return
	DisplayServer.clipboard_set("\n".join(lines))
	toast("已复制 %d 条聊天记录" % lines.size())

# ================================================================== 弹窗 / 提示
func _modal(title: String, width := 640.0) -> VBoxContainer:
	close_modal()
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	top_root.add_child(dim)
	modal = dim
	dim.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
			close_modal())
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dim.add_child(cc)
	var p := UI.panel(UI.PANEL, 28, 26)
	var vs := get_viewport_rect().size
	p.custom_minimum_size.x = minf(width, vs.x - 40.0)
	p.mouse_filter = Control.MOUSE_FILTER_STOP
	cc.add_child(p)
	var outer := UI.vb(14)
	p.add_child(outer)
	var hd := UI.hb(10)
	var tl := UI.title(title, 30)
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hd.add_child(tl)
	hd.add_child(UI.icon_btn("close", func(): close_modal(), 56, "flat"))
	outer.add_child(hd)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.custom_minimum_size.y = 0
	var v := UI.vb(14)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(v)
	outer.add_child(sc)
	v.resized.connect(func():
		sc.custom_minimum_size.y = minf(v.get_combined_minimum_size().y, vs.y * 0.7))
	return v

func close_modal() -> void:
	if modal != null and is_instance_valid(modal):
		modal.queue_free()
	modal = null

func toast(t: String, secs := 3.2) -> void:
	var p := UI.panel(Color("#33385c"), 20, 16)
	var l := UI.label(t, 23, UI.TXT, false, HORIZONTAL_ALIGNMENT_CENTER)
	var vs := get_viewport_rect().size
	var maxw := vs.x - 80.0
	var tw := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, 23).x + 8.0
	if tw > maxw:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = maxw
	p.add_child(l)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_root.add_child(p)
	p.reset_size()
	await get_tree().process_frame
	if not is_instance_valid(p):
		return
	var sz := p.get_combined_minimum_size()
	p.size = sz
	p.position = Vector2((vs.x - sz.x) * 0.5, vs.y * 0.12)
	p.modulate.a = 0.0
	var tw2 := create_tween()
	tw2.tween_property(p, "modulate:a", 1.0, 0.2)
	tw2.tween_interval(secs)
	tw2.tween_property(p, "modulate:a", 0.0, 0.4)
	tw2.tween_callback(p.queue_free)

func _confirm(title: String, msg: String, ok_text: String, cb: Callable, danger := true) -> void:
	var v := _modal(title, 560.0)
	v.add_child(UI.label(msg, 24, UI.TXT, true))
	var h := UI.hb(12)
	h.add_child(UI.grow(UI.btn("取消", func(): close_modal(), "ghost")))
	h.add_child(UI.grow(UI.btn(ok_text, func():
		close_modal()
		cb.call(), "danger" if danger else "primary")))
	v.add_child(h)

# ================================================================== 创建 / 修改外形
func _build_create() -> void:
	var editing := cr_edit_id != ""
	var body := _scroll_page("修改外形" if editing else "创造你的伙伴", "profile" if editing else ("chat" if not store.companions.is_empty() else "welcome"))
	var holder := StageScript.new()
	holder.custom_minimum_size = Vector2(0, 400)
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var hp := UI.panel(UI.PANEL, 24, 0)
	hp.clip_contents = true
	hp.add_child(holder)
	body.add_child(hp)
	cr_preview = CR.new()
	cr_preview.font = font
	cr_preview.wander = false
	holder.add_child(cr_preview)
	holder.resized.connect(func():
		if is_instance_valid(cr_preview):
			cr_preview.position = Vector2(holder.size.x * 0.5, holder.ground_y())
			cr_preview.home_y = cr_preview.position.y
			cr_preview.x_min = cr_preview.position.x
			cr_preview.x_max = cr_preview.position.x
			cr_preview.scale = Vector2.ONE * clampf(holder.size.y / 320.0, 0.8, 1.4))
	if cr_spec.is_empty():
		var tmp := SP.default_spec()
		tmp.name = "？"
		tmp.colors.main = "#c9c6e6"
		cr_preview.set_spec(tmp)
		cr_preview.modulate = Color(1, 1, 1, 0.55)
	else:
		cr_preview.set_spec(cr_spec)
	var s1 := _section(body, "" if editing else "描述你想要的伙伴")
	var desc := UI.te("外形、性格、说话方式……越具体越好。\n例如：银色短发的猫耳少年，有点傲娇，说话句尾带“喵”，喜欢晒太阳。", "", 170)
	if not editing:
		s1.add_child(desc)
		var fl := HFlowContainer.new()
		fl.add_theme_constant_override("h_separation", 8)
		fl.add_theme_constant_override("v_separation", 8)
		for ex in ["银发猫耳少女，傲娇，说话带喵", "元气满满的小柴犬", "会讲冷笑话的仙人掌", "毒舌但很关心你的马克杯", "温柔的白龙爷爷", "害羞的粉色史莱姆", "高冷的机器人管家", "爱唱歌的向日葵"]:
			var e: String = ex
			fl.add_child(UI.btn(e, func(): desc.text = e, "chip"))
		s1.add_child(fl)
		var nm := UI.le("名字（可不填，让 AI 起）")
		s1.add_child(nm)
		var h := UI.hb(12)
		var gb := UI.btn("AI 生成" if llm.has_chat() else "生成（离线简单版）", Callable(), "primary", 27)
		gb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(gb)
		h.add_child(UI.btn("随机", func():
			var picks := ["银发猫耳少女，傲娇，说话带喵", "元气满满的小柴犬", "会讲冷笑话的仙人掌", "毒舌但很关心你的马克杯", "温柔的白色龙", "害羞的粉色史莱姆", "高冷的机器人", "调皮的小狐狸", "慵懒的熊猫", "爱哭的小幽灵", "紫色长发的魔法少女", "憨憨的企鹅", "蘑菇精灵", "戴眼镜的程序员男孩", "会发光的星星"]
			desc.text = picks[rng.randi() % picks.size()], "ghost"))
		s1.add_child(h)
		var hint := UI.hint("AI 生成大约消耗 1500~3000 tokens，费用由你的 API 账户支付。" if llm.has_chat() else "现在没有设置 AI Key，会按关键词离线生成（简单版）。去设置里填 Key 可以生成更贴合描述的伙伴。")
		s1.add_child(hint)
		if llm.has_img():
			s1.add_child(UI.tog("同时用 AI 画一张精致的动漫立绘当形象（约 1 分钟，按画像接口计费）", cr_art_on, func(on: bool): cr_art_on = on))
		else:
			s1.add_child(UI.hint("想要精致的动漫立绘形象：先在设置 → AI 画像里填好阿里云 Key，之后可在伙伴详情页点“精致立绘”。"))
		gb.pressed.connect(func():
			if cr_busy:
				return
			var d := desc.text.strip_edges()
			if d == "":
				toast("先写一句描述吧~")
				return
			cr_desc = d
			cr_busy = true
			gb.disabled = true
			gb.text = "正在生成…（约 10~40 秒）" if llm.has_chat() else "生成中…"
			cr_preview.react("thinking", "think", 30.0)
			brain.generate(d, nm.text, func(spec: Dictionary, note: String):
				cr_busy = false
				if not is_instance_valid(gb):
					return
				gb.disabled = false
				gb.text = "重新生成" if llm.has_chat() else "重新生成（离线）"
				if note != "":
					toast(note, 4.0)
				_set_cr_spec(spec)
				cr_preview.react("happy", "wave", 3.0)))
	cr_info = UI.vb(14)
	body.add_child(cr_info)
	if not cr_spec.is_empty():
		_fill_cr_info()

func _set_cr_spec(spec: Dictionary) -> void:
	cr_spec = spec
	if is_instance_valid(cr_preview):
		cr_preview.modulate = Color.WHITE
		cr_preview.set_spec(spec)
	_fill_cr_info()

func _fill_cr_info() -> void:
	if cr_info == null or not is_instance_valid(cr_info):
		return
	for ch in cr_info.get_children():
		ch.queue_free()
	var s: Dictionary = cr_spec
	var p: Dictionary = s.personality
	var card := _section(cr_info, "%s · %s" % [s.name, s.label])
	card.add_child(UI.label("性格：%s（%s）" % [p.desc, SP.ARCH_CN.get(p.archetype, "")], 23, UI.TXT, true))
	card.add_child(UI.label("说话：%s%s" % [p.speech, ("　口头禅：" + "、".join(p.catchphrases)) if not p.catchphrases.is_empty() else ""], 23, UI.TXT, true))
	if not p.likes.is_empty():
		card.add_child(UI.label("喜欢：%s　讨厌：%s" % ["、".join(p.likes), "、".join(p.dislikes)], 23, UI.MUTED, true))
	var vrow := UI.hb(10)
	vrow.add_child(UI.btn("试听声音", func():
		var g: Array = s.lines.get("greet", [])
		var line := String(g[0]) if not g.is_empty() else "你好呀，我是%s。" % s.name
		voice.speak(line, s)
		if is_instance_valid(cr_preview):
			cr_preview.set_speaking(true)
			get_tree().create_timer(2.5).timeout.connect(func():
				if is_instance_valid(cr_preview):
					cr_preview.set_speaking(false)), "ghost", 23))
	for e in [["开心", "happy", "jump"], ["害羞", "shy", "none"], ["生气", "angry", "pout"], ["挥手", "happy", "wave"], ["跳舞", "excited", "dance"]]:
		var ee: Array = e
		vrow.add_child(UI.btn(String(ee[0]), func():
			if is_instance_valid(cr_preview):
				cr_preview.react(ee[1], ee[2], 2.5), "chip"))
	var vsc := ScrollContainer.new()
	vsc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vsc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	vsc.custom_minimum_size.y = 72
	vsc.add_child(vrow)
	card.add_child(vsc)
	# 一句话修改
	var ed := _section(cr_info, "用一句话修改")
	var eh := UI.hb(10)
	var el := UI.le("例如：耳朵换成狐狸耳朵，眼睛改成金色，加一顶巫师帽")
	eh.add_child(el)
	var eb := UI.btn("修改", Callable(), "primary", 24)
	eh.add_child(eb)
	ed.add_child(eh)
	eb.pressed.connect(func():
		if cr_busy or el.text.strip_edges() == "":
			return
		cr_busy = true
		eb.disabled = true
		eb.text = "修改中…"
		brain.edit(cr_spec, el.text, func(spec: Dictionary, note: String):
			cr_busy = false
			if note != "":
				toast(note, 4.0)
			_set_cr_spec(spec)))
	# 手动微调
	var mt := _section(cr_info, "手动微调（不花 token）")
	_build_tweaks(mt)
	var done := UI.btn("就是它了！" if cr_edit_id == "" else "保存外形", func(): _finish_create(), "primary", 30)
	done.custom_minimum_size.y = 84
	cr_info.add_child(done)

const CN := {"none": "无", "humanoid": "人形", "animal": "动物", "plant": "植物", "object": "物品", "blob": "软软的生物",
	"mug": "马克杯", "phone": "手机", "book": "书", "lamp": "台灯", "box": "纸箱", "ball": "球", "star": "星星", "heart": "爱心", "cloud": "云朵", "robot": "机器人",
	"teapot": "茶壶", "cake": "蛋糕", "potato": "土豆", "rock": "石头", "gem": "宝石", "bottle": "瓶子", "toast": "吐司", "pudding": "布丁",
	"flower": "花", "sprout": "嫩芽", "cactus": "仙人掌", "mushroom": "蘑菇", "tree": "树", "sunflower": "向日葵", "leafy": "绿叶", "tulip": "郁金香",
	"slime": "史莱姆", "ghost": "幽灵", "spirit": "小精灵", "fish": "鱼", "jelly": "水母", "marshmallow": "棉花糖",
	"short": "短发", "long": "长发", "bob": "波波头", "twintails": "双马尾", "ponytail": "马尾", "spiky": "刺猬头", "bun": "丸子头", "messy": "凌乱", "curly": "卷发", "side": "侧分", "fluffy": "蓬松",
	"tshirt": "T恤", "dress": "裙子", "hoodie": "卫衣", "suit": "制服", "robe": "长袍", "armor": "盔甲", "overalls": "背带裤", "kimono": "和服", "apron": "围裙", "sweater": "毛衣",
	"human": "人耳", "cat": "猫", "dog": "狗", "fox": "狐狸", "rabbit": "兔子", "bear": "熊", "elf": "精灵", "mouse": "老鼠", "floppy": "垂耳", "fin": "鳍",
	"dragon": "龙", "devil": "恶魔", "squirrel": "松鼠", "small": "小角", "curved": "弯角", "unicorn": "独角", "antlers": "鹿角",
	"bird": "羽翼", "bat": "蝙蝠翼", "fairy": "妖精翼", "angel": "天使翼", "butterfly": "蝴蝶翼",
	"cap": "鸭舌帽", "beret": "贝雷帽", "witch": "巫师帽", "crown": "皇冠", "bow": "蝴蝶结", "tophat": "礼帽", "beanie": "毛线帽", "headphones": "耳机", "halo": "光环", "leaf": "叶子",
	"round": "圆", "square": "方", "sun": "墨镜", "monocle": "单片镜", "scarf": "围巾", "bowtie": "领结", "collar": "项圈", "necklace": "项链", "bell": "铃铛", "tie": "领带",
	"anime": "动漫大眼", "sleepy": "困困眼", "dot": "豆豆眼", "sparkle": "星星眼", "sharp": "锐利", "button": "纽扣眼", "gentle": "眯眯眼",
	"smile": "微笑", "fang": "小虎牙", "beak": "鸟嘴", "stripes": "条纹", "dots": "斑点", "belly": "肚皮", "scales": "鳞片", "plaid": "格子",
	"hearts": "爱心", "glow": "光晕", "snow": "雪花", "fire": "火苗", "notes": "音符", "bubbles": "泡泡", "petals": "花瓣"}

func _tweak_row(parent: Control, label: String, opts: Array, getter: Callable, setter: Callable) -> void:
	var names := CN
	var h := UI.hb(8)
	var l := UI.label(label, 23, UI.MUTED)
	l.custom_minimum_size.x = 120
	h.add_child(l)
	var val := UI.label("", 23, UI.TXT, false, HORIZONTAL_ALIGNMENT_CENTER)
	val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var upd := func():
		val.text = names.get(String(getter.call()), String(getter.call()))
	upd.call()
	var step := func(d: int):
		var cur := String(getter.call())
		var i := opts.find(cur)
		i = (i + d + opts.size()) % opts.size()
		setter.call(opts[i])
		cr_spec = SP.normalize(cr_spec)
		cr_preview.set_spec(cr_spec)
		upd.call()
	h.add_child(UI.icon_btn("back", func(): step.call(-1), 52))
	h.add_child(val)
	h.add_child(UI.icon_btn("fwd", func(): step.call(1), 52))
	parent.add_child(h)

func _build_tweaks(parent: VBoxContainer) -> void:
	var s: Dictionary = cr_spec
	_tweak_row(parent, "身体", SP.PLANS, func(): return cr_spec.plan, func(v):
		cr_spec.plan = v
		cr_spec.kind = {"humanoid": "human", "animal": "cat", "plant": "flower", "object": "mug", "blob": "slime"}[v]
		if v == "humanoid" and cr_spec.hair.style == "none":
			cr_spec.hair.style = "short"
		if v == "humanoid" and cr_spec.outfit == "none":
			cr_spec.outfit = "tshirt")
	match String(s.plan):
		"object":
			_tweak_row(parent, "物品", SP.OBJECT_KINDS, func(): return cr_spec.kind, func(v): cr_spec.kind = v)
		"plant":
			_tweak_row(parent, "植物", SP.PLANT_KINDS, func(): return cr_spec.kind, func(v): cr_spec.kind = v)
		"blob":
			_tweak_row(parent, "种类", SP.BLOB_KINDS, func(): return cr_spec.kind, func(v): cr_spec.kind = v)
	if s.plan in ["humanoid", "animal"]:
		if s.plan == "humanoid":
			_tweak_row(parent, "发型", SP.HAIRS, func(): return cr_spec.hair.style, func(v): cr_spec.hair.style = v)
			_tweak_row(parent, "衣服", SP.OUTFITS, func(): return cr_spec.outfit, func(v): cr_spec.outfit = v)
		else:
			_tweak_row(parent, "花纹", SP.PATTERNS, func(): return cr_spec.body.pattern, func(v): cr_spec.body.pattern = v)
		_tweak_row(parent, "耳朵", SP.EARS, func(): return cr_spec.ears, func(v): cr_spec.ears = v)
		_tweak_row(parent, "尾巴", SP.TAILS, func(): return cr_spec.tail, func(v): cr_spec.tail = v)
		_tweak_row(parent, "翅膀", SP.WINGS, func(): return cr_spec.wings, func(v): cr_spec.wings = v)
		_tweak_row(parent, "角", SP.HORNS, func(): return cr_spec.horns, func(v): cr_spec.horns = v)
		_tweak_row(parent, "脖子", SP.NECKS, func(): return cr_spec.neck, func(v): cr_spec.neck = v)
		_tweak_row(parent, "眼镜", SP.GLASSES, func(): return cr_spec.glasses, func(v): cr_spec.glasses = v)
	_tweak_row(parent, "帽子", SP.HATS, func(): return cr_spec.hat, func(v): cr_spec.hat = v)
	_tweak_row(parent, "眼睛", SP.EYE_STYLES, func(): return cr_spec.eyes.style, func(v): cr_spec.eyes.style = v)
	_tweak_row(parent, "嘴巴", SP.MOUTHS, func(): return cr_spec.mouth, func(v): cr_spec.mouth = v)
	_tweak_row(parent, "特效", SP.AURAS, func(): return cr_spec.aura, func(v): cr_spec.aura = v)
	var swatches := ["#e8505b", "#f497b6", "#f39c4a", "#f4d35e", "#6cc070", "#4fd1c5", "#4a90e2", "#9b6ddf", "#2d2a32", "#f5f3ef", "#9aa0ac", "#8b5e3c", "#f6e7c8", "#ffe0c8"]
	var keys := [["main", "主色"], ["second", "副色"], ["accent", "点缀"], ["eye", "眼睛"]]
	if s.plan == "humanoid":
		keys.insert(2, ["hair", "头发"])
		keys.append(["skin", "皮肤"])
	for kk in keys:
		var key: String = kk[0]
		parent.add_child(UI.label(String(kk[1]) + "颜色", 22, UI.MUTED))
		var fl := HFlowContainer.new()
		fl.add_theme_constant_override("h_separation", 8)
		fl.add_theme_constant_override("v_separation", 8)
		for sw in swatches:
			var col: String = sw
			var b := Button.new()
			b.custom_minimum_size = Vector2(52, 52)
			b.focus_mode = Control.FOCUS_NONE
			var selected: bool = String(cr_spec.colors.get(key, "")).to_lower() == col
			b.add_theme_stylebox_override("normal", UI.sb(Color(col), 26, 0, 4 if selected else 2, Color.WHITE if selected else UI.LINE))
			b.add_theme_stylebox_override("hover", UI.sb(Color(col).lightened(0.1), 26, 0, 3, Color.WHITE))
			b.add_theme_stylebox_override("pressed", UI.sb(Color(col), 26, 0, 4, Color.WHITE))
			b.pressed.connect(func():
				cr_spec.colors[key] = col
				cr_preview.set_spec(cr_spec)
				_fill_cr_info.call_deferred())
			fl.add_child(b)
		parent.add_child(fl)
	parent.add_child(UI.label("声音：音调 / 语速", 22, UI.MUTED))
	parent.add_child(UI.sld(0.5, 2.0, 0.05, float(s.voice.pitch), func(v: float): cr_spec.voice.pitch = v))
	parent.add_child(UI.sld(0.6, 1.6, 0.05, float(s.voice.rate), func(v: float): cr_spec.voice.rate = v))

func _finish_create() -> void:
	if cr_spec.is_empty():
		return
	voice.stop_speaking()
	if cr_edit_id != "":
		for c in store.companions:
			if c.id == cr_edit_id:
				c.spec = SP.normalize(cr_spec)
				store.save_companions()
		cr_edit_id = ""
		_apply_accent()
		show_screen("profile")
		return
	var newc: Dictionary = store.add_companion(cr_spec)
	var want_art: bool = cr_art_on and llm.has_img()
	var art_desc := cr_desc
	newc.state.art_desc = art_desc
	store.save_companions()
	cr_spec = {}
	_apply_accent()
	if want_art:
		_make_art(newc, art_desc)
	_greeted = false
	show_screen("chat")

# ================================================================== 伙伴列表
func _build_list() -> void:
	var body := _scroll_page("我的伙伴", "chat")
	var grid := HFlowContainer.new()
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 16)
	body.add_child(grid)
	var vs := get_viewport_rect().size
	var cw := clampf((vs.x - 48.0 - 16.0) / 2.0, 260.0, 340.0)
	if vs.x > 1100:
		cw = clampf((vs.x - 48.0 - 48.0) / 4.0, 260.0, 340.0)
	for c in store.companions:
		var comp: Dictionary = c
		var card := Button.new()
		card.focus_mode = Control.FOCUS_NONE
		card.custom_minimum_size = Vector2(cw, cw * 1.25)
		var cur: bool = comp.id == store.current_id
		card.add_theme_stylebox_override("normal", UI.sb(UI.CARD, 24, 0, 3 if cur else 0, UI.accent))
		card.add_theme_stylebox_override("hover", UI.sb(UI.CARD2, 24, 0, 3 if cur else 0, UI.accent))
		card.add_theme_stylebox_override("pressed", UI.sb(UI.accent.darkened(0.3), 24, 0))
		var cr2 := CR.new()
		cr2.font = font
		cr2.set_spec(comp.spec)
		_apply_art(cr2, comp)
		cr2.wander = false
		cr2.position = Vector2(cw * 0.5, cw * 0.95)
		cr2.scale = Vector2.ONE * (cw / 330.0)
		cr2.x_min = cr2.position.x
		cr2.x_max = cr2.position.x
		cr2.home_y = cr2.position.y
		card.add_child(cr2)
		var nl := UI.title(comp.spec.name, 26)
		nl.position = Vector2(16, cw * 1.0)
		nl.size = Vector2(cw - 32, 36)
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		card.add_child(nl)
		var ll := UI.label(String(comp.spec.label).left(14), 19, UI.MUTED, false, HORIZONTAL_ALIGNMENT_CENTER)
		ll.position = Vector2(12, cw * 1.0 + 38)
		ll.size = Vector2(cw - 24, 28)
		ll.clip_text = true
		card.add_child(ll)
		card.pressed.connect(func():
			store.current_id = comp.id
			store.save_companions()
			_apply_accent()
			_greeted = false
			show_screen("chat"))
		grid.add_child(card)
	var add := Button.new()
	add.focus_mode = Control.FOCUS_NONE
	add.custom_minimum_size = Vector2(cw, cw * 1.25)
	add.add_theme_stylebox_override("normal", UI.sb(Color(0, 0, 0, 0), 24, 0, 3, UI.LINE))
	add.add_theme_stylebox_override("hover", UI.sb(Color(1, 1, 1, 0.04), 24, 0, 3, UI.MUTED))
	add.add_theme_stylebox_override("pressed", UI.sb(Color(1, 1, 1, 0.08), 24, 0, 3, UI.accent))
	add.text = "＋\n创造新伙伴"
	add.add_theme_font_size_override("font_size", 28)
	add.add_theme_color_override("font_color", UI.MUTED)
	add.pressed.connect(func():
		cr_edit_id = ""
		cr_spec = {}
		show_screen("create"))
	grid.add_child(add)
	body.add_child(UI.btn("导入伙伴码", func(): _import_dialog(), "ghost"))
	body.add_child(UI.hint("每个伙伴有自己独立的记忆、好感度和聊天记录。点卡片切换。"))

func _import_dialog() -> void:
	var v := _modal("导入伙伴码")
	v.add_child(UI.hint("把朋友分享给你的伙伴码（以 LB1: 开头）粘贴到下面。伙伴码只包含外形和性格，不含聊天记录和 Key。"))
	var t := UI.te("LB1:……", DisplayServer.clipboard_get() if DisplayServer.clipboard_get().find("LB1:") >= 0 else "", 160)
	v.add_child(t)
	v.add_child(UI.btn("导入", func():
		var spec = Store.parse_share_code(t.text)
		if spec == null:
			toast("伙伴码不对，检查一下有没有复制完整")
			return
		close_modal()
		store.add_companion(spec)
		_apply_accent()
		_greeted = false
		toast("导入成功：%s" % spec.name)
		show_screen("chat"), "primary"))

# ================================================================== 伙伴资料
func _build_profile() -> void:
	var comp = store.current()
	if comp == null:
		show_screen("welcome")
		return
	var s: Dictionary = comp.spec
	var p: Dictionary = s.personality
	var body := _scroll_page("%s 的资料" % s.name, "chat")
	var top_card := _section(body, "")
	var th := UI.hb(16)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(220, 240)
	var cr2 := CR.new()
	cr2.font = font
	cr2.set_spec(s)
	cr2.wander = false
	cr2.position = Vector2(110, 228)
	cr2.scale = Vector2.ONE * 0.78
	cr2.x_min = 110
	cr2.x_max = 110
	cr2.home_y = 228
	holder.add_child(cr2)
	th.add_child(holder)
	var info := UI.vb(8)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var aff := int(comp.state.get("affection", 25))
	info.add_child(UI.title(s.name, 34))
	info.add_child(UI.label(s.label, 22, UI.MUTED, true))
	info.add_child(UI.label("好感度 %d/100 · %s" % [aff, BrainScript.level_name(aff)], 22, UI.TXT))
	var pb := ProgressBar.new()
	pb.max_value = 100
	pb.value = aff
	pb.show_percentage = false
	pb.custom_minimum_size.y = 14
	pb.add_theme_stylebox_override("background", UI.sb(UI.FIELD, 7, 0))
	pb.add_theme_stylebox_override("fill", UI.sb(UI.accent, 7, 0))
	info.add_child(pb)
	var days := maxi(1, int((_unix() - int(comp.state.get("created", _unix()))) / 86400) + 1)
	info.add_child(UI.label("相识第 %d 天 · 记得 %d 件关于你的事" % [days, comp.state.memory.size()], 21, UI.MUTED))
	th.add_child(info)
	top_card.add_child(th)
	var f_art := UI.te("立绘要求，例如：黑色长发红瞳的成年犬耳少女，穿深紫色连帽外套，笑起来有点坏", String(comp.state.get("art_desc", "")), 110)
	top_card.add_child(UI.row("立绘要求", f_art))
	var bh := HFlowContainer.new()
	bh.add_theme_constant_override("h_separation", 10)
	bh.add_theme_constant_override("v_separation", 10)
	bh.add_child(UI.btn("修改外形", func():
		cr_edit_id = comp.id
		cr_spec = comp.spec.duplicate(true)
		show_screen("create"), "primary", 24))
	bh.add_child(UI.btn("复制伙伴码", func():
		DisplayServer.clipboard_set(Store.share_code(comp.spec))
		toast("伙伴码已复制，发给朋友就能导入（不含聊天和 Key）"), "ghost", 24))
	bh.add_child(UI.btn("精致立绘", func():
		comp.state.art_desc = f_art.text.strip_edges()
		store.save_companions()
		_make_art(comp, f_art.text), "primary", 24))
	bh.add_child(UI.btn("上传图片做立绘", func(): _pick_ref(comp), "primary", 24))
	bh.add_child(UI.btn("生成多表情", func(): _make_emotions(comp), "ghost", 24))
	bh.add_child(UI.btn("用回简笔形象", func():
		comp.state.art = {}
		store.save_companions()
		_art_refresh(comp)
		toast("已换回简笔形象"), "ghost", 24))
	bh.add_child(UI.btn("AI 画像", func(): _portrait(comp), "ghost", 24))
	top_card.add_child(bh)
	# 性格
	var ps := _section(body, "性格与说话方式")
	var f_name := UI.le("名字", s.name)
	ps.add_child(UI.row("名字", f_name))
	var f_label := UI.le("身份", s.label)
	ps.add_child(UI.row("身份", f_label))
	var f_desc := UI.te("性格描述", p.desc, 110)
	ps.add_child(UI.row("性格", f_desc))
	var f_speech := UI.le("说话方式", p.speech)
	ps.add_child(UI.row("说话方式", f_speech))
	var f_suffix := UI.le("如：喵（可空）", p.suffix)
	ps.add_child(UI.row("句尾口癖", f_suffix))
	var f_cp := UI.le("用逗号分隔", "，".join(p.catchphrases))
	ps.add_child(UI.row("口头禅", f_cp))
	var f_likes := UI.le("用逗号分隔", "，".join(p.likes))
	ps.add_child(UI.row("喜欢", f_likes))
	var f_dis := UI.le("用逗号分隔", "，".join(p.dislikes))
	ps.add_child(UI.row("讨厌", f_dis))
	var f_rel := UI.le("朋友 / 家人 / 搭档…", p.relation)
	ps.add_child(UI.row("你们的关系", f_rel))
	var f_call := UI.le("怎么称呼你", p.call_user)
	ps.add_child(UI.row("称呼你", f_call))
	var f_story := UI.te("来历", p.backstory, 100)
	ps.add_child(UI.row("来历", f_story))
	var trs := [["extravert", "外向"], ["warm", "温柔"], ["playful", "调皮"], ["sass", "毒舌"], ["independent", "独立（不顺从）"], ["curious", "好奇"], ["energy", "活力"]]
	for tr in trs:
		var k: String = tr[0]
		ps.add_child(UI.row(String(tr[1]), UI.sld(0, 1, 0.05, float(p.traits[k]), func(v: float): comp.spec.personality.traits[k] = v)))
	var vsec := _section(body, "声音")
	vsec.add_child(UI.seg([["female", "女声"], ["male", "男声"], ["neutral", "中性"]], s.voice.gender, func(v): comp.spec.voice.gender = v))
	vsec.add_child(UI.row("音调", UI.sld(0.5, 2.0, 0.05, float(s.voice.pitch), func(v: float): comp.spec.voice.pitch = v)))
	vsec.add_child(UI.row("语速", UI.sld(0.6, 1.6, 0.05, float(s.voice.rate), func(v: float): comp.spec.voice.rate = v)))
	var f_av := UI.le("API 语音名（留空=自动选）", String(s.voice.get("api_voice", "")))
	vsec.add_child(UI.row("API 音色", f_av))
	vsec.add_child(UI.btn("试听", func():
		voice.speak("你好呀，我是%s，很高兴认识你。" % comp.spec.name, comp.spec), "ghost"))
	var save := UI.btn("保存资料", func():
		var sp2: Dictionary = comp.spec
		sp2.name = f_name.text.strip_edges() if f_name.text.strip_edges() != "" else sp2.name
		sp2.label = f_label.text
		sp2.personality.desc = f_desc.text
		sp2.personality.speech = f_speech.text
		sp2.personality.suffix = f_suffix.text
		sp2.personality.catchphrases = f_cp.text
		sp2.personality.likes = f_likes.text
		sp2.personality.dislikes = f_dis.text
		sp2.personality.relation = f_rel.text
		sp2.personality.call_user = f_call.text
		sp2.personality.backstory = f_story.text
		sp2.personality.archetype = ""
		sp2.voice.api_voice = f_av.text
		comp.spec = SP.normalize(sp2)
		store.save_companions()
		toast("已保存")
		show_screen("profile"), "primary", 28)
	save.custom_minimum_size.y = 80
	body.add_child(save)
	# 记忆
	var ms := _section(body, "%s记得的事" % s.name)
	ms.add_child(UI.hint("聊天时它会自动记住关于你的重要信息。点 × 可以让它忘掉。"))
	var mem: Array = comp.state.memory
	if mem.is_empty():
		ms.add_child(UI.label("还没有记住什么。多聊聊吧~", 22, UI.MUTED))
	for i in range(mem.size() - 1, -1, -1):
		var idx := i
		var row := UI.hb(8)
		row.add_child(UI.label("· " + String(mem[i].get("text", "")), 22, UI.TXT, true))
		row.add_child(UI.icon_btn("close", func():
			comp.state.memory.remove_at(idx)
			store.save_companions()
			show_screen("profile"), 48, "flat"))
		ms.add_child(row)
	var add_mem := UI.hb(8)
	var am := UI.le("手动告诉它一件事，比如：我对芒果过敏")
	add_mem.add_child(am)
	add_mem.add_child(UI.btn("记住", func():
		if am.text.strip_edges() != "":
			_remember(comp, am.text.strip_edges())
			store.save_companions()
			show_screen("profile"), "ghost", 23))
	ms.add_child(add_mem)
	var ds := _section(body, "")
	ds.add_child(UI.btn("清空聊天记录", func():
		_confirm("清空聊天记录", "聊天记录会被删除，但%s的记忆和好感度会保留。" % s.name, "清空", func():
			store.clear_chat(comp.id)
			toast("已清空")), "ghost"))
	ds.add_child(UI.btn("删除这个伙伴", func():
		_confirm("删除伙伴", "确定要删除%s吗？它的记忆、好感度和聊天记录都会消失，不能恢复。" % s.name, "删除", func():
			store.delete_companion(comp.id)
			_apply_accent()
			_greeted = false
			show_screen("chat" if not store.companions.is_empty() else "welcome")), "danger"))

# ================================================================== 精致立绘
const ART_EMOS := {
	"happy": "开心地笑，眼睛弯弯",
	"shy": "害羞脸红，眼神躲闪",
	"angry": "生气鼓着脸，皱着眉",
	"sad": "难过委屈，眼里有泪光",
	"surprised": "惊讶，睁大眼睛，嘴巴微张",
	"sleepy": "困倦，眼睛半闭，打哈欠",
}

func _apply_art(cr, comp: Dictionary) -> void:
	if is_instance_valid(cr):
		cr.set_art(ART.load_for(comp))

func _art_refresh(comp: Dictionary) -> void:
	if comp.id == store.current_id and is_instance_valid(creature):
		_apply_art(creature, comp)

func _art_prompt(comp: Dictionary, desc: String) -> String:
	var s: Dictionary = comp.spec
	var base := desc.strip_edges()
	if base == "":
		base = "%s，%s。性格：%s" % [s.label, SP.appearance_summary(s), s.personality.desc]
	return base + "。二次元日系动漫插画，精致的赛璐璐上色，细腻干净的线条，漂亮的光影，大而有神的眼睛，全身立绘，正面站立，从头到脚完整入画，姿态自然，单个角色。背景是纯绿色（#00FF00），平整，没有阴影、渐变和任何其他物体，角色身上不要出现绿色。高清，高细节。"

func _wait_call(starter: Callable) -> Dictionary:
	var st := {"d": false, "ok": false, "img": null, "err": ""}
	starter.call(func(ok: bool, img, err: String):
		st.ok = ok
		st.img = img
		st.err = err
		st.d = true)
	while not st.d:
		await get_tree().process_frame
	return st

func _art_key(img: Image, w: int, h: int) -> Image:
	var st := {"img": null}
	var th := Thread.new()
	th.start(func(): st.img = ART.chroma(img, w, h))
	while th.is_alive():
		await get_tree().process_frame
	th.wait_to_finish()
	return st.img

func _make_art(comp: Dictionary, desc: String, ref: Image = null) -> void:
	if not llm.has_img():
		toast("先在设置 → AI 画像里填好阿里云 Key，才能画立绘", 4.0)
		return
	if art_busy:
		toast("正在生成中，请稍等")
		return
	art_busy = true
	toast("正在画精致立绘（约 30~90 秒），可以先去聊天", 5.0)
	var r: Dictionary
	if ref != null:
		var rp := "把这张图里的人物重新绘制成二次元日系动漫角色立绘：保留发型、发色、服装、配饰、气质和神态，画成精致的赛璐璐上色、细腻干净线条的动漫风格，全身立绘，正面站立，从头到脚完整入画，单个角色。背景换成纯绿色（#00FF00），平整无阴影无其他物体，角色身上不要出现绿色。" + (" 额外要求：" + desc.strip_edges() if desc.strip_edges() != "" else "")
		r = await _wait_call(func(cb): llm.image_edit(ref, rp, cb))
	else:
		r = await _wait_call(func(cb): llm.image(_art_prompt(comp, desc), cb, true))
	if not r.ok or r.img == null:
		art_busy = false
		toast("立绘生成失败：" + String(r.err), 6.0)
		return
	var src: Image = r.img
	var sc := minf(1.0, 1000.0 / float(maxi(src.get_width(), src.get_height())))
	var w := maxi(64, int(src.get_width() * sc))
	var h := maxi(64, int(src.get_height() * sc))
	var keyed: Image = await _art_key(src, w, h)
	if keyed == null:
		art_busy = false
		toast("抠图失败，请再试一次")
		return
	var rect := keyed.get_used_rect()
	if rect.size.x < 40 or rect.size.y < 40:
		art_busy = false
		toast("没认出角色，换个描述再试一次")
		return
	rect = rect.grow(6).intersection(Rect2i(0, 0, w, h))
	var base_path := "%s/art_%s.png" % [store.DIR, comp.id]
	keyed.get_region(rect).save_png(base_path)
	var small: Image = src.duplicate()
	small.resize(w, h, Image.INTERPOLATE_LANCZOS)
	small.save_png("%s/art_%s_src.png" % [store.DIR, comp.id])
	comp.state.art = {"base": base_path, "rect": [rect.position.x, rect.position.y, rect.size.x, rect.size.y], "w": w, "h": h, "emo": {}}
	store.save_companions()
	art_busy = false
	_art_refresh(comp)
	toast("立绘完成！想让它有更多表情，可在伙伴详情页点“生成多表情”。桌面悬浮需要关掉再开才会换上。", 6.0)

func _pick_ref(comp: Dictionary) -> void:
	if not llm.has_img():
		toast("先在设置 → AI 画像里填好阿里云 Key", 4.0)
		return
	_confirm("上传图片做立绘", "图片会发给阿里云，由 AI 重新画成二次元角色（不是照片，也不会保留真实长相）。请只上传你自己的画、你自己的照片，或已经征得本人同意的图片，不要上传他人的私密照片。", "我确认，选择图片", func():
		DisplayServer.file_dialog_show("选择图片", "", "", false, DisplayServer.FILE_DIALOG_MODE_OPEN_FILE, PackedStringArray(["*.png,*.jpg,*.jpeg,*.webp;图片"]), func(ok: bool, paths: PackedStringArray, _f: int):
			if not ok or paths.is_empty():
				return
			var im := Image.load_from_file(paths[0])
			if im == null or im.is_empty():
				toast("读取图片失败，换一张试试")
				return
			var sc := minf(1.0, 1280.0 / float(maxi(im.get_width(), im.get_height())))
			if sc < 1.0:
				im.resize(int(im.get_width() * sc), int(im.get_height() * sc), Image.INTERPOLATE_LANCZOS)
			_make_art(comp, String(comp.state.get("art_desc", "")), im)), false)

func _make_emotions(comp: Dictionary) -> void:
	var a = comp.state.get("art", {})
	if typeof(a) != TYPE_DICTIONARY or a.is_empty():
		toast("先生成精致立绘")
		return
	if String(store.settings.img.base).find("aliyuncs") < 0 or store.key("img") == "":
		toast("多表情需要阿里云百炼的画像接口和 Key", 4.0)
		return
	if art_busy:
		toast("正在生成中，请稍等")
		return
	var src := Image.load_from_file("%s/art_%s_src.png" % [store.DIR, comp.id])
	if src == null or src.is_empty():
		toast("找不到原图，请重新生成立绘")
		return
	art_busy = true
	var w := int(a.w)
	var h := int(a.h)
	var rect := Rect2i(int(a.rect[0]), int(a.rect[1]), int(a.rect[2]), int(a.rect[3]))
	var got := {}
	var n := 0
	for emo in ART_EMOS:
		n += 1
		toast("正在生成表情 %d/%d …" % [n, ART_EMOS.size()], 60.0)
		var pr := "保持这个角色的外貌、发型、服装、画风、构图、姿势和纯绿色背景完全不变，只把表情改成：%s。" % ART_EMOS[emo]
		var r: Dictionary = await _wait_call(func(cb): llm.image_edit(src, pr, cb))
		if not r.ok or r.img == null:
			toast("表情“%s”失败：%s" % [emo, String(r.err)], 6.0)
			if n == 1:
				break
			continue
		var k: Image = await _art_key(r.img, w, h)
		if k == null:
			continue
		var pth := "%s/art_%s_%s.png" % [store.DIR, comp.id, emo]
		k.get_region(rect).save_png(pth)
		got[emo] = pth
	a["emo"] = got
	comp.state.art = a
	store.save_companions()
	art_busy = false
	_art_refresh(comp)
	if not got.is_empty():
		toast("表情生成完成（%d 个）。桌面悬浮需要关掉再开才会换上。" % got.size(), 5.0)

func _portrait(comp: Dictionary) -> void:
	if not llm.has_img():
		toast("先在设置 → AI 画像里填写图片接口的 Key")
		return
	toast("正在生成画像（约 10~60 秒），可以先去聊天")
	var s: Dictionary = comp.spec
	var prompt := "%s，%s。性格：%s。Q版可爱角色设计，全身，正面站立，纯白色背景，干净清晰的线条，柔和配色，高质量插画，单个角色" % [s.label, SP.appearance_summary(s), s.personality.desc]
	llm.image(prompt, func(ok: bool, img, err: String):
		if not ok or img == null:
			toast("画像生成失败：" + err, 4.0)
			return
		var path := "%s/portrait_%s.png" % [store.DIR, comp.id]
		(img as Image).save_png(path)
		comp.state.portrait = path
		store.save_companions()
		_show_portrait(path, s.name))

func _show_portrait(path: String, nm: String) -> void:
	var img := Image.load_from_file(path)
	if img == null:
		return
	var v := _modal("%s 的画像" % nm, 620.0)
	var tr := TextureRect.new()
	tr.texture = ImageTexture.create_from_image(img)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.custom_minimum_size = Vector2(520, 520)
	v.add_child(tr)
	v.add_child(UI.hint("画像保存在 App 里，可以截图分享。动态形象仍然使用矢量版（这样表情和动作最丰富）。"))

# ================================================================== 设置
# 主设置只留常用项；接口地址、模型、其他平台都收在“高级自定义”里
func _key_of(k: String) -> String:
	return String(store.keys.get(k, "")).strip_edges()

func _ds_key() -> String:
	var k := _key_of("deepseek")
	if k == "" and String(store.settings.chat.base).find("deepseek") >= 0:
		k = _key_of("chat")
	return k

func _ali_key() -> String:
	var k := _key_of("aliyun")
	if k == "":
		k = _key_of("tts")
	if k == "" and String(store.settings.chat.base).find("aliyuncs") >= 0:
		k = _key_of("chat")
	return k

# 简单模式：聊天用 DeepSeek 或通义千问；声音、听写、画立绘、陪看都用阿里云
func _simple_route(brain := "") -> void:
	var S: Dictionary = store.settings
	var cs: Dictionary = S.chat
	# 先把旧版填在 chat / tts 里的 Key 记到对应平台名下，切换大脑时不会丢
	if _key_of("deepseek") == "" and _ds_key() != "":
		store.keys["deepseek"] = _ds_key()
	if _key_of("aliyun") == "" and _ali_key() != "":
		store.keys["aliyun"] = _ali_key()
	if brain == "":
		brain = String(cs.get("preset", "deepseek"))
	if brain == "dashscope":
		cs.preset = "dashscope"
		cs.base = String(LLMScript.PRESETS["dashscope"].base)
		if not String(cs.model).begins_with("qwen"):
			cs.model = "qwen-plus"
		if _key_of("aliyun") != "":
			store.keys["chat"] = _key_of("aliyun")
	else:
		cs.preset = "deepseek"
		cs.base = "https://api.deepseek.com"
		if not String(cs.model).begins_with("deepseek") or String(cs.model) in ["deepseek-chat", "deepseek-reasoner"]:
			cs.model = "deepseek-flash"
		if _key_of("deepseek") != "":
			store.keys["chat"] = _key_of("deepseek")
	if _key_of("aliyun") != "":
		store.keys["tts"] = _key_of("aliyun")
	var ts: Dictionary = S.tts
	if String(ts.base).find("aliyuncs") < 0:
		ts.base = "https://dashscope.aliyuncs.com/api/v1"
		ts.model = "cosyvoice-v3-flash"
		ts.voice = ""
	var ss: Dictionary = S.stt
	if String(ss.base).find("aliyuncs") < 0:
		ss.base = "https://dashscope.aliyuncs.com/api/v1"
		ss.model = "qwen3-asr-flash"
	var isec: Dictionary = S.img
	if String(isec.base).find("aliyuncs") < 0:
		isec.base = "https://dashscope.aliyuncs.com/api/v1"
		isec.model = "qwen-image-2.0"
	store.save_settings()
	store.save_keys()

func _keys_popup() -> void:
	var v := _modal("填写 AI Key（一次就好）", 700.0)
	v.add_child(UI.label("只要两个 Key：DeepSeek 负责聊天（便宜又聪明），阿里云百炼负责声音、听你说话、画立绘和陪看。Key 只加密保存在这台设备上。", 22, UI.MUTED, true))
	v.add_child(UI.title("DeepSeek Key", 25))
	v.add_child(UI.hint("获取：浏览器打开 platform.deepseek.com → 注册登录 → 充值（几块钱能用很久）→ API Keys → 创建，复制 sk- 开头的整串。"))
	var fd := UI.le("sk-…", _ds_key(), true)
	v.add_child(fd)
	v.add_child(UI.title("阿里云百炼 Key", 25))
	v.add_child(UI.hint("获取：浏览器打开 bailian.console.aliyun.com → 支付宝登录并实名 → 右上角 API-KEY → 创建，复制 sk- 开头的整串。新用户有免费额度。"))
	var fa := UI.le("sk-…", _ali_key(), true)
	v.add_child(fa)
	var res := UI.hint("")
	var row := UI.hb(12)
	row.add_child(UI.grow(UI.btn("保存并测试", func():
		store.keys["deepseek"] = fd.text.strip_edges()
		store.keys["aliyun"] = fa.text.strip_edges()
		var brain := String(store.settings.chat.get("preset", "deepseek"))
		if brain != "dashscope" and _key_of("deepseek") == "" and _key_of("aliyun") != "":
			brain = "dashscope"
		_simple_route(brain)
		_refresh_top()
		if not llm.has_chat():
			res.text = "已保存。还没有可用的聊天 Key，伙伴会先用离线模式。"
			return
		res.text = "测试中…"
		llm.chat([{"role": "user", "content": "请只回复两个字：你好"}], func(ok: bool, content: String, err: String):
			if is_instance_valid(res):
				res.text = ("✓ 连接成功！伙伴已经变聪明了：" + content.left(20)) if ok else ("✕ " + err)
				res.add_theme_color_override("font_color", UI.GOOD if ok else UI.BAD), {"json": false, "max_tokens": 20, "timeout": 30.0}), "primary", 24)))
	row.add_child(UI.btn("显示", func():
		fd.secret = not fd.secret
		fa.secret = not fa.secret, "ghost", 22))
	v.add_child(row)
	v.add_child(res)

func _build_settings() -> void:
	var body := _scroll_page("设置", "chat" if not store.companions.is_empty() else "welcome")
	var S: Dictionary = store.settings
	var hp := _section(body, "帮助")
	hp.add_child(UI.hint("第一次用？先看教程；遇到问题可以直接联系客服。"))
	var hr := UI.hb(12)
	hr.add_child(UI.btn("使用教程", func(): show_screen("help"), "primary", 24))
	hr.add_child(UI.btn("联系客服", func(): _support_popup(), "ghost", 24))
	hp.add_child(hr)
	# ---- AI 服务（简单模式）
	var a := _section(body, "AI 服务")
	var cs: Dictionary = S.chat
	var pk := String(cs.get("preset", "deepseek"))
	var st_lbl := UI.label("", 23, UI.TXT, true)
	var show_st := func():
		var p2 := String(cs.get("preset", ""))
		var nm := "DeepSeek" if p2 == "deepseek" else ("通义千问" if p2 == "dashscope" else String(LLMScript.PRESETS.get(p2, {}).get("name", "自定义")))
		st_lbl.text = "聊天：%s · %s\n声音 / 听写 / 立绘 / 陪看：阿里云 · %s" % [nm, "已连接" if store.key("chat") != "" else "未填 Key（离线模式）", "已连接" if _ali_key() != "" else "未填 Key"]
	show_st.call()
	a.add_child(st_lbl)
	if pk in ["deepseek", "dashscope"]:
		a.add_child(UI.label("聊天用哪个大脑", 23, UI.MUTED))
		a.add_child(UI.seg([["deepseek", "DeepSeek（推荐）"], ["dashscope", "通义千问（阿里云）"]], pk, func(v):
			_simple_route(String(v))
			show_st.call()
			_refresh_top()))
	else:
		a.add_child(UI.hint("你正在用「高级自定义」里的平台。想回到简单模式，选一个大脑即可。"))
		a.add_child(UI.seg([["deepseek", "DeepSeek"], ["dashscope", "通义千问"]], "", func(v):
			_simple_route(String(v))
			show_screen("settings")))
	var ar := HFlowContainer.new()
	ar.add_theme_constant_override("h_separation", 12)
	ar.add_theme_constant_override("v_separation", 10)
	ar.add_child(UI.btn("填写 Key", func(): _keys_popup(), "primary", 24))
	var test_lbl := UI.hint("")
	ar.add_child(UI.btn("测试连接", func():
		if not llm.has_chat():
			test_lbl.text = "还没填聊天 Key，先点“填写 Key”。"
			return
		test_lbl.text = "测试中…"
		llm.chat([{"role": "user", "content": "请只回复两个字：你好"}], func(ok: bool, content: String, err: String):
			if is_instance_valid(test_lbl):
				test_lbl.text = ("✓ 连接成功：" + content.left(30)) if ok else ("✕ " + err)
				test_lbl.add_theme_color_override("font_color", UI.GOOD if ok else UI.BAD), {"json": false, "max_tokens": 20, "timeout": 30.0}), "ghost", 24))
	ar.add_child(UI.btn("高级自定义", func(): show_screen("advanced"), "ghost", 24))
	a.add_child(ar)
	a.add_child(test_lbl)
	# ---- 声音
	var vo := _section(body, "伙伴的声音")
	var ts: Dictionary = S.tts
	vo.add_child(UI.seg([["off", "不出声"], ["system", "系统语音（免费）"], ["api", "AI 语音（阿里云，更自然）"]], ts.mode, func(v):
		ts.mode = v
		if v == "api" and String(ts.base).find("aliyuncs") < 0 and String(S.chat.get("preset", "")) in ["deepseek", "dashscope"]:
			_simple_route()
		store.save_settings()))
	var vlist: Array = voice.sys_voices()
	var vnames: Array = ["自动（中文）"]
	var vids: Array = [""]
	for vv in vlist:
		vnames.append("%s（%s）" % [String(vv.get("name", "?")), String(vv.get("language", ""))])
		vids.append(String(vv.get("id", "")))
	vo.add_child(UI.row("语言 / 系统语音", UI.opt(vnames, maxi(0, vids.find(String(ts.get("sys_voice", "")))), func(i: int):
		ts.sys_voice = vids[i]
		store.save_settings()), 210))
	if vlist.is_empty():
		vo.add_child(UI.hint("没有检测到系统语音引擎。可以在手机设置里安装“文字转语音”引擎，或改用 AI 语音。"))
	vo.add_child(UI.row("音量", UI.sld(0, 100, 5, float(ts.get("volume", 80)), func(v: float):
		ts.volume = int(v)
		store.save_settings()), 210))
	vo.add_child(UI.tog("被摸、被戳的时候也出声", bool(S.behavior.get("touch_voice", true)), func(on: bool):
		S.behavior.touch_voice = on
		store.save_settings()))
	vo.add_child(UI.btn("试听", func():
		var c = store.current()
		voice.speak("你好呀，这是我的声音。", c.spec if c != null else SP.default_spec()), "ghost"))
	var ss: Dictionary = S.stt
	vo.add_child(UI.label("听你说话", 23, UI.MUTED))
	vo.add_child(UI.seg([["ime", "用输入法的语音"], ["api", "阿里云识别（支持通话模式）"]], ss.mode, func(v):
		ss.mode = v
		if v == "api" and String(ss.base).find("aliyuncs") < 0 and String(S.chat.get("preset", "")) in ["deepseek", "dashscope"]:
			_simple_route()
		store.save_settings()))
	vo.add_child(UI.row("通话灵敏度", UI.sld(0, 1, 0.05, float(S.behavior.get("vad", 0.5)), func(v: float):
		S.behavior.vad = v
		store.save_settings()), 210))
	# ---- 屏幕陪看
	var vs := _section(body, "屏幕陪看（实验）")
	var vsec: Dictionary = S.vision
	vs.add_child(UI.hint("打开后，在桌面悬浮窗点“陪看”并允许录屏，伙伴会像坐在你旁边一样看着屏幕自己搭话。用阿里云按量计费；银行、支付、密码页面系统会自动拦住。"))
	vs.add_child(UI.tog("允许悬浮窗陪我看屏幕", bool(vsec.get("on", false)), func(on: bool):
		vsec.on = on
		store.save_settings()))
	vs.add_child(UI.label("说话程度", 23, UI.MUTED))
	vs.add_child(UI.seg([["lively", "爱说话"], ["normal", "适中"], ["quiet", "安静"]], String(vsec.get("freq", "normal")), func(v):
		vsec.freq = v
		store.save_settings()))
	# ---- 舞台背景
	var bgs := _section(body, "舞台背景")
	var sg: Dictionary = S.get("stage", {})
	bgs.add_child(UI.hint("伙伴站立的背景。默认是随时间变化的天空；也可以换成你相册里的图片，或让 AI 画一张。"))
	bgs.add_child(UI.seg([["sky", "动态天空（默认）"], ["image", "自定义图片"]], String(sg.get("mode", "sky")), func(v):
		if v == "sky":
			store.settings.stage = {"mode": "sky", "img": String(sg.get("img", ""))}
			store.save_settings()
			_apply_stage_bg()
		elif String(sg.get("img", "")) != "" and FileAccess.file_exists(String(sg.get("img", ""))):
			store.settings.stage = {"mode": "image", "img": String(sg.get("img", ""))}
			store.save_settings()
			_apply_stage_bg()
		else:
			toast("先从相册选一张，或用 AI 生成")))
	var bgr := UI.hb(12)
	bgr.add_child(UI.btn("从相册选图", func(): _pick_stage_image(), "primary", 24))
	bgr.add_child(UI.btn("AI 生成背景", func(): _gen_stage_ai(), "ghost", 24))
	bgs.add_child(bgr)
	bgs.add_child(UI.hint("视频背景受手机格式限制，先支持静态图片，后续再加。"))
	# ---- 外观与音效
	var ap := _section(body, "外观与音效")
	ap.add_child(UI.label("字体大小", 23, UI.MUTED))
	ap.add_child(UI.seg([[0.9, "小"], [1.0, "标准"], [1.15, "大"], [1.3, "特大"]], float(S.behavior.get("font_scale", 1.0)), func(v):
		S.behavior.font_scale = float(v)
		UI.fscale = float(v)
		store.save_settings()
		_apply_accent()
		show_screen("settings")))
	ap.add_child(UI.tog("音效（点按、消息提示音）", bool(S.behavior.get("sfx", true)), func(on: bool):
		S.behavior.sfx = on
		if snd != null: snd.on = on
		store.save_settings()))
	ap.add_child(UI.tog("每次打开显示开场动画", bool(S.behavior.get("intro_anim", true)), func(on: bool):
		S.behavior.intro_anim = on
		store.save_settings()))
	ap.add_child(UI.hint("开场和聊天的背景可在上面「舞台背景」里自定义。"))
	# ---- 行为
	var bs := _section(body, "伙伴的行为")
	var B: Dictionary = S.behavior
	bs.add_child(UI.label("你不说话时，它多久主动找你聊天", 23, UI.MUTED))
	bs.add_child(UI.seg([[0, "从不"], [5, "5 分钟"], [8, "8 分钟"], [15, "15 分钟"], [30, "30 分钟"]], int(B.get("proactive_min", 8)), func(v):
		B.proactive_min = v
		store.save_settings()))
	bs.add_child(UI.tog("主动聊天时使用 AI（更自然，会消耗 token）", bool(B.get("proactive_ai", true)), func(on: bool):
		B.proactive_ai = on
		store.save_settings()))
	bs.add_child(UI.label("每小时最多主动用 AI 几次", 23, UI.MUTED))
	bs.add_child(UI.seg([[1, "1 次"], [3, "3 次"], [6, "6 次"], [12, "12 次"]], int(B.get("ai_per_hour", 3)), func(v):
		B.ai_per_hour = v
		store.save_settings()))
	bs.add_child(UI.label("多久没理它会睡着", 23, UI.MUTED))
	bs.add_child(UI.seg([[0, "不睡"], [10, "10 分钟"], [20, "20 分钟"], [40, "40 分钟"]], int(B.get("sleep_min", 20)), func(v):
		B.sleep_min = v
		store.save_settings()))
	bs.add_child(UI.label("回复长度", 23, UI.MUTED))
	bs.add_child(UI.seg([["short", "简短"], ["normal", "适中"], ["long", "详细"]], String(B.get("reply_len", "short")), func(v):
		B.reply_len = v
		store.save_settings()))
	bs.add_child(UI.tog("让它在舞台上自由走动（关掉就乖乖站着）", bool(B.get("roam", true)), func(on: bool):
		B.roam = on
		store.save_settings()))
	bs.add_child(UI.label("界面", 23, UI.MUTED))
	bs.add_child(UI.seg([["auto", "自动"], ["normal", "普通"], ["mini", "小窗模式"]], String(B.get("ui_mode", "auto")), func(v):
		B.ui_mode = v
		store.save_settings()))
	bs.add_child(UI.hint("小窗模式：把桌宠物语放进平板的小窗/悬浮窗里，它就能浮在别的 App 上和你聊天。“自动”会在窗口变小时自动切换。"))
	bs.add_child(UI.label("搜索引擎", 23, UI.MUTED))
	bs.add_child(UI.seg([["bing", "必应"], ["baidu", "百度"], ["google", "Google"]], String(B.get("search", "bing")), func(v):
		B.search = v
		store.save_settings()))
	# ---- 权限
	# ---- 桌面悬浮
	var fl := _section(body, "桌面悬浮（实验功能）")
	fl.add_child(UI.hint("让伙伴站在桌面上：能拖动、会自己走动，点它就弹出聊天框。需要“悬浮版”安装包，并在系统里允许“显示在其他应用上层”。悬浮时的聊天是简化版，不能操作手机。"))
	var OVS: Dictionary = S.overlay
	fl.add_child(UI.row("大小", UI.sld(90, 260, 10, float(OVS.get("size", 150)), func(v: float):
		OVS.size = int(v)
		store.save_settings())))
	fl.add_child(UI.tog("没人理它时自己在桌面上走动", bool(OVS.get("wander", true)), func(on: bool):
		OVS.wander = on
		store.save_settings()))
	fl.add_child(UI.btn("开启桌面悬浮", func():
		var c = store.current()
		if c == null:
			toast("还没有伙伴")
			return
		toast("正在准备图片…", 6.0)
		var msg: String = await floater.start(c)
		if msg == "":
			toast("已开启，回到桌面就能看到它", 4.0)
		else:
			toast(msg, 6.0), "primary"))
	fl.add_child(UI.btn("关闭桌面悬浮", func():
		floater.stop()
		toast("已关闭"), "ghost"))
	var pm := _section(body, "手机操作权限")
	pm.add_child(UI.hint("伙伴只有在你允许时才能碰你的手机。“询问”= 每次都先问你；“允许”= 直接做；“禁止”= 永远不做。"))
	for cap in DeviceScript.CAP_ORDER:
		var ck: String = cap
		var r := UI.vb(6)
		r.add_child(UI.label(DeviceScript.CAPS[ck], 23, UI.TXT))
		r.add_child(UI.seg([["deny", "禁止"], ["ask", "询问"], ["allow", "允许"]], String(S.perms.get(ck, "ask")), func(v):
			S.perms[ck] = v
			store.save_settings(), 22))
		pm.add_child(r)
	pm.add_child(UI.hint("说明：这一版可以打开 App、搜索、导航、拨号界面、闹钟计时、手电筒、音量、系统设置、相机、分享。下个版本加入“无障碍服务”：伙伴能按你的指令点击、滑动、操作任意 App——只在你下指令时才动，绝不自己乱动。"))
	# ---- 用量
	var us := _section(body, "Token 用量")
	var st: Dictionary = store.stats
	var pin := int(st.get("prompt", 0))
	var pout := int(st.get("completion", 0))
	var price: Dictionary = S.price
	var cost := pin / 1000000.0 * float(price.get("in", 0.0)) + pout / 1000000.0 * float(price.get("out", 0.0))
	var ul := UI.label("自 %s 起：%d 次请求，输入 %s tokens，输出 %s tokens%s" % [String(st.get("since", "")), int(st.get("requests", 0)), _kfmt(pin), _kfmt(pout), ("，约 %.2f 元" % cost) if cost > 0.0 else ""], 23, UI.TXT, true)
	us.add_child(ul)
	var prow := UI.hb(8)
	var fin := UI.le("输入价 元/百万", str(price.get("in", 0.0)) if float(price.get("in", 0.0)) > 0.0 else "")
	var fout := UI.le("输出价 元/百万", str(price.get("out", 0.0)) if float(price.get("out", 0.0)) > 0.0 else "")
	fin.text_changed.connect(func(t: String):
		price["in"] = t.to_float()
		store.save_settings())
	fout.text_changed.connect(func(t: String):
		price["out"] = t.to_float()
		store.save_settings())
	prow.add_child(fin)
	prow.add_child(fout)
	us.add_child(prow)
	us.add_child(UI.hint("填上你的服务商价格，就能估算花了多少钱（只是估算，以服务商账单为准）。"))
	us.add_child(UI.btn("清零统计", func():
		store.stats = {"prompt": 0, "completion": 0, "requests": 0, "since": Time.get_date_string_from_system()}
		store.save_stats()
		show_screen("settings"), "ghost"))
	# ---- 数据
	var ds := _section(body, "数据与关于")
	ds.add_child(UI.btn("复制全部伙伴码（备份外形和性格）", func():
		var lines: Array = []
		for c in store.companions:
			lines.append("%s\n%s" % [c.spec.name, Store.share_code(c.spec)])
		DisplayServer.clipboard_set("\n\n".join(lines))
		toast("已复制 %d 个伙伴码" % store.companions.size()), "ghost"))
	ds.add_child(UI.btn("导入伙伴码", func(): _import_dialog(), "ghost"))
	ds.add_child(UI.hint("桌宠物语 %s · 所有聊天记录、记忆和 Key 都只保存在这台设备上。\n字体：Noto Sans CJK（SIL Open Font License）。引擎：Godot Engine（MIT）。" % VERSION))


# ---------------------------------------------------------------- 高级自定义
func _build_advanced() -> void:
	var body := _scroll_page("高级自定义", "settings")
	var S: Dictionary = store.settings
	var tu := _section(body, "教程：自定义接入")
	tu.add_child(UI.label("这里给想用其他 AI 平台、中转站或自己指定模型的用户。一般用户不用动——在设置的「AI 服务」里填两个 Key 就够了。", 22, UI.TXT, true))
	tu.add_child(UI.label("1. 在平台官网注册 → 充值 → 创建 API Key（密钥）。\n2. 下面「服务商」选对应平台，会自动填好接口地址和模型；平台不在列表里就选「自定义」，照平台文档填接口地址（OpenAI 兼容格式，一般以 /v1 结尾）和模型名。\n3. 粘贴 Key，点「测试连接」，显示连接成功就能用。\n4. 中转站：服务商选「自定义」，接口地址填中转站给的 Base URL（OpenAI 格式，通常要加 /v1），模型名照中转站列表填。\n5. 声音、听写、画立绘、陪看可以分别指定平台；Key 留空时会自动借用阿里云 Key。", 21, UI.MUTED, true))
	# ---- AI 模型
	var a := _section(body, "AI 模型（自己的 API Key）")
	a.add_child(UI.hint("伙伴的聊天、生成外形和性格都用这里的模型。Key 只加密保存在这台设备上，费用由你在服务商那里支付。不填也能用离线模式。"))
	var cs: Dictionary = S.chat
	var preset_idx := LLMScript.PRESET_ORDER.find(String(cs.get("preset", "deepseek")))
	var pnames: Array = []
	for k in LLMScript.PRESET_ORDER:
		pnames.append(LLMScript.PRESETS[k].name)
	var f_base := UI.le("接口地址，如 https://api.deepseek.com", String(cs.base))
	var f_model := UI.le("模型名", String(cs.model))
	var model_chips := HFlowContainer.new()
	model_chips.add_theme_constant_override("h_separation", 8)
	var fill_chips := func(pk: String):
		for ch in model_chips.get_children():
			ch.queue_free()
		for m in LLMScript.PRESETS.get(pk, {}).get("models", []):
			var mm: String = m
			model_chips.add_child(UI.btn(mm, func():
				f_model.text = mm
				cs.model = mm
				store.save_settings(), "chip"))
	var site_lbl := UI.hint("")
	var show_site := func(pk: String):
		var st := String(LLMScript.PRESETS.get(pk, {}).get("site", ""))
		site_lbl.text = ("获取 Key：用浏览器打开 " + st + "，注册→充值→创建 API 密钥，粘贴到下面。") if st != "" else "填入平台的接口地址、模型名和 Key 即可（只要支持 OpenAI 格式）。"
	a.add_child(UI.row("服务商", UI.opt(pnames, preset_idx, func(i: int):
		var pk: String = LLMScript.PRESET_ORDER[i]
		cs.preset = pk
		if pk != "custom":
			cs.base = LLMScript.PRESETS[pk].base
			f_base.text = cs.base
			var ms: Array = LLMScript.PRESETS[pk].models
			if not ms.is_empty():
				cs.model = ms[0]
				f_model.text = cs.model
		fill_chips.call(pk)
		show_site.call(pk)
		store.save_settings())))
	a.add_child(site_lbl)
	show_site.call(String(cs.get("preset", "deepseek")))
	f_base.text_changed.connect(func(t: String):
		cs.base = t.strip_edges()
		store.save_settings())
	a.add_child(UI.row("接口地址", f_base))
	var keyrow := UI.hb(8)
	var f_key := UI.le("API Key（sk-…）", store.key("chat"), true)
	f_key.text_changed.connect(func(t: String): store.set_key("chat", t))
	keyrow.add_child(f_key)
	keyrow.add_child(UI.btn("显示", func():
		f_key.secret = not f_key.secret, "ghost", 22))
	a.add_child(UI.row("API Key", keyrow))
	f_model.text_changed.connect(func(t: String):
		cs.model = t.strip_edges()
		store.save_settings())
	a.add_child(UI.row("模型", f_model))
	fill_chips.call(String(cs.get("preset", "deepseek")))
	a.add_child(model_chips)
	a.add_child(UI.tog("JSON 模式（让表情和动作更准确；不支持的服务商会自动关闭）", bool(cs.get("json", true)), func(on: bool):
		cs.json = on
		store.save_settings()))
	var test_lbl := UI.hint("")
	a.add_child(UI.btn("测试连接", func():
		test_lbl.text = "测试中…"
		llm.chat([{"role": "user", "content": "请只回复两个字：你好"}], func(ok: bool, content: String, err: String):
			if is_instance_valid(test_lbl):
				test_lbl.text = ("✓ 连接成功：" + content.left(30)) if ok else ("✕ " + err)
				test_lbl.add_theme_color_override("font_color", UI.GOOD if ok else UI.BAD), {"json": false, "max_tokens": 20, "timeout": 30.0}), "ghost"))
	a.add_child(test_lbl)
	# ---- AI 语音接口
	var vo := _section(body, "AI 语音接口")
	var ts: Dictionary = S.tts
	vo.add_child(UI.label("API 语音：可选阿里云百炼（CosyVoice，声音生动，支付宝登录即可实名；地址填百炼 API Key 窗口里 DashScope 那一行）、硅基流动，或任何 OpenAI 兼容 /audio/speech", 22, UI.MUTED, true))
	var tb := UI.le("接口地址", String(ts.base))
	var tm := UI.le("模型名", String(ts.model))
	vo.add_child(UI.seg([["dashscope", "阿里云百炼"], ["siliconflow", "硅基流动"]], "dashscope" if String(ts.base).find("aliyuncs") >= 0 else "siliconflow", func(v):
		if v == "dashscope":
			if String(ts.base).find("aliyuncs") < 0:
				ts.base = "https://dashscope.aliyuncs.com/api/v1"
			ts.model = "cosyvoice-v3-flash"
		else:
			ts.base = "https://api.siliconflow.cn/v1"
			ts.model = "FunAudioLLM/CosyVoice2-0.5B"
		ts.voice = ""
		tb.text = String(ts.base)
		tm.text = String(ts.model)
		store.save_settings()))
	tb.text_changed.connect(func(t: String):
		ts.base = t.strip_edges()
		store.save_settings())
	vo.add_child(UI.row("接口地址", tb))
	var tk := UI.le("语音 API Key", String(store.keys.get("tts", "")), true)
	tk.text_changed.connect(func(t: String): store.set_key("tts", t))
	vo.add_child(UI.row("Key", tk))
	vo.add_child(UI.tog("和 AI 模型用同一个 Key", bool(ts.get("same_key", false)), func(on: bool):
		ts.same_key = on
		store.save_settings()))
	tm.text_changed.connect(func(t: String):
		ts.model = t.strip_edges()
		store.save_settings())
	vo.add_child(UI.row("模型", tm))
	var tv := UI.le("留空 = 按伙伴性别性格自动选", String(ts.get("voice", "")))
	tv.text_changed.connect(func(t: String):
		ts.voice = t.strip_edges()
		store.save_settings())
	vo.add_child(UI.row("音色", tv))
	# ---- 语音识别接口
	var vi := _section(body, "语音识别接口")
	var ss: Dictionary = S.stt
	var sb2 := UI.le("接口地址", String(ss.base))
	var sm := UI.le("模型名", String(ss.model))
	vi.add_child(UI.seg([["dashscope", "阿里云百炼"], ["siliconflow", "硅基流动"]], "dashscope" if String(ss.base).find("aliyuncs") >= 0 else "siliconflow", func(v):
		if v == "dashscope":
			ss.base = "https://dashscope.aliyuncs.com/api/v1"
			ss.model = "qwen3-asr-flash"
		else:
			ss.base = "https://api.siliconflow.cn/v1"
			ss.model = "FunAudioLLM/SenseVoiceSmall"
		sb2.text = String(ss.base)
		sm.text = String(ss.model)
		store.save_settings()))
	sb2.text_changed.connect(func(t: String):
		ss.base = t.strip_edges()
		store.save_settings())
	vi.add_child(UI.row("接口地址", sb2))
	var sk := UI.le("语音识别 API Key", String(store.keys.get("stt", "")), true)
	sk.text_changed.connect(func(t: String): store.set_key("stt", t))
	vi.add_child(UI.row("Key", sk))
	vi.add_child(UI.tog("和 AI 模型用同一个 Key", bool(ss.get("same_key", false)), func(on: bool):
		ss.same_key = on
		store.save_settings()))
	sm.text_changed.connect(func(t: String):
		ss.model = t.strip_edges()
		store.save_settings())
	vi.add_child(UI.row("模型", sm))
	# ---- 画像
	var im := _section(body, "AI 画像（可选）")
	var isec: Dictionary = S.img
	im.add_child(UI.hint("用图片模型给伙伴画一张更精致的画像（阿里云百炼用通义千问 Image；也支持 OpenAI 兼容接口。选阿里云时 Key 留空会自动用语音合成的百炼 Key）。"))
	var ib := UI.le("接口地址", String(isec.base))
	var imd := UI.le("模型名", String(isec.model))
	im.add_child(UI.seg([["dashscope", "阿里云百炼"], ["siliconflow", "硅基流动"]], "dashscope" if String(isec.base).find("aliyuncs") >= 0 else "siliconflow", func(v):
		if v == "dashscope":
			isec.base = "https://dashscope.aliyuncs.com/api/v1"
			isec.model = "qwen-image-plus"
		else:
			isec.base = "https://api.siliconflow.cn/v1"
			isec.model = "Kwai-Kolors/Kolors"
		ib.text = String(isec.base)
		imd.text = String(isec.model)
		store.save_settings()))
	ib.text_changed.connect(func(t: String):
		isec.base = t.strip_edges()
		store.save_settings())
	im.add_child(UI.row("接口地址", ib))
	var ik := UI.le("图片 API Key", String(store.keys.get("img", "")), true)
	ik.text_changed.connect(func(t: String): store.set_key("img", t))
	im.add_child(UI.row("Key", ik))
	im.add_child(UI.tog("和 AI 模型用同一个 Key", bool(isec.get("same_key", false)), func(on: bool):
		isec.same_key = on
		store.save_settings()))
	imd.text_changed.connect(func(t: String):
		isec.model = t.strip_edges()
		store.save_settings())
	im.add_child(UI.row("模型", imd))
	# ---- 陪看视觉接口
	var vs := _section(body, "陪看视觉接口")
	var vsec: Dictionary = S.vision
	var vb := UI.le("接口地址", String(vsec.base))
	vb.text_changed.connect(func(t: String):
		vsec.base = t.strip_edges()
		store.save_settings())
	vs.add_child(UI.row("接口地址", vb))
	var vk := UI.le("视觉模型 Key（留空=用语音合成的百炼 Key）", String(store.keys.get("vision", "")), true)
	vk.text_changed.connect(func(t: String): store.set_key("vision", t))
	vs.add_child(UI.row("Key", vk))
	var vm := UI.le("模型名", String(vsec.model))
	vm.text_changed.connect(func(t: String):
		vsec.model = t.strip_edges()
		store.save_settings())
	vs.add_child(UI.row("模型", vm))

func _kfmt(n: int) -> String:
	if n >= 1000000:
		return "%.2fM" % (n / 1000000.0)
	if n >= 1000:
		return "%.1fk" % (n / 1000.0)
	return str(n)
