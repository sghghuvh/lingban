extends Node2D
# 灵伴：程序化绘制的“活”角色。
# spec 决定外形（人 / 动物 / 植物 / 物品 / 史莱姆）；emotion + gesture 决定表情和动作。
# 原点在脚底中心，角色向上（y 为负）画，基准身高约 240。

signal touched(zone: String, kind: String)  # kind: tap / double / pet / carry / drop / spam / wake

const SP = preload("res://scripts/species.gd")
const LW := 4.2

var spec: Dictionary = {}
var C := {}
var font: Font
var plan := "blob"
var art: Dictionary = {}   # 精致立绘：{"base": Texture2D, "tex": {情绪: Texture2D}}，空 = 用原来的简笔形象
var kind := ""
var rng := RandomNumberGenerator.new()
var _hash := 0

# ---- 状态
var t := 0.0
var emotion := "neutral"
var emo_timer := 0.0
var gesture := "none"
var g_t := 0.0
var g_dur := 0.0
var speaking := false
var talk := 0.0
var sleeping := false
var blink := 0.0
var _blink_t := 2.5
var _blink_phase := -1.0
var look := Vector2.ZERO
var look_target := Vector2.ZERO
var _look_t := 2.0
var finger_global := Vector2.INF
var petting := 0.0
var puff := 0.0

# ---- 移动（父节点坐标）
var home_y := 0.0
var x_min := 0.0
var x_max := 720.0
var wander := true
var walk_target := INF
var walk_speed := 110.0
var vel := Vector2.ZERO
var carried := false
var airborne := false
var sitting := false
var facing := 1.0
var face_turn := 0.0
var _idle_t := 4.0
var _sq := 0.0
var _sq_v := 0.0
var paused := false
var static_pose := false

# ---- 姿势（每帧计算）
var p_rot := 0.0
var p_lift := 0.0
var p_sx := 1.0
var p_sy := 1.0
var p_head_rot := 0.0
var p_head_dy := 0.0
var p_head_dx := 0.0
var p_arm := [0.18, 0.18]
var p_legl := [0.0, 0.0]
var p_tail := 0.0
var p_ear := 0.0
var p_wing := 0.0
var p_spin := 1.0
var p_trem := 0.0
var p_float := 0.0
var _ear_t := 3.0
var _ear_kick := 0.0

# ---- 布局
var L := {}
var root := Transform2D.IDENTITY
var _hits: Array = []  # [zone, center(char space), radius]  或 [zone, Rect2]

# ---- 粒子
var parts: Array = []
var _aura_t := 0.0

# ---- 触摸
var _press := false
var _press_pos := Vector2.ZERO
var _press_time := 0.0
var _press_zone := ""
var _moved := 0.0
var _last_dx := 0.0
var _strokes := 0
var _last_pet_emit := -9.0
var _grab_off := Vector2.ZERO
var _last_tap_t := -9.0
var _taps: Array = []
var _prev_finger := Vector2.ZERO
var _intent := ""
var _pet_dist := 0.0

func _ready() -> void:
	if spec.is_empty():
		set_spec(SP.default_spec())

func set_spec(s: Dictionary) -> void:
	spec = SP.normalize(s)
	plan = spec.plan
	kind = spec.kind
	_hash = abs(hash(spec.name + spec.label))
	rng.seed = _hash
	_setup_colors()
	_layout()
	queue_redraw()

func set_art(d: Dictionary) -> void:
	art = d
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS if not art.is_empty() else CanvasItem.TEXTURE_FILTER_PARENT_NODE
	_layout()
	queue_redraw()

# ================================================================== 颜色与布局
func _c(k: String) -> Color:
	return Color(String(spec.colors.get(k, "#ffffff")))

func _setup_colors() -> void:
	C.main = _c("main")
	C.second = _c("second")
	C.accent = _c("accent")
	C.skin = _c("skin")
	C.hair = _c("hair")
	C.eye = _c("eye")
	var lc := String(spec.colors.get("line", ""))
	C.line = Color(lc) if lc != "" else Color("#2b2340").lerp(C.main.darkened(0.75), 0.35)
	C.mouth = Color("#5b2333")
	C.tongue = Color("#f08ca0")
	C.white = Color(1, 1, 1)
	C.blush = Color(1.0, 0.42, 0.52)
	match plan:
		"humanoid":
			C.face = C.skin
		"animal":
			C.face = C.main
		"plant":
			C.face = C.second if kind in ["cactus", "sprout", "leafy", "tree"] else C.main
			if kind in ["cactus", "sprout", "leafy"]:
				C.face = C.main
			if kind in ["flower", "sunflower", "tulip"]:
				C.face = Color("#fff1c9") if kind != "sunflower" else Color("#8a5a2b")
			if kind == "mushroom":
				C.face = Color("#fff4e2")
			if kind == "tree":
				C.face = Color("#9b6b47")
		"object":
			C.face = C.main
			if kind == "phone":
				C.face = C.main
			if kind == "robot":
				C.face = Color("#1f2333")
		_:
			C.face = C.main

func _layout() -> void:
	var hs: float = spec.head.size
	L = {}
	match plan:
		"humanoid":
			var R := 64.0 * hs
			L.R = R
			L.hip = -50.0
			L.leg_len = 44.0
			L.shoulder_y = -110.0
			L.head = Vector2(0, -110.0 - R * 0.8)
			L.arm_len = 40.0
			L.arm_r = 8.5
			L.sh_x = 24.0
		"animal":
			var R2 := 70.0 * hs
			if kind in ["bird", "penguin", "owl", "chick", "duck"]:
				R2 = 66.0 * hs
			L.R = R2
			L.hip = -36.0
			L.leg_len = 30.0
			L.shoulder_y = -92.0
			L.head = Vector2(0, -92.0 - R2 * 0.74)
			L.arm_len = 30.0
			L.arm_r = 9.5
			L.sh_x = 27.0
		"plant":
			L.R = 46.0
			L.head = Vector2(0, -150)
			if kind in ["cactus", "sprout", "leafy"]:
				L.head = Vector2(0, -112)
			if kind == "mushroom":
				L.head = Vector2(0, -40)
			if kind == "tree":
				L.head = Vector2(0, -70)
			L.arm_len = 34.0
		"object":
			L.R = 54.0
			L.body = Vector2(0, -98)
			L.head = Vector2(0, -98)
			L.arm_len = 34.0
		_:
			L.R = 60.0
			L.body = Vector2(0, -70)
			L.head = Vector2(0, -78)
			L.arm_len = 20.0

	if not art.is_empty():
		L.head = Vector2(0, -290.0 * 0.8)
		L.R = 290.0 * 0.15

# ================================================================== 对外接口
func react(emo: String, ges := "none", hold := 4.0) -> void:
	if emo in SP.EMOTIONS:
		emotion = emo
		emo_timer = hold
		_emote_for(emo)
	if ges != "none" and ges in SP.GESTURES:
		play_gesture(ges)

func play_gesture(ges: String) -> void:
	if ges == "sleep":
		go_sleep()
		return
	if ges == "sit":
		sitting = true
		return
	gesture = ges
	g_t = 0.0
	g_dur = {"wave": 1.8, "nod": 1.0, "shake": 1.1, "jump": 0.75, "dance": 2.8, "spin": 0.9, "bow": 1.4, "clap": 1.5, "think": 2.6,
		"shrug": 1.4, "hug": 2.0, "point": 1.8, "stretch": 2.2, "cheer": 1.8, "pout": 2.6}.get(ges, 1.2)
	if ges in ["jump", "cheer", "dance"]:
		sitting = false

func set_speaking(on: bool) -> void:
	speaking = on
	if on and sleeping:
		sleeping = false

func go_sleep() -> void:
	sleeping = true
	sitting = true
	walk_target = INF
	gesture = "none"

func wake() -> void:
	if sleeping:
		sleeping = false
		sitting = false
		emotion = "sleepy"
		emo_timer = 2.0

func walk_to(x: float) -> void:
	if carried or sleeping:
		return
	sitting = false
	walk_target = clampf(x, x_min, x_max)

func set_ground(y: float, xa: float, xb: float) -> void:
	home_y = y
	x_min = xa
	x_max = xb
	if carried:
		return
	if position.y < y - 6.0:
		airborne = true
	else:
		position.y = y
	position.x = clampf(position.x, x_min, x_max)

func head_top_global() -> Vector2:
	var top := Vector2(0, -260.0 * float(spec.get("size", 1.0)))
	if L.has("head"):
		var extra := 0.0
		if plan in ["humanoid", "animal"]:
			extra = {"rabbit": 0.85, "fox": 0.45, "cat": 0.3, "dog": 0.3, "elf": 0.2}.get(String(spec.ears), 0.0)
			extra = maxf(extra, {"witch": 0.9, "crown": 0.4, "tophat": 0.5, "beanie": 0.35, "halo": 0.45, "bow": 0.15}.get(String(spec.hat), 0.0))
			extra = maxf(extra, {"unicorn": 0.55, "antlers": 0.55, "devil": 0.45, "curved": 0.25, "small": 0.25}.get(String(spec.horns), 0.0))
			if _ahoge():
				extra = maxf(extra, 0.35)
		top = Vector2(L.head.x, L.head.y + p_head_dy - L.R * (1.12 + extra))
	if plan == "plant" and kind in ["flower", "sunflower", "tulip"]:
		top.y -= 20.0
	return get_global_transform_with_canvas() * (root * top)

func body_center_global() -> Vector2:
	var c := Vector2(0, -110)
	if L.has("head"):
		c = (Vector2(0, -20) + L.head) * 0.5
	return get_global_transform_with_canvas() * (root * c)

# ================================================================== 每帧更新
func _process(delta: float) -> void:
	if paused:
		return
	if static_pose:
		queue_redraw()
		return
	t += delta
	_update_state(delta)
	_update_motion(delta)
	_pose(delta)
	_update_parts(delta)
	queue_redraw()

func _update_state(delta: float) -> void:
	if emo_timer > 0.0:
		emo_timer -= delta
		if emo_timer <= 0.0:
			emotion = "neutral"
	if gesture != "none":
		g_t += delta
		if g_t >= g_dur:
			gesture = "none"
	# 眨眼
	if _blink_phase < 0.0:
		_blink_t -= delta
		if _blink_t <= 0.0:
			_blink_phase = 0.0
	else:
		_blink_phase += delta / 0.16
		blink = sin(clampf(_blink_phase, 0.0, 1.0) * PI)
		if _blink_phase >= 1.0:
			_blink_phase = -1.0
			blink = 0.0
			_blink_t = rng.randf_range(2.0, 5.0) if rng.randf() > 0.2 else 0.18
	# 视线
	if finger_global != Vector2.INF:
		var me := body_center_global()
		var d := (finger_global - me)
		look_target = Vector2(clampf(d.x / 300.0, -1, 1), clampf(d.y / 300.0, -1, 1))
	else:
		_look_t -= delta
		if _look_t <= 0.0:
			_look_t = rng.randf_range(1.5, 4.5)
			look_target = Vector2(rng.randf_range(-0.8, 0.8), rng.randf_range(-0.5, 0.4)) if rng.randf() < 0.6 else Vector2.ZERO
	look = look.lerp(look_target, clampf(delta * 8.0, 0, 1))
	# 说话嘴型
	if speaking:
		var n := 0.55 + 0.45 * sin(t * 17.0) * sin(t * 5.3 + 1.0)
		talk = lerpf(talk, clampf(n, 0.1, 1.0), clampf(delta * 18.0, 0, 1))
	else:
		talk = lerpf(talk, 0.0, clampf(delta * 14.0, 0, 1))
	# 耳朵抖动
	_ear_t -= delta
	if _ear_t <= 0.0:
		_ear_t = rng.randf_range(2.0, 6.0)
		_ear_kick = 1.0
	_ear_kick = maxf(_ear_kick - delta * 5.0, 0.0)
	petting = maxf(petting - delta, 0.0)
	# 长按拎起
	if _press and not carried and _moved < 14.0 and t - _press_time > 0.5 and _intent == "":
		_start_carry()
	# 弹性挤压
	_sq_v += (-_sq * 170.0 - _sq_v * 12.0) * delta
	_sq += _sq_v * delta

func _update_motion(delta: float) -> void:
	if carried:
		return
	if airborne:
		vel.y += 2600.0 * delta
		position += vel * delta
		if position.y >= home_y:
			position.y = home_y
			airborne = false
			_sq_v = -clampf(vel.y * 0.0045, 1.0, 7.0)
			vel = Vector2.ZERO
		position.x = clampf(position.x, x_min, x_max)
		return
	position.y = home_y
	if walk_target != INF:
		var dx := walk_target - position.x
		if absf(dx) < 3.0:
			walk_target = INF
		else:
			var sp := walk_speed
			if plan in ["blob", "plant"]:
				sp *= 0.8
			position.x += signf(dx) * minf(absf(dx), sp * delta)
			facing = signf(dx)
	elif wander and not sleeping and gesture == "none" and not speaking:
		_idle_t -= delta
		if _idle_t <= 0.0:
			_idle_t = rng.randf_range(4.0, 10.0)
			var r := rng.randf()
			if r < 0.42 and x_max - x_min > 60.0:
				walk_to(rng.randf_range(x_min, x_max))
			elif r < 0.52:
				play_gesture("stretch")
			elif r < 0.6:
				sitting = not sitting
			elif r < 0.66:
				play_gesture("jump")
			elif r < 0.72:
				_emote("note")
	position.x = clampf(position.x, x_min, x_max)

# ================================================================== 姿势
func _ease_env() -> float:
	if gesture == "none" or g_dur <= 0.0:
		return 0.0
	var a := clampf(g_t / 0.18, 0.0, 1.0)
	var b := clampf((g_dur - g_t) / 0.22, 0.0, 1.0)
	return minf(a, b)

func _pose(delta: float) -> void:
	var br := sin(t * 2.1)
	var a0 := 0.16 + 0.03 * sin(t * 1.3)
	var a1 := 0.16 + 0.03 * sin(t * 1.3 + 1.2)
	var rot := 0.0
	var lift := 0.0
	var sx := 1.0
	var sy := 1.0 + 0.016 * br
	var hrot := 0.0
	var hdy := 1.4 * br
	var hdx := 0.0
	var legl := [0.0, 0.0]
	var tail := sin(t * 2.2) * 0.18
	var wing := sin(t * 2.0) * 0.08
	var spin := 1.0
	var trem := 0.0
	var turn := 0.0
	puff = maxf(puff - delta * 2.0, 0.0)
	# 情绪带来的身体语言
	match emotion:
		"happy":
			tail = sin(t * 6.0) * 0.35
			hrot = sin(t * 1.6) * 0.05
		"excited":
			lift = -absf(sin(t * 7.5)) * 7.0
			tail = sin(t * 11.0) * 0.45
			a0 = 0.45 + sin(t * 7.5) * 0.25
			a1 = 0.45 - sin(t * 7.5) * 0.25
			wing = sin(t * 10.0) * 0.3
		"love":
			rot = sin(t * 2.0) * 0.06
			tail = sin(t * 4.0) * 0.3
			hrot = 0.1
		"sad":
			hdy += 5.0
			a0 = 0.06
			a1 = 0.06
			tail = -0.35 + sin(t) * 0.04
			sy = 0.97 + 0.01 * br
		"angry":
			trem = sin(t * 40.0) * 1.2
			a0 = -1.05
			a1 = -1.05
			tail = sin(t * 14.0) * 0.12
			puff = 1.0
		"scared":
			trem = sin(t * 45.0) * 2.0
			a0 = -0.6
			a1 = -0.6
			tail = -0.5
			sy = 0.95
		"shy":
			hrot = 0.12
			a0 = -0.5
			a1 = -0.5
			rot = sin(t * 1.8) * 0.04
			turn = -0.4
		"thinking":
			hrot = -0.1
			a1 = -1.78
		"sleepy":
			hdy += 3.0
			hrot = sin(t * 0.8) * 0.08
			sy = 0.98 + 0.012 * br
		"smug":
			hrot = -0.08
			a0 = -1.0
			a1 = 0.7
			turn = 0.25
		"surprised":
			lift = -4.0
			a0 = 0.7
			a1 = 0.7
			sy = 1.04
	# 手势
	var e := _ease_env()
	var gp := clampf(g_t / maxf(g_dur, 0.01), 0.0, 1.0)
	if e > 0.0:
		match gesture:
			"wave":
				a1 = lerpf(a1, 2.55 + sin(t * 13.0) * 0.38, e)
				hrot = lerpf(hrot, 0.08, e)
			"nod":
				hdy += sin(gp * PI * 4.0) * 7.0 * e
				hrot += sin(gp * PI * 4.0) * 0.03 * e
			"shake":
				hrot += sin(gp * PI * 6.0) * 0.24 * e
				hdx += sin(gp * PI * 6.0) * 3.0 * e
			"jump":
				var k := clampf((gp - 0.12) / 0.8, 0.0, 1.0)
				if gp < 0.12:
					sy = 1.0 - 0.18 * (gp / 0.12)
					sx = 1.0 + 0.1 * (gp / 0.12)
				else:
					lift += -sin(k * PI) * 80.0
					sy = 1.0 + 0.08 * sin(k * PI)
				a0 = lerpf(a0, 2.2, e * sin(k * PI))
				a1 = lerpf(a1, 2.2, e * sin(k * PI))
			"dance":
				a0 = lerpf(a0, 1.3 + sin(t * 8.0) * 1.2, e)
				a1 = lerpf(a1, 1.3 - sin(t * 8.0) * 1.2, e)
				rot += sin(t * 4.0) * 0.14 * e
				lift += -absf(sin(t * 8.0)) * 10.0 * e
				legl = [maxf(sin(t * 8.0), 0.0) * 10.0 * e, maxf(-sin(t * 8.0), 0.0) * 10.0 * e]
				tail = sin(t * 8.0) * 0.5
			"spin":
				spin = cos(gp * TAU)
				lift += -sin(gp * PI) * 16.0
			"bow":
				hdy += 14.0 * e
				sy -= 0.07 * e
				a0 = lerpf(a0, -0.35, e)
				a1 = lerpf(a1, -0.35, e)
			"clap":
				var cc := -0.95 + sin(t * 17.0) * 0.28
				a0 = lerpf(a0, cc, e)
				a1 = lerpf(a1, cc, e)
				lift += -absf(sin(t * 8.5)) * 3.0 * e
			"think":
				a1 = lerpf(a1, -1.78, e)
				hrot = lerpf(hrot, 0.14, e)
				look_target = Vector2(0.6, -0.8)
			"shrug":
				a0 = lerpf(a0, 1.1, e)
				a1 = lerpf(a1, 1.1, e)
				hrot = lerpf(hrot, 0.16, e)
				hdy -= 3.0 * e
			"hug":
				var hh := (sin(gp * PI * 2.0 - PI / 2.0) + 1.0) * 0.5
				a0 = lerpf(a0, lerpf(1.6, -0.7, hh), e)
				a1 = lerpf(a1, lerpf(1.6, -0.7, hh), e)
				rot += sin(t * 3.0) * 0.05 * e
			"point":
				a1 = lerpf(a1, 1.55, e)
				hrot = lerpf(hrot, -0.06, e)
			"stretch":
				a0 = lerpf(a0, 2.9, e)
				a1 = lerpf(a1, 2.9, e)
				sy += 0.07 * e
				sx -= 0.03 * e
			"cheer":
				a0 = lerpf(a0, 2.65 + sin(t * 14.0) * 0.2, e)
				a1 = lerpf(a1, 2.65 - sin(t * 14.0) * 0.2, e)
				lift += -absf(sin(t * 7.0)) * 14.0 * e
			"pout":
				a0 = lerpf(a0, -1.2, e)
				a1 = lerpf(a1, -1.2, e)
				turn = -0.7 * e
				hrot = -0.1 * e
				puff = 1.0
	# 走路
	if walk_target != INF and not carried:
		var ph := t * 11.0
		legl = [maxf(sin(ph), 0.0) * 9.0, maxf(-sin(ph), 0.0) * 9.0]
		lift += -absf(sin(ph)) * 4.0
		a0 += sin(ph) * 0.3
		a1 -= sin(ph) * 0.3
		turn = facing * 0.45
		if plan in ["blob", "plant"]:
			lift = -absf(sin(t * 7.0)) * 14.0
			sy = 1.0 + sin(t * 14.0) * 0.05
	# 被拎着
	if carried:
		rot = clampf(-vel.x * 0.0012, -0.45, 0.45)
		a0 = 0.9 + sin(t * 3.0) * 0.1
		a1 = 0.9 - sin(t * 3.0) * 0.1
		legl = [sin(t * 4.0) * 3.0 + 3.0, -sin(t * 4.0) * 3.0 + 3.0]
		tail = sin(t * 5.0) * 0.4
		sy = 1.04
	# 坐下 / 睡觉
	if sitting and walk_target == INF and not carried:
		lift += 10.0
		sy *= 0.95
		legl = [-6.0, -6.0]
	if sleeping:
		hrot = 0.16 + sin(t * 0.9) * 0.03
		hdy += 4.0
		sy = 0.95 + 0.02 * sin(t * 1.3)
		a0 = 0.05
		a1 = 0.05
		tail = 0.1
	if petting > 0.0:
		hrot = sin(t * 5.0) * 0.08
		tail = sin(t * 9.0) * 0.5
	# 飘浮类
	var fl := 0.0
	if (plan == "blob" and kind in ["ghost", "spirit", "fish", "jelly"]) or (plan == "object" and kind == "cloud"):
		fl = -26.0 + sin(t * 1.6) * 7.0
	# 弹性
	sy *= 1.0 + _sq * 0.5
	sx *= 1.0 - _sq * 0.35
	p_rot = rot
	p_lift = lift
	p_sx = sx
	p_sy = sy
	p_head_rot = hrot
	p_head_dy = hdy
	p_head_dx = hdx
	p_arm = [a0, a1]
	p_legl = legl
	p_tail = tail
	p_wing = wing + (sin(t * 12.0) * 0.4 if carried or airborne else 0.0)
	p_spin = spin
	p_trem = trem
	p_float = fl
	face_turn = lerpf(face_turn, turn, clampf(delta * 6.0, 0, 1))
	p_ear = _ear_kick * 0.25 * sin(t * 30.0)

# ================================================================== 形状工具
static func ell(c: Vector2, rx: float, ry: float, n := 30) -> PackedVector2Array:
	var p := PackedVector2Array()
	p.resize(n)
	for i in n:
		var a := TAU * float(i) / float(n)
		p[i] = c + Vector2(cos(a) * rx, sin(a) * ry)
	return p

static func ell_arc(c: Vector2, rx: float, ry: float, a0: float, a1: float, n := 16) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n + 1:
		var a := lerpf(a0, a1, float(i) / float(n))
		p.append(c + Vector2(cos(a) * rx, sin(a) * ry))
	return p

static func supell(c: Vector2, rx: float, ry: float, pw := 4.0, n := 40) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n:
		var a := TAU * float(i) / float(n)
		var ca := cos(a)
		var sa := sin(a)
		p.append(c + Vector2(signf(ca) * pow(absf(ca), 2.0 / pw) * rx, signf(sa) * pow(absf(sa), 2.0 / pw) * ry))
	return p

static func rrect(c: Vector2, w: float, h: float, r: float, seg := 5) -> PackedVector2Array:
	r = minf(r, minf(w, h) * 0.5)
	var p := PackedVector2Array()
	var cs := [Vector2(c.x + w * 0.5 - r, c.y - h * 0.5 + r), Vector2(c.x + w * 0.5 - r, c.y + h * 0.5 - r), Vector2(c.x - w * 0.5 + r, c.y + h * 0.5 - r), Vector2(c.x - w * 0.5 + r, c.y - h * 0.5 + r)]
	var starts := [-PI / 2.0, 0.0, PI / 2.0, PI]
	for k in 4:
		for i in seg + 1:
			var a: float = starts[k] + PI / 2.0 * float(i) / float(seg)
			p.append(cs[k] + Vector2(cos(a), sin(a)) * r)
	return p

static func cap(a: Vector2, b: Vector2, r: float, seg := 8) -> PackedVector2Array:
	var p := PackedVector2Array()
	var ang := (b - a).angle()
	for i in seg + 1:
		var q := ang - PI / 2.0 + PI * float(i) / float(seg)
		p.append(b + Vector2(cos(q), sin(q)) * r)
	for i in seg + 1:
		var q2 := ang + PI / 2.0 + PI * float(i) / float(seg)
		p.append(a + Vector2(cos(q2), sin(q2)) * r)
	return p

static func heart_pts(c: Vector2, s: float, n := 36) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n:
		var tt := TAU * float(i) / float(n)
		var x := 16.0 * pow(sin(tt), 3)
		var y := -(13.0 * cos(tt) - 5.0 * cos(2.0 * tt) - 2.0 * cos(3.0 * tt) - cos(4.0 * tt))
		p.append(c + Vector2(x, y) * (s / 17.0))
	return p

static func star_pts(c: Vector2, ro: float, ri: float, k := 5, rot := -PI / 2.0) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in k * 2:
		var r := ro if i % 2 == 0 else ri
		var a := rot + PI * float(i) / float(k)
		p.append(c + Vector2(cos(a), sin(a)) * r)
	return p

static func bez(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, n := 12) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in n + 1:
		var u := float(i) / float(n)
		var v := 1.0 - u
		p.append(p0 * v * v * v + p1 * 3.0 * v * v * u + p2 * 3.0 * v * u * u + p3 * u * u * u)
	return p

static func stroke_poly(pts: PackedVector2Array, w0: float, w1: float) -> PackedVector2Array:
	var n := pts.size()
	var left := PackedVector2Array()
	var right := PackedVector2Array()
	for i in n:
		var d := (pts[mini(i + 1, n - 1)] - pts[maxi(i - 1, 0)]).normalized()
		var nr := Vector2(-d.y, d.x)
		var w := lerpf(w0, w1, float(i) / float(maxi(n - 1, 1))) * 0.5
		left.append(pts[i] + nr * w)
		right.append(pts[i] - nr * w)
	right.reverse()
	left.append_array(right)
	return left

func _xf(x: Transform2D) -> void:
	draw_set_transform_matrix(x)

func fill(p: PackedVector2Array, col: Color, lw := LW) -> void:
	if p.size() < 3:
		return
	draw_colored_polygon(p, col)
	if lw > 0.0:
		var q := p.duplicate()
		q.append(p[0])
		draw_polyline(q, C.line, lw, true)

func fill_sh(p: PackedVector2Array, col: Color, lw := LW, amt := 1.0) -> void:
	if p.size() < 3:
		return
	var miny := 1e9
	var maxy := -1e9
	for v in p:
		miny = minf(miny, v.y)
		maxy = maxf(maxy, v.y)
	var hgt := maxf(maxy - miny, 1.0)
	var cols := PackedColorArray()
	var top := col.lightened(0.07 * amt)
	var bot := col.darkened(0.16 * amt)
	for v in p:
		cols.append(top.lerp(bot, smoothstep(0.35, 1.0, (v.y - miny) / hgt)))
	draw_polygon(p, cols)
	if lw > 0.0:
		var q := p.duplicate()
		q.append(p[0])
		draw_polyline(q, C.line, lw, true)

func outline(p: PackedVector2Array, col: Color, w := LW, closed := true) -> void:
	var q := p.duplicate()
	if closed and p.size() > 0:
		q.append(p[0])
	draw_polyline(q, col, w, true)

func dot(c: Vector2, r: float, col: Color) -> void:
	draw_circle(c, r, col)

func ring(c: Vector2, r: float, col: Color, lw := LW) -> void:
	draw_arc(c, r, 0.0, TAU, 28, col, lw, true)

func circle_o(c: Vector2, r: float, col: Color, lw := LW) -> void:
	draw_circle(c, r, col)
	if lw > 0.0:
		draw_arc(c, r, 0.0, TAU, 28, C.line, lw, true)

func line(a: Vector2, b: Vector2, col: Color, w := LW) -> void:
	draw_line(a, b, col, w, true)

# ================================================================== 绘制入口
func _draw() -> void:
	_hits.clear()
	if spec.is_empty():
		return
	var s: float = spec.size
	root = Transform2D(p_rot, Vector2(facing * p_spin * p_sx * s, p_sy * s), 0.0, Vector2(p_trem, p_lift + p_float * s))
	_draw_shadow(s)
	if spec.aura == "glow":
		_xf(root)
		var gc := Vector2(0, -120)
		for i in 6:
			draw_circle(gc, 150.0 - i * 18.0, Color(C.accent.r, C.accent.g, C.accent.b, 0.035 + i * 0.012))
	if not art.is_empty():
		_draw_art()
	else:
		match plan:
			"humanoid", "animal":
				_draw_biped()
			"plant":
				_draw_plant()
			"object":
				_draw_object()
			_:
				_draw_blob()
	_draw_parts(s)
	draw_set_transform_matrix(Transform2D.IDENTITY)

# 精致立绘：一张（或每个情绪一张）透明底图，用同一套走路、跳跃、呼吸、被摸的动作驱动
func _draw_art() -> void:
	var tex: Texture2D = art.get("base")
	var m: Dictionary = art.get("tex", {})
	var key := "sleepy" if sleeping else emotion
	if m.has(key):
		tex = m[key]
	if m.has("blink") and blink > 0.6 and not sleeping:
		tex = m["blink"]
	if tex == null:
		return
	var tw := float(tex.get_width())
	var th := float(tex.get_height())
	var H := 290.0
	var W := H * tw / th
	if W > 240.0:
		W = 240.0
		H = W * th / tw
	# ---- 身体语言：呼吸 + 情绪 + 手势 + 说话点头，再叠加“头发裙摆迟滞摇摆”
	var amp := 1.6
	var bob := 0.0
	var tilt := 0.0
	var sqy := 1.0 + 0.012 * sin(t * 2.2)
	var sqx := 1.0
	var shk := 0.0
	var slide := 0.0
	match emotion:
		"happy":
			amp = 3.2
			bob = -absf(sin(t * 3.4)) * 3.0
			tilt = sin(t * 1.7) * 0.03
		"excited":
			amp = 5.0
			bob = -absf(sin(t * 7.0)) * 9.0
			tilt = sin(t * 3.5) * 0.05
		"love":
			amp = 3.0
			tilt = sin(t * 2.0) * 0.06
			bob = -absf(sin(t * 2.4)) * 2.0
		"sad":
			sqy *= 0.965
			tilt = -0.025
			amp = 0.8
		"angry":
			shk = sin(t * 38.0) * 1.6
			sqx = 1.02
			amp = 0.6
		"scared":
			shk = sin(t * 44.0) * 2.4
			sqy *= 0.95
			amp = 0.4
		"shy":
			tilt = 0.05 + sin(t * 1.8) * 0.02
			slide = -5.0
			amp = 2.0
		"surprised":
			sqy *= 1.035
			bob = -4.0 * maxf(0.0, 1.0 - fmod(t, 3.0) * 3.0)
		"thinking":
			tilt = -0.05
			amp = 1.0
		"smug":
			tilt = 0.03
			sqy *= 1.015
		"sleepy":
			sqy *= 0.985
			tilt = sin(t * 0.9) * 0.025
			amp = 0.6
	if sleeping:
		tilt = sin(t * 0.8) * 0.03 - 0.03
		sqy = 0.985 + 0.015 * sin(t * 1.2)
		amp = 0.4
	if talk > 0.15:
		tilt += sin(t * 9.0) * 0.012 * talk
		sqy *= 1.0 + 0.014 * talk
		bob -= talk * 0.8
	if gesture != "none" and g_dur > 0.0:
		var gp := clampf(g_t / g_dur, 0.0, 1.0)
		var env := sin(gp * PI)
		match gesture:
			"nod":
				sqy *= 1.0 - 0.035 * absf(sin(gp * PI * 3.0))
				tilt += 0.05 * sin(gp * PI * 3.0)
			"shake":
				shk += sin(gp * PI * 7.0) * 3.0 * env
				tilt += sin(gp * PI * 7.0) * 0.03 * env
			"wave":
				tilt += sin(gp * PI * 6.0) * 0.045 * env
				bob -= 2.0 * env
			"bow":
				tilt += 0.16 * env
				sqy *= 1.0 - 0.05 * env
			"dance":
				tilt += sin(t * 6.0) * 0.1
				bob -= absf(sin(t * 6.0)) * 8.0
				slide += sin(t * 3.0) * 8.0
				amp = 6.0
			"spin":
				sqx *= cos(gp * TAU)
			"jump", "cheer":
				sqy *= 1.0 + 0.05 * env
				bob -= 4.0 * env
			"clap":
				sqy *= 1.0 - 0.02 * absf(sin(gp * PI * 8.0))
				bob -= absf(sin(gp * PI * 8.0)) * 3.0
			"pout":
				tilt += 0.04 * env
				sqx *= 1.0 + 0.02 * env
			"shrug":
				bob -= 4.0 * env
				sqy *= 1.0 - 0.02 * env
			"stretch":
				sqy *= 1.0 + 0.06 * env
			"hug":
				sqx *= 1.0 - 0.04 * env
			"think":
				tilt -= 0.05 * env
	if petting > 0.0:
		tilt += sin(t * 12.0) * 0.02 * clampf(petting, 0.0, 1.0)
		sqy *= 1.0 + 0.012 * sin(t * 12.0) * clampf(petting, 0.0, 1.0)
	var tint := Color(0.82, 0.84, 0.95) if sleeping else Color.WHITE
	_xf(root * Transform2D(tilt, Vector2(sqx, sqy), 0.0, Vector2(slide + shk, bob)))
	var N := 28
	var sh := th / float(N)
	var dh := H / float(N)
	for i in N:
		var f := 1.0 - (float(i) + 0.5) / float(N)   # 0=脚 1=头顶
		var ox := amp * pow(f, 1.5) * sin(t * 1.7 - f * 1.4)
		ox += amp * 0.6 * (1.0 - f) * sin(t * 2.3 + 1.0) * (1.0 if f < 0.45 else 0.0)
		draw_texture_rect_region(tex, Rect2(-W * 0.5 + ox, -H + float(i) * dh, W, dh + 0.7), Rect2(0.0, float(i) * sh, tw, sh + 0.5), tint)
	_hits.append(["body", Rect2(-W * 0.3, -H * 0.62, W * 0.6, H * 0.5)])
	_hits.append(["head", Vector2(0, -H * 0.8), H * 0.16])
	_hits.append(["face", Vector2(0, -H * 0.76), H * 0.11])

func _draw_shadow(s: float) -> void:
	var gy := 0.0
	if (carried or airborne) and scale.y > 0.01:
		gy = (home_y - position.y) / scale.y
	_xf(Transform2D(0.0, Vector2(s, s), 0.0, Vector2(0, gy)))
	var h := clampf((-(p_lift + p_float) + gy / maxf(s, 0.01)) / 160.0, 0.0, 1.0)
	var w := 62.0 * (1.0 - h * 0.45)
	if plan == "plant" and not kind in ["mushroom", "tree"]:
		w = 55.0
	draw_colored_polygon(ell(Vector2(0, -2), w, w * 0.2, 24), Color(0, 0, 0, 0.18 * (1.0 - h * 0.6)))

# ================================================================== 人形 / 动物
func _hand_pos(side: int) -> Vector2:
	var a: float = p_arm[0 if side < 0 else 1]
	var r := -a * float(side)
	var sh := Vector2(L.sh_x * side, L.shoulder_y)
	return sh + Vector2(0, L.arm_len).rotated(r)

func _draw_biped() -> void:
	var R: float = L.R
	var animal := plan == "animal"
	var birdish := animal and kind in ["bird", "penguin", "owl", "chick", "duck"]
	var hc: Vector2 = L.head + Vector2(p_head_dx, p_head_dy)
	var hxf := root * Transform2D(p_head_rot, hc)
	var fur: Color = C.main if animal else C.hair
	# 翅膀
	if spec.wings != "none":
		_xf(root)
		_draw_wings(Vector2(0, L.shoulder_y + 8.0), animal)
	# 尾巴
	if spec.tail != "none":
		var tb := Vector2(6, L.hip - 6.0)
		_xf(root * Transform2D(p_tail, tb))
		_draw_tail(C.main if animal else C.hair)
	# 后发
	_xf(hxf)
	_draw_hair_back(R)
	# 腿
	var legc: Color = C.main
	var shoe := Color("#3a2f45")
	if not animal:
		legc = C.skin
		if spec.outfit in ["tshirt", "hoodie", "sweater", "suit", "armor", "kimono", "none"]:
			legc = C.second.darkened(0.25) if C.second.get_luminance() < 0.8 else Color("#3d4663")
		if spec.outfit == "overalls":
			legc = C.main
		if spec.outfit == "armor":
			legc = Color("#8d93a3")
		shoe = C.accent.darkened(0.35) if spec.outfit in ["dress", "apron"] else Color("#3a2f45")
	for side in [-1, 1]:
		var lift: float = p_legl[0 if side < 0 else 1]
		var hip := Vector2(14.0 * side if not animal else 17.0 * side, L.hip)
		_xf(root * Transform2D(0.0, hip + Vector2(0, -lift)))
		var ll: float = L.leg_len
		if birdish:
			line(Vector2(0, 0), Vector2(0, ll), Color("#f2a541"), 5.0)
			fill(ell(Vector2(4.0 * side, ll), 11, 5, 14), Color("#f2a541"), 3.0)
		elif animal:
			fill_sh(cap(Vector2(0, 0), Vector2(0, ll - 6), 11.5), C.main)
			fill(ell(Vector2(1.5 * side, ll - 3), 13, 8, 18), C.main.lerp(C.second, 0.35))
		else:
			fill_sh(cap(Vector2(0, 0), Vector2(0, ll - 4), 9.0), legc)
			fill(ell(Vector2(3.0 * side, ll - 1), 12, 7, 18), shoe)
	# 身体
	_xf(root)
	if animal:
		_draw_animal_body(R, birdish)
	else:
		_draw_outfit()
	_hits.append(["body", Rect2(-36, L.shoulder_y, 72, -L.shoulder_y + L.hip + 20)])
	# 手臂（放下的先画；举起来的画在头前面，否则会被大脑袋挡住）
	_draw_arms(false, animal, birdish)
	# 头
	_xf(hxf)
	_draw_ears(R, fur, true)
	_draw_head_shape(R, C.face)
	if animal:
		_draw_animal_face_base(R, birdish)
	_draw_ears(R, fur, false)
	_draw_face(Vector2(face_turn * R * 0.14, R * 0.05), R)
	_draw_hair_front(R)
	_draw_brows(Vector2(face_turn * R * 0.14, R * 0.05), R)
	_draw_horns(R)
	_draw_hat(R)
	_draw_glasses(Vector2(face_turn * R * 0.14, R * 0.05), R)
	_draw_arms(true, animal, birdish)
	# 领口饰品：画在下巴下方（头的后面一层看不见，所以放在头之后）
	if spec.neck != "none" and spec.neck != "tie":
		_xf(root)
		var chin_y: float = L.head.y + p_head_dy + R * 0.86
		_draw_neck(Vector2(0, maxf(chin_y, L.shoulder_y - 2.0)), animal)
	_hits.append(["head", hc + Vector2(0, -R * 0.3), R * 0.85])
	_hits.append(["face", hc + Vector2(0, R * 0.35), R * 0.7])

func _arm_raised(a: float) -> bool:
	return a > 1.25 or a < -1.7

func _draw_arms(raised: bool, animal: bool, birdish: bool) -> void:
	for side in [-1, 1]:
		var a: float = p_arm[0 if side < 0 else 1]
		if _arm_raised(a) != raised:
			continue
		var lift := clampf((a - 1.1) / 1.2, 0.0, 1.0)
		var sh := Vector2((L.sh_x + 7.0 * lift) * side, L.shoulder_y + 3.0 - 3.0 * lift)
		_xf(root * Transform2D(-a * float(side), sh))
		var al: float = L.arm_len * (1.0 + 0.32 * lift)
		if birdish:
			var wp := PackedVector2Array([Vector2(-3, -4), Vector2(9 * side, 6), Vector2(8 * side, al), Vector2(-2 * side, al - 6)])
			if side < 0:
				wp.reverse()
			fill_sh(wp, C.main.darkened(0.1))
		elif animal:
			fill_sh(cap(Vector2(0, 0), Vector2(0, al - 8), L.arm_r), C.main)
			circle_o(Vector2(0, al - 4), 10.5, C.main.lerp(C.second, 0.25))
		else:
			var sleeve: Color = C.main
			var long: bool = spec.outfit in ["hoodie", "suit", "robe", "kimono", "sweater", "armor"]
			if spec.outfit == "overalls":
				sleeve = C.second
			if long:
				fill_sh(cap(Vector2(0, 0), Vector2(0, al - 8), L.arm_r + 1.0), sleeve.darkened(0.04))
				if spec.outfit in ["robe", "kimono"]:
					fill(PackedVector2Array([Vector2(-11, al - 18), Vector2(11, al - 18), Vector2(14, al - 4), Vector2(-14, al - 4)]), sleeve.darkened(0.08))
			else:
				fill_sh(cap(Vector2(0, 0), Vector2(0, al - 8), L.arm_r), C.skin)
				fill(cap(Vector2(0, 0), Vector2(0, 10), L.arm_r + 2.5), sleeve)
			circle_o(Vector2(0, al - 3), 9.0, C.skin)
		var hp := root * (sh + Vector2(0, al).rotated(-a * float(side)))
		_hits.append(["hand", root.affine_inverse() * hp, 16.0])

func _draw_head_shape(R: float, col: Color) -> void:
	var p: PackedVector2Array
	match spec.head.shape:
		"oval":
			p = ell(Vector2.ZERO, R * 0.92, R * 1.04, 40)
		"wide":
			p = ell(Vector2.ZERO, R * 1.1, R * 0.9, 40)
		"square":
			p = supell(Vector2.ZERO, R * 0.98, R * 0.92, 4.5, 44)
		"heart":
			p = PackedVector2Array()
			for i in 44:
				var a := TAU * float(i) / 44.0
				var rr := R * (1.0 - 0.1 * pow(maxf(sin(a), 0.0), 3.0))
				var q := Vector2(cos(a) * rr * 1.02, sin(a) * rr * 0.95)
				if sin(a) > 0.0:
					q.x *= 1.0 - 0.25 * sin(a)
				p.append(q)
		_:
			p = ell(Vector2.ZERO, R, R * 0.94, 40)
	if puff > 0.0:
		for i in p.size():
			var v: Vector2 = p[i]
			if v.y > 0.0 and absf(v.x) > R * 0.5:
				p[i] = v + Vector2(signf(v.x) * puff * R * 0.08, 0)
	fill_sh(p, col, LW, 0.7)
	if spec.material in ["shiny", "glass", "metal"]:
		draw_colored_polygon(ell(Vector2(-R * 0.4, -R * 0.5), R * 0.22, R * 0.12, 16), Color(1, 1, 1, 0.35))

func _draw_animal_body(R: float, birdish: bool) -> void:
	var top: float = L.shoulder_y
	var bot: float = L.hip + 14.0
	var w := 38.0
	match spec.body.shape:
		"slim", "tall":
			w = 31.0
		"chubby", "round", "pear":
			w = 42.0
	var cy := (top + bot) * 0.5
	var p := ell(Vector2(0, cy), w, (bot - top) * 0.58, 36)
	fill_sh(p, C.main)
	var belly: bool = spec.body.pattern == "belly" or birdish or kind in ["fox", "dog", "cat", "rabbit", "hamster", "bear", "penguin", "squirrel", "raccoon", "deer", "dino", "dragon", "koala", "monkey", "wolf"]
	if belly:
		fill(ell(Vector2(0, cy + 6.0), w * 0.62, (bot - top) * 0.42, 30), C.second, 0.0)
	_draw_pattern(Vector2(0, cy), w * 0.8, (bot - top) * 0.45, true)

func _draw_outfit() -> void:
	var top: float = L.shoulder_y
	var hip: float = L.hip
	var ws := 24.0
	var wh := 27.0
	match spec.body.shape:
		"slim", "tall":
			ws = 21.0
			wh = 23.0
		"chubby", "round":
			ws = 27.0
			wh = 33.0
		"pear":
			ws = 22.0
			wh = 33.0
		"square":
			ws = 28.0
			wh = 28.0
	var main: Color = C.main
	var o: String = spec.outfit
	var torso := PackedVector2Array([Vector2(-ws, top + 4), Vector2(-ws + 6, top - 1), Vector2(ws - 6, top - 1), Vector2(ws, top + 4), Vector2(wh, hip + 6), Vector2(-wh, hip + 6)])
	match o:
		"dress", "apron":
			var sk := PackedVector2Array([Vector2(-ws, top + 4), Vector2(-ws + 6, top - 1), Vector2(ws - 6, top - 1), Vector2(ws, top + 4), Vector2(wh - 2, hip - 8),
				Vector2(wh + 18, hip + 18), Vector2(0, hip + 22), Vector2(-wh - 18, hip + 18), Vector2(-wh + 2, hip - 8)])
			fill_sh(sk, main)
			if o == "apron":
				fill(rrect(Vector2(0, hip + 2), 34, 34, 6), Color(1, 1, 1, 0.95), 3.0)
				fill(rrect(Vector2(0, top + 20), 26, 22, 5), Color(1, 1, 1, 0.95), 3.0)
				line(Vector2(-13, top + 9), Vector2(-ws + 5, top), Color(1, 1, 1), 4.0)
				line(Vector2(13, top + 9), Vector2(ws - 5, top), Color(1, 1, 1), 4.0)
			else:
				line(Vector2(-wh + 4, hip - 6), Vector2(wh - 4, hip - 6), main.darkened(0.25), 3.0)
		"robe":
			var rb := PackedVector2Array([Vector2(-ws, top + 4), Vector2(-ws + 6, top - 1), Vector2(ws - 6, top - 1), Vector2(ws, top + 4), Vector2(wh + 12, -8), Vector2(-wh - 12, -8)])
			fill_sh(rb, main)
			line(Vector2(0, top + 2), Vector2(0, -10), main.darkened(0.3), 3.0)
			fill(PackedVector2Array([Vector2(-wh - 3, hip - 4), Vector2(wh + 3, hip - 4), Vector2(wh + 4, hip + 4), Vector2(-wh - 4, hip + 4)]), C.accent, 3.0)
		"overalls":
			fill_sh(torso, C.second)
			var bib := PackedVector2Array([Vector2(-ws + 6, top + 16), Vector2(ws - 6, top + 16), Vector2(wh, hip + 6), Vector2(-wh, hip + 6)])
			fill_sh(bib, main)
			line(Vector2(-ws + 7, top + 16), Vector2(-ws + 9, top), main.darkened(0.15), 5.0)
			line(Vector2(ws - 7, top + 16), Vector2(ws - 9, top), main.darkened(0.15), 5.0)
			dot(Vector2(-ws + 9, top + 18), 3.0, C.accent)
			dot(Vector2(ws - 9, top + 18), 3.0, C.accent)
		"kimono":
			fill_sh(torso, main)
			line(Vector2(-ws + 6, top), Vector2(6, hip - 4), main.lightened(0.5), 4.0)
			line(Vector2(ws - 6, top), Vector2(-2, top + 20), main.darkened(0.3), 3.0)
			fill(PackedVector2Array([Vector2(-wh, hip - 16), Vector2(wh, hip - 16), Vector2(wh + 1, hip - 4), Vector2(-wh - 1, hip - 4)]), C.accent, 3.0)
		"suit":
			fill_sh(torso, main)
			fill(PackedVector2Array([Vector2(-10, top), Vector2(10, top), Vector2(0, top + 26)]), Color(1, 1, 1), 2.5)
			line(Vector2(-10, top), Vector2(-4, top + 34), main.darkened(0.35), 3.0)
			line(Vector2(10, top), Vector2(4, top + 34), main.darkened(0.35), 3.0)
			dot(Vector2(0, top + 38), 2.5, main.darkened(0.4))
			dot(Vector2(0, top + 48), 2.5, main.darkened(0.4))
		"armor":
			fill_sh(torso, main.lerp(Color("#c9ced8"), 0.5), LW, 1.6)
			line(Vector2(-wh + 6, top + 26), Vector2(wh - 6, top + 26), C.line, 2.5)
			line(Vector2(0, top + 4), Vector2(0, hip), C.line, 2.0)
			for sd in [-1, 1]:
				fill_sh(ell(Vector2((ws + 1) * sd, top + 6), 13, 10, 18), main.lerp(Color("#d6dae3"), 0.4), LW, 1.6)
			draw_colored_polygon(ell(Vector2(-8, top + 14), 6, 3, 10), Color(1, 1, 1, 0.5))
		"hoodie":
			fill_sh(PackedVector2Array([Vector2(-ws - 6, top + 2), Vector2(ws + 6, top + 2), Vector2(ws - 2, top - 10), Vector2(-ws + 2, top - 10)]), main.darkened(0.12))
			fill_sh(torso, main)
			fill(rrect(Vector2(0, hip - 6), wh * 1.1, 14, 5), main.darkened(0.08), 3.0)
			line(Vector2(-5, top + 2), Vector2(-6, top + 20), Color(1, 1, 1), 2.5)
			line(Vector2(5, top + 2), Vector2(6, top + 20), Color(1, 1, 1), 2.5)
		"sweater":
			fill_sh(torso, main)
			for i in 4:
				line(Vector2(-wh + 3 + i * 0.0, hip + 2 - i * 0.0), Vector2(wh - 3, hip + 2), main.darkened(0.15), 2.0)
				break
			for x in range(-int(wh) + 6, int(wh) - 3, 6):
				line(Vector2(x, hip - 2), Vector2(x, hip + 5), main.darkened(0.2), 2.0)
		_:
			fill_sh(torso, main)
			fill(ell(Vector2(0, top + 1), 9, 4, 14), C.skin, 2.0)
	if not o in ["dress", "apron", "robe"]:
		_draw_pattern(Vector2(0, (top + hip) * 0.5 + 4.0), wh * 0.7, (hip - top) * 0.32, false)
	if spec.neck == "tie":
		fill(PackedVector2Array([Vector2(-4, top + 2), Vector2(4, top + 2), Vector2(6, top + 30), Vector2(0, top + 38), Vector2(-6, top + 30)]), C.accent, 2.5)

func _draw_pattern(c: Vector2, rx: float, ry: float, animal: bool) -> void:
	var pc: Color = C.main.darkened(0.3) if C.main.get_luminance() > 0.3 else C.main.lightened(0.35)
	match spec.body.pattern:
		"stripes":
			for i in 3:
				var y := c.y - ry * 0.6 + i * ry * 0.6
				if animal:
					fill(PackedVector2Array([Vector2(-rx * 1.18, y - 5), Vector2(-rx * 0.55, y), Vector2(-rx * 1.18, y + 5)]), pc, 0.0)
					fill(PackedVector2Array([Vector2(rx * 1.18, y - 5), Vector2(rx * 0.55, y), Vector2(rx * 1.18, y + 5)]), pc, 0.0)
				else:
					line(Vector2(-rx * 0.95, y), Vector2(rx * 0.95, y), pc, 5.0)
		"dots":
			var ds := [Vector2(-0.5, -0.4), Vector2(0.45, -0.1), Vector2(-0.2, 0.5), Vector2(0.55, 0.6), Vector2(-0.7, 0.2)]
			for d in ds:
				dot(c + Vector2(d.x * rx, d.y * ry), 5.0 if not animal else 8.0, pc if not kind == "cow" else Color("#2d2a32"))
		"star":
			fill(star_pts(c, rx * 0.45, rx * 0.2), C.accent, 2.5)
		"heart":
			fill(heart_pts(c, rx * 0.42), C.accent, 2.5)
		"scales":
			for yy in 3:
				for xx in 3:
					var sc := c + Vector2((xx - 1) * rx * 0.5 + (yy % 2) * rx * 0.25, (yy - 1) * ry * 0.5)
					draw_arc(sc, 6.0, 0.2, PI - 0.2, 8, pc, 2.0, true)
		"plaid":
			for i in 3:
				line(Vector2(c.x - rx * 0.9, c.y - ry * 0.6 + i * ry * 0.6), Vector2(c.x + rx * 0.9, c.y - ry * 0.6 + i * ry * 0.6), Color(pc, 0.5), 3.0)
				line(Vector2(c.x - rx * 0.6 + i * rx * 0.6, c.y - ry * 0.9), Vector2(c.x - rx * 0.6 + i * rx * 0.6, c.y + ry * 0.9), Color(pc, 0.5), 3.0)

func _draw_animal_face_base(R: float, birdish: bool) -> void:
	var ft := face_turn * R * 0.14
	if "panda_patches" in spec.extras:
		for sd in [-1, 1]:
			var pp := ell(Vector2(sd * R * 0.36 + ft, R * 0.1), R * 0.22, R * 0.28, 20)
			var rr := PackedVector2Array()
			for v in pp:
				rr.append((v - Vector2(sd * R * 0.36 + ft, R * 0.1)).rotated(sd * -0.5) + Vector2(sd * R * 0.36 + ft, R * 0.1))
			fill(rr, C.second if C.second.get_luminance() < 0.4 else Color("#2d2a32"), 0.0)
	if "snout" in spec.extras or kind in ["dog", "fox", "bear", "wolf", "pig", "cow", "koala", "lion", "monkey"]:
		var sc: Color = C.second if C.second.get_luminance() > C.main.get_luminance() - 0.05 else C.main.lightened(0.35)
		if kind == "pig":
			sc = C.main.darkened(0.1)
		fill(ell(Vector2(ft, R * 0.45), R * 0.32, R * 0.24, 24), sc, 3.0)
	if "stripes_face" in spec.extras:
		var stc: Color = C.main.darkened(0.45)
		for i in 3:
			fill(PackedVector2Array([Vector2(-8 + i * 8, -R * 0.92), Vector2(-4 + i * 8, -R * 0.92), Vector2(-2 + i * 6, -R * 0.62)]).duplicate(), stc, 0.0)
		for sd in [-1, 1]:
			fill(PackedVector2Array([Vector2(sd * R * 0.98, R * 0.1), Vector2(sd * R * 0.98, R * 0.22), Vector2(sd * R * 0.7, R * 0.18)]), stc, 0.0)
	if birdish or "beak" in spec.extras:
		return
	# 鼻子
	if plan == "animal" and not kind in ["frog", "dino", "dragon"]:
		var nz := Vector2(ft, R * 0.32)
		if kind == "pig":
			fill(ell(nz + Vector2(0, 6), R * 0.17, R * 0.12, 18), C.main.darkened(0.2), 3.0)
			dot(nz + Vector2(-5, 6), 2.6, C.line)
			dot(nz + Vector2(5, 6), 2.6, C.line)
		else:
			fill(PackedVector2Array([nz + Vector2(-R * 0.09, -R * 0.03), nz + Vector2(R * 0.09, -R * 0.03), nz + Vector2(0, R * 0.07)]), C.line.lightened(0.1), 2.5)
	if "whiskers" in spec.extras:
		for sd in [-1, 1]:
			for i in 3:
				var y0 := R * (0.38 + i * 0.08)
				line(Vector2(sd * R * 0.42 + ft, y0), Vector2(sd * R * 0.92 + ft, y0 - R * 0.06 + i * R * 0.06), Color(C.line, 0.7), 2.0)

# ---------------------------------------------------------------- 脸
func _emo_open() -> float:
	var o := 1.0
	match emotion:
		"sleepy":
			o = 0.4
		"smug":
			o = 0.6
		"angry":
			o = 0.85
		"surprised", "scared":
			o = 1.15
	if sleeping:
		o = 0.0
	if petting > 0.0:
		o = 0.0
	return o * (1.0 - blink)

func _draw_face(fc: Vector2, R: float) -> void:
	var st: String = spec.eyes.style
	var es: float = spec.eyes.size
	var ex := R * 0.36
	var ey := fc.y + R * 0.06
	var er := R * 0.17 * es
	if plan in ["object", "plant", "blob"]:
		ex = R * 0.42
		er = R * 0.2 * es
	var openv := _emo_open()
	var happy_arc := emotion in ["happy", "love"] and not speaking and st != "button"
	if petting > 0.0:
		happy_arc = true
	if st == "gentle" and not emotion in ["surprised", "scared", "angry", "sad"]:
		happy_arc = true
	if spec.extras.has("eyepatch"):
		pass
	for side in [-1, 1]:
		var c := Vector2(fc.x + side * ex, ey)
		if spec.extras.has("eyepatch") and side > 0:
			fill(ell(c, er * 1.25, er * 1.1, 18), Color("#2a2733"), 2.5)
			line(c + Vector2(-er * 1.2, -er * 0.6), Vector2(c.x - R * 0.9, ey - R * 0.55), Color("#2a2733"), 3.0)
			continue
		if openv <= 0.12 or happy_arc:
			_eye_closed(c, er, side, happy_arc and not sleeping)
			continue
		if plan == "object" and kind == "robot":
			fill(rrect(c, er * 1.6, er * 1.6 * openv, er * 0.4), Color("#7df9ff"), 0.0)
			draw_colored_polygon(rrect(c, er * 2.2, er * 2.2 * openv, er * 0.6), Color(0.49, 0.98, 1.0, 0.18))
			continue
		_eye_open(c, er, side, openv, st)
	_draw_cheeks(fc, R)
	_draw_mouth(Vector2(fc.x, fc.y + R * 0.4), R)
	_draw_face_extras(fc, R)

func _eye_closed(c: Vector2, er: float, side: int, happy: bool) -> void:
	if happy:
		draw_arc(c + Vector2(0, er * 0.35), er * 0.85, PI * 1.12, PI * 1.88, 12, C.line, LW * 1.05, true)
	else:
		draw_arc(c + Vector2(0, -er * 0.25), er * 0.8, PI * 0.15, PI * 0.85, 12, C.line, LW * 1.05, true)
		if spec.eyes.lashes:
			line(c + Vector2(side * er * 0.75, er * 0.1), c + Vector2(side * er * 1.05, er * 0.25), C.line, 2.5)

func _eye_open(c: Vector2, er: float, side: int, openv: float, st: String) -> void:
	var lk := Vector2(look.x * er * 0.35 + face_turn * er * 0.25, look.y * er * 0.25)
	var big := emotion in ["surprised", "scared"]
	var ic: Color = C.eye
	match st:
		"dot":
			var r := er * (0.62 if not big else 0.75)
			fill(ell(c + lk * 0.5, r * 0.8, r * openv, 16), C.line.darkened(0.2), 0.0)
			dot(c + lk * 0.5 + Vector2(-r * 0.25, -r * 0.35 * openv), r * 0.25, Color(1, 1, 1, 0.9))
			return
		"button":
			circle_o(c, er * 0.95, Color("#26222e"), 2.5)
			ring(c, er * 0.7, Color("#4a4458"), 2.0)
			dot(c + Vector2(-er * 0.25, -er * 0.1), er * 0.12, Color("#8c8599"))
			dot(c + Vector2(er * 0.25, er * 0.1), er * 0.12, Color("#8c8599"))
			return
	var rx := er * (1.0 if st != "sharp" else 1.1)
	var ry := er * 1.18
	if st == "anime" or st == "sparkle":
		ry = er * 1.38
	if st == "cat":
		ry = er * 1.2
	if big:
		rx *= 1.15
		ry *= 1.12
	ry *= openv
	ry = maxf(ry, 1.5)
	# 眼白（大眼/惊讶/深色脸时）
	var dark_face: bool = C.face.get_luminance() < 0.4
	if big or st in ["anime", "sharp"] or dark_face:
		fill(ell(c, rx * 1.12, ry * 1.08, 26), Color(1, 1, 1), 0.0)
	var iris := ell(c + lk * (0.25 if big else 0.6), rx * (0.62 if big else 0.92), ry * (0.62 if big else 0.95), 26)
	var cols := PackedColorArray()
	for v in iris:
		var k := clampf((v.y - (c.y - ry)) / (2.0 * ry + 0.01), 0.0, 1.0)
		cols.append(ic.darkened(0.45).lerp(ic.lightened(0.25), k))
	draw_polygon(iris, cols)
	var pc := c + lk * (0.4 if big else 0.75)
	if st == "cat":
		fill(ell(pc, rx * 0.16, ry * 0.75, 16), Color("#141118"), 0.0)
	elif emotion == "love":
		fill(heart_pts(pc + Vector2(0, -ry * 0.05), rx * 0.62), Color("#ff4d7a"), 0.0)
	else:
		var pr := 0.42 if not big else 0.28
		fill(ell(pc, rx * pr, ry * pr * 1.1, 18), ic.darkened(0.72), 0.0)
	# 高光
	if st == "sparkle" or emotion == "excited":
		fill(star_pts(pc + Vector2(-rx * 0.28, -ry * 0.32), rx * 0.42, rx * 0.12, 4, 0.0), Color(1, 1, 1, 0.95), 0.0)
	else:
		dot(pc + Vector2(-rx * 0.3, -ry * 0.35), rx * 0.3, Color(1, 1, 1, 0.95))
	dot(pc + Vector2(rx * 0.32, ry * 0.32), rx * 0.13, Color(1, 1, 1, 0.8))
	var wide: bool = big or st in ["anime", "sharp"] or dark_face
	outline(ell(c, rx * (1.12 if wide else 1.0), ry * (1.08 if wide else 1.0), 26), C.line, LW * 0.75)
	# 眼皮（困/得意/生气/锐利）
	var lid_cut := -2.0
	var lid_rot := 0.0
	match emotion:
		"sleepy":
			lid_cut = -0.1
		"smug":
			lid_cut = -0.25
		"angry":
			lid_cut = -0.45
			lid_rot = 0.45 * side
		"sad":
			lid_cut = -0.55
			lid_rot = -0.35 * side
	if st == "sleepy":
		lid_cut = maxf(lid_cut, -0.15)
	if st == "sharp" and lid_cut < -1.0:
		lid_cut = -0.55
		lid_rot = 0.3 * side
	if lid_cut > -1.0:
		var k2 := clampf(lid_cut, -0.98, 0.98)
		var ak := asin(k2)
		var lid := ell_arc(Vector2.ZERO, rx * 1.25, ry * 1.25 + 2.0, PI - ak, TAU + ak, 14)
		var lp := PackedVector2Array()
		for v in lid:
			lp.append(v.rotated(lid_rot) + c)
		draw_colored_polygon(lp, C.face)
		var ln := PackedVector2Array([lp[0], lp[lp.size() - 1]])
		draw_polyline(ln, C.line, LW * 0.9, true)
	# 睫毛 / 上眼线
	if st in ["anime", "sparkle"] or spec.eyes.lashes:
		var top := ell_arc(c, rx * 1.05, ry * 1.06, PI * 1.08, PI * 1.92, 12)
		draw_polyline(top, C.line, LW * 1.5, true)
		if spec.eyes.lashes:
			var oc := c + Vector2(side * rx * 0.95, -ry * 0.5)
			line(oc, oc + Vector2(side * rx * 0.45, -ry * 0.35), C.line, 3.0)
			line(oc + Vector2(-side * rx * 0.2, -ry * 0.25), oc + Vector2(side * rx * 0.2, -ry * 0.75), C.line, 2.5)
	if emotion == "sad" and sin(t * 1.5) > -0.2:
		fill(_tear_pts(c + Vector2(side * rx * 0.6, ry * 1.1), er * 0.32), Color(0.55, 0.8, 1.0, 0.9), 2.0)

func _tear_pts(c: Vector2, r: float) -> PackedVector2Array:
	var p := PackedVector2Array()
	for i in 20:
		var a := TAU * float(i) / 20.0
		var k := 1.0 - 0.5 * maxf(-sin(a), 0.0)
		p.append(c + Vector2(cos(a) * r * k, sin(a) * r + (-r * 1.2 * maxf(-sin(a), 0.0))))
	return p

func _draw_cheeks(fc: Vector2, R: float) -> void:
	var b := 0.0
	if "blush" in spec.extras:
		b = 0.32
	match emotion:
		"shy":
			b = 0.7
		"love":
			b = 0.6
		"happy", "excited":
			b = maxf(b, 0.4)
		"angry":
			b = maxf(b, 0.35)
	if petting > 0.0:
		b = 0.65
	if b <= 0.0:
		return
	for sd in [-1, 1]:
		var c := fc + Vector2(sd * R * 0.56, R * 0.3)
		if plan in ["object", "blob", "plant"]:
			c = fc + Vector2(sd * R * 0.66, R * 0.28)
		draw_colored_polygon(ell(c, R * 0.14, R * 0.075, 18), Color(C.blush, b * 0.75))
		if b >= 0.6:
			for i in 3:
				var x := c.x - R * 0.07 + i * R * 0.07
				line(Vector2(x + R * 0.02, c.y - R * 0.04), Vector2(x - R * 0.02, c.y + R * 0.04), Color(C.blush.darkened(0.2), 0.8), 2.0)

func _draw_mouth(m: Vector2, R: float) -> void:
	var st: String = spec.mouth
	var mw := R * 0.2
	if st == "small":
		mw *= 0.7
	if st == "beak" or ("beak" in spec.extras and plan == "animal"):
		_draw_beak(m + Vector2(0, -R * 0.06), R)
		return
	var lw := LW * 0.9
	if talk > 0.05:
		var o := talk
		var mp := ell(m + Vector2(0, mw * 0.1), mw * (0.48 + 0.22 * o), mw * (0.2 + 0.5 * o), 20)
		fill(mp, C.mouth, lw)
		if o > 0.35:
			draw_colored_polygon(ell(m + Vector2(0, mw * (0.2 + 0.32 * o)), mw * 0.32, mw * 0.16 * o, 14), C.tongue)
		if st == "fang" or "fangs" in spec.extras:
			fill(PackedVector2Array([m + Vector2(mw * 0.18, -mw * 0.05), m + Vector2(mw * 0.36, -mw * 0.05), m + Vector2(mw * 0.27, mw * 0.25)]), C.white, 1.5)
		return
	if st == "none" and not emotion in ["surprised", "scared"]:
		return
	var emo := emotion
	if sleeping:
		emo = "sleepy"
	if puff > 0.5 and emo != "angry":
		emo = "pout"
	if st == "cat" and emo in ["neutral", "happy", "love", "smug", "shy"]:
		draw_arc(m + Vector2(-mw * 0.32, -mw * 0.1), mw * 0.32, 0.1, PI - 0.1, 10, C.line, lw, true)
		draw_arc(m + Vector2(mw * 0.32, -mw * 0.1), mw * 0.32, 0.1, PI - 0.1, 10, C.line, lw, true)
		if emo == "happy":
			fill(ell_arc(m + Vector2(0, mw * 0.18), mw * 0.25, mw * 0.3, 0.0, PI, 10), C.mouth, lw * 0.8)
		return
	match emo:
		"happy", "excited":
			var ww := mw * (0.8 if emo == "happy" else 1.0)
			var hh := mw * (0.7 if emo == "happy" else 0.95)
			var p := ell_arc(m + Vector2(0, -mw * 0.15), ww, hh, 0.0, PI, 14)
			fill(p, C.mouth, lw)
			draw_colored_polygon(ell(m + Vector2(0, hh * 0.55 - mw * 0.15), ww * 0.5, hh * 0.25, 14), C.tongue)
		"love":
			draw_arc(m + Vector2(0, -mw * 0.5), mw * 0.7, PI * 0.2, PI * 0.8, 12, C.line, lw, true)
		"shy", "scared":
			var pts := PackedVector2Array()
			for i in 9:
				var u := float(i) / 8.0
				pts.append(m + Vector2(lerpf(-mw * 0.6, mw * 0.6, u), sin(u * TAU * 1.5) * mw * 0.12))
			draw_polyline(pts, C.line, lw, true)
			if emo == "scared":
				fill(ell(m + Vector2(0, mw * 0.3), mw * 0.25, mw * 0.18, 12), C.mouth, lw * 0.7)
		"sad":
			draw_arc(m + Vector2(0, mw * 0.55), mw * 0.6, PI * 1.2, PI * 1.8, 12, C.line, lw, true)
		"angry", "pout":
			if emo == "angry":
				var p2 := ell_arc(m + Vector2(0, mw * 0.35), mw * 0.6, mw * 0.45, PI, TAU, 12)
				fill(p2, C.mouth, lw)
				draw_line(m + Vector2(-mw * 0.4, mw * 0.08), m + Vector2(mw * 0.4, mw * 0.08), C.white, 2.0, true)
			else:
				draw_arc(m + Vector2(0, mw * 0.25), mw * 0.25, PI * 1.15, PI * 1.85, 8, C.line, lw, true)
		"surprised":
			fill(ell(m + Vector2(0, mw * 0.1), mw * 0.32, mw * 0.42, 16), C.mouth, lw)
		"thinking":
			draw_line(m + Vector2(-mw * 0.1, 0), m + Vector2(mw * 0.55, -mw * 0.12), C.line, lw, true)
		"sleepy":
			fill(ell(m + Vector2(0, mw * 0.05), mw * 0.18, mw * 0.22, 12), C.mouth, lw * 0.8)
		"smug":
			var pts2 := bez(m + Vector2(-mw * 0.55, -mw * 0.05), m + Vector2(-mw * 0.1, mw * 0.25), m + Vector2(mw * 0.3, mw * 0.15), m + Vector2(mw * 0.6, -mw * 0.3), 10)
			draw_polyline(pts2, C.line, lw, true)
		_:
			draw_arc(m + Vector2(0, -mw * 0.55), mw * 0.72, PI * 0.22, PI * 0.78, 12, C.line, lw, true)
	if (st == "fang" or "fangs" in spec.extras) and emo in ["happy", "excited", "neutral", "smug"]:
		fill(PackedVector2Array([m + Vector2(mw * 0.2, -mw * 0.12), m + Vector2(mw * 0.42, -mw * 0.12), m + Vector2(mw * 0.3, mw * 0.18)]), C.white, 1.8)

func _draw_beak(m: Vector2, R: float) -> void:
	var bc := Color("#f2a541")
	var op := talk * R * 0.12
	if emotion in ["happy", "excited", "surprised"] and talk < 0.05:
		op = R * 0.06
	var w := R * 0.2
	fill(PackedVector2Array([m + Vector2(-w, -R * 0.02), m + Vector2(w, -R * 0.02), m + Vector2(0, R * 0.14)]), bc, 3.0)
	if op > 0.5:
		fill(PackedVector2Array([m + Vector2(-w * 0.75, R * 0.02 + op * 0.4), m + Vector2(w * 0.75, R * 0.02 + op * 0.4), m + Vector2(0, R * 0.12 + op)]), bc.darkened(0.15), 3.0)

func _draw_face_extras(fc: Vector2, R: float) -> void:
	for e in spec.extras:
		match e:
			"freckles":
				for sd in [-1, 1]:
					for i in 3:
						dot(fc + Vector2(sd * (R * 0.48 + i * 5.0), R * 0.22 + (i % 2) * 4.0), 1.8, C.face.darkened(0.35))
			"mole":
				dot(fc + Vector2(R * 0.5, R * 0.25), 2.2, C.line)
			"scar":
				line(fc + Vector2(-R * 0.62, R * 0.05), fc + Vector2(-R * 0.4, R * 0.3), C.face.darkened(0.35), 3.0)
			"star_mark":
				fill(star_pts(fc + Vector2(R * 0.6, R * 0.12), 8.0, 3.5), C.accent, 1.5)
			"bandage":
				var bp := rrect(fc + Vector2(-R * 0.55, R * 0.2), 22, 9, 3)
				var bpr := PackedVector2Array()
				for v in bp:
					bpr.append((v - (fc + Vector2(-R * 0.55, R * 0.2))).rotated(-0.5) + fc + Vector2(-R * 0.55, R * 0.2))
				fill(bpr, Color("#f3d2b0"), 2.0)
			"mask":
				fill(ell_arc(fc + Vector2(0, R * 0.28), R * 0.86, R * 0.55, 0.0, PI, 16), Color("#2a2d3a"), 3.0)
			"beard":
				var bc: Color = C.hair if spec.hair.style != "none" else Color("#e8e6e3")
				var bd := bez(fc + Vector2(-R * 0.55, R * 0.35), fc + Vector2(-R * 0.4, R * 1.1), fc + Vector2(R * 0.4, R * 1.1), fc + Vector2(R * 0.55, R * 0.35), 14)
				bd.append(fc + Vector2(R * 0.2, R * 0.55))
				bd.append(fc + Vector2(-R * 0.2, R * 0.55))
				fill(bd, bc, 3.0)
			"spots":
				for sd in [-1, 1]:
					dot(fc + Vector2(sd * R * 0.7, -R * 0.2), 4.0, C.second)
					dot(fc + Vector2(sd * R * 0.62, -R * 0.38), 3.0, C.second)

func _draw_brows(fc: Vector2, R: float) -> void:
	if spec.brows == "none" or plan in ["object", "blob"] and spec.brows == "normal" and not emotion in ["angry", "sad", "surprised", "smug", "thinking"]:
		return
	var w := LW * 1.25
	match spec.brows:
		"thin":
			w = LW * 0.85
		"thick":
			w = LW * 2.1
	var ba := 0.0
	var by := fc.y - R * 0.28
	match emotion:
		"angry":
			ba = 0.42
		"sad", "scared", "shy":
			ba = -0.35
		"surprised":
			by -= R * 0.1
		"thinking":
			ba = -0.15
	var col: Color = C.hair.darkened(0.2) if plan == "humanoid" else C.line
	if spec.extras.has("eyepatch"):
		pass
	for sd in [-1, 1]:
		var c := Vector2(fc.x + sd * R * 0.36, by)
		var a := -float(sd) * ba
		var yy := 0.0
		if emotion == "smug" and sd > 0:
			yy = -R * 0.08
			a = 0.15
		var hl := R * 0.14
		draw_line(c + Vector2(-hl, yy).rotated(a), c + Vector2(hl, yy).rotated(a), col, w, true)

# ---------------------------------------------------------------- 头发
func _ahoge() -> bool:
	return _hash % 3 == 0 and spec.hair.style in ["short", "messy", "bob", "long", "side"]

func _draw_hair_back(R: float) -> void:
	var hc: Color = C.hair
	var sway := sin(t * 1.7) * 3.0
	match spec.hair.style:
		"long":
			var p := PackedVector2Array([Vector2(-R * 1.02, -R * 0.2), Vector2(-R * 1.08, R * 0.9), Vector2(-R * 0.9 + sway, R * 1.7), Vector2(R * 0.9 + sway, R * 1.7), Vector2(R * 1.08, R * 0.9), Vector2(R * 1.02, -R * 0.2)])
			var arc := ell_arc(Vector2.ZERO, R * 1.04, R * 1.0, PI * 2.0, PI * 1.0, 16)
			arc.reverse()
			var full := PackedVector2Array()
			full.append_array(ell_arc(Vector2.ZERO, R * 1.05, R * 1.02, PI, TAU, 16))
			full.append(Vector2(R * 1.08, R * 0.9))
			full.append(Vector2(R * 0.92 + sway, R * 1.75))
			full.append(Vector2(-R * 0.92 + sway, R * 1.75))
			full.append(Vector2(-R * 1.08, R * 0.9))
			fill_sh(full, hc.darkened(0.12))
		"bob":
			var full2 := PackedVector2Array()
			full2.append_array(ell_arc(Vector2.ZERO, R * 1.07, R * 1.04, PI, TAU, 16))
			full2.append(Vector2(R * 1.12, R * 0.55))
			full2.append(Vector2(R * 0.8, R * 0.82))
			full2.append(Vector2(-R * 0.8, R * 0.82))
			full2.append(Vector2(-R * 1.12, R * 0.55))
			fill_sh(full2, hc.darkened(0.12))
		"twintails":
			for sd in [-1, 1]:
				var base := Vector2(sd * R * 0.92, -R * 0.35)
				var tip := Vector2(sd * R * 1.45 + sway * sd, R * 1.45)
				var cen := bez(base, base + Vector2(sd * R * 0.7, R * 0.2), tip + Vector2(sd * R * 0.2, -R * 0.6), tip, 12)
				fill_sh(stroke_poly(cen, R * 0.52, R * 0.08), hc.darkened(0.06))
				circle_o(base + Vector2(sd * 4, 0), R * 0.13, C.accent, 3.0)
		"ponytail":
			var base2 := Vector2(R * 0.55, -R * 0.75)
			var tip2 := Vector2(R * 1.25 + sway, R * 1.1)
			var cen2 := bez(base2, base2 + Vector2(R * 0.9, -R * 0.1), tip2 + Vector2(R * 0.2, -R * 0.7), tip2, 12)
			fill_sh(stroke_poly(cen2, R * 0.5, R * 0.1), hc.darkened(0.06))
			circle_o(base2 + Vector2(R * 0.12, 0), R * 0.12, C.accent, 3.0)
		"bun":
			circle_o(Vector2(0, -R * 1.05), R * 0.36, hc.darkened(0.04))
		"fluffy", "curly":
			if plan == "animal" or spec.hair.style == "fluffy":
				for i in 12:
					var a := TAU * float(i) / 12.0
					circle_o(Vector2(cos(a) * R * 1.05, sin(a) * R * 0.98 + R * 0.08), R * 0.3, hc.darkened(0.06), 3.0)
	if spec.hat == "witch" and spec.hair.style in ["short", "none"]:
		pass

func _bangs_edge(R: float, depth: float, teeth: int, jag: float) -> PackedVector2Array:
	var p := PackedVector2Array()
	var n := teeth * 2
	for i in n + 1:
		var u := float(i) / float(n)
		var x := lerpf(R * 1.02, -R * 1.02, u)
		var base := -R * depth - (1.0 - pow(absf(x) / R, 2.0)) * R * 0.08
		var y := base + (jag * R if i % 2 == 1 else 0.0)
		var lim := sqrt(maxf(R * R * 1.06 - x * x, 0.0)) * 0.98
		p.append(Vector2(x, clampf(y, -lim, lim)))
	return p

func _draw_hair_front(R: float) -> void:
	var st: String = spec.hair.style
	if st == "none" or (plan == "animal" and st in ["fluffy"]):
		return
	var hc: Color = C.hair
	var top := ell_arc(Vector2.ZERO, R * 1.06, R * 1.03, PI * 1.0, PI * 2.0, 22)
	var p := PackedVector2Array()
	match st:
		"spiky":
			p = PackedVector2Array()
			for i in 15:
				var a := PI + PI * float(i) / 14.0
				var rr := R * (1.08 if i % 2 == 0 else 1.32)
				p.append(Vector2(cos(a) * rr, sin(a) * rr * 0.98))
			p.append_array(_bangs_edge(R, 0.18, 4, 0.22))
		"curly":
			for i in 9:
				var a2 := PI + PI * float(i) / 8.0
				circle_o(Vector2(cos(a2) * R * 0.95, sin(a2) * R * 0.92 + R * 0.05), R * 0.27, hc, 3.0)
			circle_o(Vector2(-R * 0.3, -R * 0.55), R * 0.3, hc, 3.0)
			circle_o(Vector2(R * 0.3, -R * 0.55), R * 0.3, hc, 3.0)
			return
		"fluffy":
			for i in 8:
				var a3 := PI * 1.05 + PI * 0.9 * float(i) / 7.0
				circle_o(Vector2(cos(a3) * R * 0.92, sin(a3) * R * 0.9 + R * 0.1), R * 0.3, hc, 3.0)
			circle_o(Vector2(0, -R * 0.62), R * 0.36, hc, 3.0)
			return
		"bob":
			p = top.duplicate()
			p.append(Vector2(-R * 1.0, R * 0.25))
			p.append_array(_bangs_edge(R * 0.98, 0.2, 1, 0.0))
			p.append(Vector2(R * 1.0, R * 0.25))
			p = top.duplicate()
			var side_r := PackedVector2Array([Vector2(R * 1.06, -R * 0.05), Vector2(R * 1.08, R * 0.55), Vector2(R * 0.78, R * 0.6), Vector2(R * 0.82, -R * 0.15)])
			var side_l := PackedVector2Array([Vector2(-R * 0.82, -R * 0.15), Vector2(-R * 0.78, R * 0.6), Vector2(-R * 1.08, R * 0.55), Vector2(-R * 1.06, -R * 0.05)])
			fill_sh(side_r, hc)
			fill_sh(side_l, hc)
			p.append_array(_bangs_edge(R, 0.22, 3, 0.07))
		"side":
			p = top.duplicate()
			var e := PackedVector2Array()
			for i in 11:
				var u2 := float(i) / 10.0
				var x2 := lerpf(R * 1.02, -R * 1.02, u2)
				var y2 := lerpf(-R * 0.55, R * 0.05, u2) + (R * 0.06 if i % 2 == 1 else 0.0)
				var lim2 := sqrt(maxf(R * R * 1.06 - x2 * x2, 0.0)) * 0.98
				e.append(Vector2(x2, clampf(y2, -lim2, lim2)))
			p.append_array(e)
		"messy":
			p = top.duplicate()
			p.append_array(_bangs_edge(R, 0.2, 5, 0.2))
		_:
			p = top.duplicate()
			p.append_array(_bangs_edge(R, 0.22 if st != "short" else 0.3, 4, 0.12))
	fill_sh(p, hc, LW, 0.8)
	# 头发高光
	draw_arc(Vector2(-R * 0.1, -R * 0.15), R * 0.78, PI * 1.25, PI * 1.5, 10, Color(1, 1, 1, 0.25), 4.0, true)
	if st in ["long", "twintails"]:
		for sd in [-1, 1]:
			var lock := PackedVector2Array([Vector2(sd * R * 0.8, -R * 0.35), Vector2(sd * R * 1.02, -R * 0.1), Vector2(sd * R * 0.96, R * 0.75), Vector2(sd * R * 0.82, R * 0.9), Vector2(sd * R * 0.78, R * 0.3)])
			if sd < 0:
				lock.reverse()
			fill_sh(lock, hc)
	if _ahoge():
		var ah := bez(Vector2(0, -R * 0.98), Vector2(R * 0.1, -R * 1.5), Vector2(R * 0.45, -R * 1.35 + sin(t * 3.0) * 4.0), Vector2(R * 0.25, -R * 1.15), 10)
		draw_polyline(ah, C.line, LW + 4.0, true)
		draw_polyline(ah, hc, LW, true)

# ---------------------------------------------------------------- 耳朵
func _draw_ears(R: float, fur: Color, back: bool) -> void:
	var ea: String = spec.ears
	var inner: Color = C.second if C.second.get_luminance() > fur.get_luminance() else Color("#f6a6b6")
	if plan == "humanoid" and ea in ["cat", "fox", "dog", "rabbit", "bear", "mouse"]:
		inner = Color("#f6b6c2")
	var tw := p_ear
	match ea:
		"human", "elf":
			if not back:
				return
			for sd in [-1, 1]:
				if ea == "elf":
					fill_sh(PackedVector2Array([Vector2(sd * R * 0.9, -R * 0.05), Vector2(sd * R * 1.55, -R * 0.45 + tw * 10.0), Vector2(sd * R * 0.92, R * 0.3)]), C.skin)
				else:
					fill_sh(ell(Vector2(sd * R * 0.96, R * 0.1), R * 0.16, R * 0.22, 16), C.skin)
		"cat", "fox", "dog":
			if not back:
				return
			for sd in [-1, 1]:
				var h := R * (0.62 if ea != "fox" else 0.78)
				var w := R * (0.5 if ea != "fox" else 0.5)
				var rot := float(sd) * 0.42 + tw * float(sd)
				var base := Vector2(sd * R * 0.55, -R * 0.62)
				var pts := PackedVector2Array([Vector2(-w * 0.5, 0), Vector2(0, -h) if ea != "dog" else Vector2(-w * 0.1, -h), Vector2(w * 0.5, 0)])
				if ea == "dog":
					pts = PackedVector2Array([Vector2(-w * 0.5, 0), Vector2(-w * 0.25, -h * 0.85), Vector2(w * 0.05, -h), Vector2(w * 0.5, 0)])
				var tp := PackedVector2Array()
				var ip := PackedVector2Array()
				for v in pts:
					tp.append(v.rotated(rot) + base)
					ip.append((v * Vector2(0.55, 0.62) + Vector2(0, -h * 0.05)).rotated(rot) + base)
				fill_sh(tp, fur)
				fill(ip, inner, 0.0)
				if ea == "fox":
					var tip := PackedVector2Array([pts[1].lerp(pts[0], 0.32), pts[1], pts[1].lerp(pts[2], 0.32)])
					var tt2 := PackedVector2Array()
					for v in tip:
						tt2.append(v.rotated(rot) + base)
					fill(tt2, C.line.lightened(0.15), 0.0)
		"rabbit":
			if not back:
				return
			for sd in [-1, 1]:
				var flop := sin(t * 2.0 + sd) * 0.05 + tw
				var rot2 := float(sd) * 0.2 + flop * float(sd)
				var base2 := Vector2(sd * R * 0.32, -R * 0.8)
				var e := ell(Vector2(0, -R * 0.55), R * 0.2, R * 0.62, 22)
				var ei := ell(Vector2(0, -R * 0.52), R * 0.1, R * 0.45, 18)
				var ep := PackedVector2Array()
				var eip := PackedVector2Array()
				for v in e:
					ep.append(v.rotated(rot2) + base2)
				for v in ei:
					eip.append(v.rotated(rot2) + base2)
				fill_sh(ep, fur)
				fill(eip, inner, 0.0)
		"bear", "mouse":
			if not back:
				return
			for sd in [-1, 1]:
				var r := R * (0.27 if ea == "bear" else 0.4)
				var c := Vector2(sd * R * (0.68 if ea == "bear" else 0.72), -R * (0.72 if ea == "bear" else 0.6)).rotated(tw * sd)
				circle_o(c, r, fur)
				dot(c, r * 0.55, inner)
		"floppy":
			if back:
				return
			for sd in [-1, 1]:
				var swing := sin(t * 2.4 + sd) * 0.06 + tw
				var base3 := Vector2(sd * R * 0.78, -R * 0.55)
				var e2 := PackedVector2Array([Vector2(0, -R * 0.05), Vector2(sd * R * 0.3, R * 0.05), Vector2(sd * R * 0.34, R * 0.6), Vector2(sd * R * 0.12, R * 0.72), Vector2(-sd * R * 0.06, R * 0.3)])
				var ep2 := PackedVector2Array()
				for v in e2:
					ep2.append(v.rotated(swing * sd) + base3)
				if sd < 0:
					ep2.reverse()
				fill_sh(ep2, fur.darkened(0.12) if plan == "animal" else C.hair)
		"fin":
			if not back:
				return
			for sd in [-1, 1]:
				var fb := Vector2(sd * R * 0.9, -R * 0.1)
				var fp := PackedVector2Array([fb, fb + Vector2(sd * R * 0.5, -R * 0.45 + tw * 8.0), fb + Vector2(sd * R * 0.42, -R * 0.1), fb + Vector2(sd * R * 0.5, R * 0.2), fb + Vector2(0, R * 0.25)])
				if sd < 0:
					fp.reverse()
				fill_sh(fp, C.accent)

# ---------------------------------------------------------------- 尾巴 / 翅膀 / 角 / 帽子 / 眼镜 / 领口
func _draw_tail(col: Color) -> void:
	var tl: String = spec.tail
	match tl:
		"cat", "devil":
			var cen := bez(Vector2(0, 0), Vector2(40, 0), Vector2(30, -55), Vector2(55, -80), 14)
			fill_sh(stroke_poly(cen, 13.0, 9.0), col if tl == "cat" else C.accent.darkened(0.3))
			if tl == "devil":
				fill(heart_pts(Vector2(58, -88), 12.0), C.accent.darkened(0.3), 3.0)
			_hits.append(["tail", root.affine_inverse() * (root * Transform2D(p_tail, Vector2(6, L.hip - 6.0)) * Vector2(55, -80)), 18.0])
		"fox", "fluffy", "squirrel":
			var big := 1.0 if tl == "fox" else (1.15 if tl == "squirrel" else 0.9)
			var tipc: Color = Color(1, 1, 1) if tl == "fox" else col.lightened(0.2)
			var cen2 := bez(Vector2(0, 0), Vector2(45 * big, 10), Vector2(60 * big, -50 * big), Vector2(30 * big, -95 * big) if tl == "squirrel" else Vector2(70 * big, -70 * big), 14)
			var poly := PackedVector2Array()
			var n := cen2.size()
			var left := PackedVector2Array()
			var right := PackedVector2Array()
			for i in n:
				var d := (cen2[mini(i + 1, n - 1)] - cen2[maxi(i - 1, 0)]).normalized()
				var nr := Vector2(-d.y, d.x)
				var u := float(i) / float(n - 1)
				var w := (8.0 + sin(u * PI) * 26.0 * big) * (1.0 - pow(u, 6.0) * 0.8)
				left.append(cen2[i] + nr * w)
				right.append(cen2[i] - nr * w)
			right.reverse()
			poly.append_array(left)
			poly.append_array(right)
			fill_sh(poly, col)
			var tipp := PackedVector2Array()
			for i in range(int(n * 0.72), n):
				tipp.append(left[i])
			for i in range(0, int(n * 0.28) + 1):
				tipp.append(right[i])
			if tipp.size() >= 3:
				fill(tipp, tipc, 0.0)
			_hits.append(["tail", root.affine_inverse() * (root * Transform2D(p_tail, Vector2(6, L.hip - 6.0)) * cen2[n - 1]), 26.0])
		"dog":
			var cen3 := bez(Vector2(0, 0), Vector2(26, -5), Vector2(38, -30), Vector2(26, -48), 10)
			fill_sh(stroke_poly(cen3, 14.0, 8.0), col)
			_hits.append(["tail", root.affine_inverse() * (root * Transform2D(p_tail, Vector2(6, L.hip - 6.0)) * Vector2(26, -48)), 16.0])
		"rabbit":
			circle_o(Vector2(18, 6), 13.0, Color(1, 1, 1) if C.main.get_luminance() < 0.9 else C.second)
		"dragon":
			var cen4 := bez(Vector2(0, 0), Vector2(40, 10), Vector2(70, 0), Vector2(95, -30), 14)
			fill_sh(stroke_poly(cen4, 24.0, 4.0), col)
			for i in 4:
				var q := cen4[2 + i * 3]
				fill(PackedVector2Array([q + Vector2(-5, -8), q + Vector2(2, -18), q + Vector2(6, -6)]), C.accent, 2.5)
			_hits.append(["tail", root.affine_inverse() * (root * Transform2D(p_tail, Vector2(6, L.hip - 6.0)) * Vector2(90, -28)), 18.0])
		"fish":
			var fpp := PackedVector2Array([Vector2(0, 0), Vector2(36, -26), Vector2(30, 0), Vector2(36, 26)])
			fill_sh(fpp, C.accent)

func _draw_wings(c: Vector2, animal: bool) -> void:
	var wg: String = spec.wings
	var f := p_wing
	for sd in [-1, 1]:
		var rot := float(sd) * (0.15 + f)
		var base := c + Vector2(sd * 18.0, 0)
		var pts := PackedVector2Array()
		var col: Color = C.white
		var a := 1.0
		match wg:
			"bird", "angel":
				var sz := 1.0 if wg == "bird" else 1.35
				pts = PackedVector2Array([Vector2(0, 0), Vector2(sd * 40 * sz, -38 * sz), Vector2(sd * 78 * sz, -46 * sz), Vector2(sd * 70 * sz, -20 * sz), Vector2(sd * 78 * sz, -6 * sz), Vector2(sd * 62 * sz, 6 * sz), Vector2(sd * 66 * sz, 22 * sz), Vector2(sd * 40 * sz, 22 * sz), Vector2(sd * 10, 18)])
				col = C.white if wg == "angel" else C.main.lightened(0.1)
			"bat":
				pts = PackedVector2Array([Vector2(0, 0), Vector2(sd * 30, -40), Vector2(sd * 84, -48), Vector2(sd * 78, -10), Vector2(sd * 62, 0), Vector2(sd * 54, 16), Vector2(sd * 36, 6), Vector2(sd * 24, 24), Vector2(sd * 8, 14)])
				col = C.accent.darkened(0.45)
			"fairy":
				pts = ell(Vector2(sd * 42, -30), 40, 24, 22)
				col = C.accent.lightened(0.5)
				a = 0.55
			"butterfly":
				pts = ell(Vector2(sd * 44, -26), 42, 34, 24)
				col = C.accent
		var tp := PackedVector2Array()
		for v in pts:
			tp.append(v.rotated(rot) + base)
		if sd < 0:
			tp.reverse()
		if a < 1.0:
			draw_colored_polygon(tp, Color(col, a))
			outline(tp, Color(C.line, 0.6), 2.5)
			var lp := PackedVector2Array()
			for v in ell(Vector2(sd * 30, 14), 26, 14, 18):
				lp.append(v.rotated(rot) + base)
			draw_colored_polygon(lp, Color(col, a))
			outline(lp, Color(C.line, 0.6), 2.5)
		else:
			fill_sh(tp, col)
			if wg == "butterfly":
				for v in [Vector2(sd * 50, -30), Vector2(sd * 32, -14)]:
					dot((v as Vector2).rotated(rot) + base, 7.0, C.second)
			if wg in ["bird", "angel"]:
				for i in 3:
					var q1: Vector2 = (Vector2(sd * (30 + i * 14), -10 + i * 6)).rotated(rot) + base
					var q2: Vector2 = (Vector2(sd * (44 + i * 14), 8 + i * 4)).rotated(rot) + base
					line(q1, q2, Color(C.line, 0.4), 2.0)

func _draw_horns(R: float) -> void:
	var hn: String = spec.horns
	var hc := Color("#efe3c8")
	match hn:
		"small":
			for sd in [-1, 1]:
				fill_sh(PackedVector2Array([Vector2(sd * R * 0.35, -R * 0.82), Vector2(sd * R * 0.48, -R * 1.18), Vector2(sd * R * 0.58, -R * 0.78)]), hc)
		"curved":
			for sd in [-1, 1]:
				var cen := bez(Vector2(sd * R * 0.5, -R * 0.75), Vector2(sd * R * 0.85, -R * 1.25), Vector2(sd * R * 1.25, -R * 0.95), Vector2(sd * R * 1.1, -R * 0.55), 12)
				fill_sh(stroke_poly(cen, R * 0.26, R * 0.06), hc.darkened(0.05))
		"unicorn":
			var p := PackedVector2Array([Vector2(-R * 0.12, -R * 0.88), Vector2(0, -R * 1.65), Vector2(R * 0.12, -R * 0.88)])
			fill_sh(p, Color("#f7d774"))
			for i in 3:
				var y := -R * (1.0 + i * 0.18)
				line(Vector2(-R * 0.09 + i * R * 0.025, y), Vector2(R * 0.09 - i * R * 0.025, y - R * 0.06), Color(C.line, 0.6), 2.0)
		"antlers":
			for sd in [-1, 1]:
				var b := Vector2(sd * R * 0.42, -R * 0.82)
				var t1 := b + Vector2(sd * R * 0.25, -R * 0.65)
				line(b, t1, C.line, LW + 6.0)
				line(b, t1, Color("#a8794f"), 7.0)
				var m := b.lerp(t1, 0.5)
				for br in [Vector2(sd * R * 0.3, -R * 0.12), Vector2(-sd * R * 0.08, -R * 0.3)]:
					line(m, m + br, C.line, LW + 5.0)
					line(m, m + br, Color("#a8794f"), 6.0)
				line(t1, t1 + Vector2(sd * R * 0.2, -R * 0.05), C.line, LW + 5.0)
				line(t1, t1 + Vector2(sd * R * 0.2, -R * 0.05), Color("#a8794f"), 6.0)
		"devil":
			for sd in [-1, 1]:
				var cen2 := bez(Vector2(sd * R * 0.45, -R * 0.8), Vector2(sd * R * 0.6, -R * 1.1), Vector2(sd * R * 0.75, -R * 1.25), Vector2(sd * R * 0.62, -R * 1.42), 10)
				fill_sh(stroke_poly(cen2, R * 0.22, R * 0.02), Color("#c0392b"))

func _draw_hat(R: float) -> void:
	var h: String = spec.hat
	var a: Color = C.accent
	match h:
		"cap":
			fill_sh(ell_arc(Vector2(0, -R * 0.45), R * 0.98, R * 0.62, PI, TAU, 16), a)
			fill(ell(Vector2(R * 0.55, -R * 0.45), R * 0.6, R * 0.12, 18), a.darkened(0.2), 3.0)
		"beret":
			var p := ell(Vector2(-R * 0.15, -R * 0.82), R * 0.9, R * 0.3, 24)
			var pr := PackedVector2Array()
			for v in p:
				pr.append((v - Vector2(-R * 0.15, -R * 0.82)).rotated(-0.2) + Vector2(-R * 0.15, -R * 0.82))
			fill_sh(pr, a)
			dot(Vector2(-R * 0.1, -R * 1.12), 5.0, a.darkened(0.2))
		"witch":
			fill(ell(Vector2(0, -R * 0.7), R * 1.35, R * 0.22, 26), Color("#3b2f5c"), 3.5)
			var cone := PackedVector2Array([Vector2(-R * 0.62, -R * 0.75), Vector2(R * 0.62, -R * 0.75), Vector2(R * 0.25, -R * 1.5), Vector2(R * 0.7 + sin(t * 1.3) * 4.0, -R * 1.85), Vector2(-R * 0.05, -R * 1.55)])
			fill_sh(cone, Color("#3b2f5c"))
			fill(PackedVector2Array([Vector2(-R * 0.6, -R * 0.82), Vector2(R * 0.6, -R * 0.82), Vector2(R * 0.55, -R * 0.96), Vector2(-R * 0.55, -R * 0.96)]), a, 2.5)
		"crown":
			var cp := PackedVector2Array([Vector2(-R * 0.5, -R * 0.78), Vector2(-R * 0.55, -R * 1.22), Vector2(-R * 0.28, -R * 1.0), Vector2(0, -R * 1.32), Vector2(R * 0.28, -R * 1.0), Vector2(R * 0.55, -R * 1.22), Vector2(R * 0.5, -R * 0.78)])
			fill_sh(cp, Color("#f2c14e"), LW, 1.4)
			dot(Vector2(0, -R * 0.92), 5.0, Color("#e8505b"))
			draw_colored_polygon(ell(Vector2(-R * 0.25, -R * 0.95), 4, 2, 8), Color(1, 1, 1, 0.6))
		"bow":
			var bc := Vector2(R * 0.55, -R * 0.82)
			fill_sh(PackedVector2Array([bc, bc + Vector2(-R * 0.4, -R * 0.25), bc + Vector2(-R * 0.38, R * 0.22)]), a)
			fill_sh(PackedVector2Array([bc, bc + Vector2(R * 0.4, -R * 0.25), bc + Vector2(R * 0.38, R * 0.22)]), a)
			circle_o(bc, R * 0.09, a.darkened(0.15), 3.0)
		"flower":
			var fc := Vector2(R * 0.62, -R * 0.68)
			for i in 5:
				var an := TAU * float(i) / 5.0 + t * 0.3
				circle_o(fc + Vector2(cos(an), sin(an)) * R * 0.14, R * 0.12, a.lightened(0.2), 2.5)
			circle_o(fc, R * 0.08, Color("#f4d35e"), 2.5)
		"tophat":
			fill(ell(Vector2(0, -R * 0.82), R * 0.85, R * 0.16, 22), Color("#2d2a32"), 3.5)
			fill_sh(rrect(Vector2(0, -R * 1.18), R * 1.0, R * 0.7, 6), Color("#2d2a32"))
			fill(rrect(Vector2(0, -R * 0.95), R * 1.02, R * 0.16, 2), a, 2.5)
		"beanie":
			fill_sh(ell_arc(Vector2(0, -R * 0.5), R * 0.96, R * 0.66, PI, TAU, 16), a)
			fill(rrect(Vector2(0, -R * 0.52), R * 1.95, R * 0.22, 8), a.darkened(0.15), 3.0)
			circle_o(Vector2(0, -R * 1.18), R * 0.17, Color(1, 1, 1))
		"headphones":
			draw_arc(Vector2(0, -R * 0.1), R * 1.08, PI * 1.08, PI * 1.92, 20, C.line, 13.0, true)
			draw_arc(Vector2(0, -R * 0.1), R * 1.08, PI * 1.08, PI * 1.92, 20, a, 7.0, true)
			for sd in [-1, 1]:
				fill_sh(rrect(Vector2(sd * R * 1.02, R * 0.05), R * 0.3, R * 0.5, 8), a.darkened(0.1))
		"halo":
			var hy := -R * 1.35 + sin(t * 2.0) * 3.0
			draw_arc(Vector2(0, hy), R * 0.5, 0, TAU, 32, Color(1.0, 0.85, 0.3, 0.35), 12.0, true)
			var hp := ell(Vector2(0, hy), R * 0.5, R * 0.14, 28)
			outline(hp, Color("#f7d774"), 5.0)
		"leaf":
			var lc := Vector2(0, -R * 0.98)
			line(lc, lc + Vector2(0, -R * 0.2), C.line, 4.0)
			var lp := ell(Vector2(R * 0.22, -R * 0.28), R * 0.28, R * 0.13, 18)
			var lr := PackedVector2Array()
			for v in lp:
				lr.append(v.rotated(-0.5 + sin(t * 2.0) * 0.1) + lc)
			fill_sh(lr, Color("#6cc070"))

func _draw_glasses(fc: Vector2, R: float) -> void:
	var g: String = spec.glasses
	if g == "none":
		return
	var ex := R * 0.36
	var ey := fc.y + R * 0.06
	var r := R * 0.25
	var col := Color("#2d2a32")
	match g:
		"round":
			for sd in [-1, 1]:
				ring(Vector2(fc.x + sd * ex, ey), r, col, 3.5)
			line(Vector2(fc.x - ex + r, ey), Vector2(fc.x + ex - r, ey), col, 3.0)
		"square":
			for sd in [-1, 1]:
				outline(rrect(Vector2(fc.x + sd * ex, ey), r * 2.1, r * 1.6, 5), col, 3.5)
			line(Vector2(fc.x - ex + r, ey), Vector2(fc.x + ex - r, ey), col, 3.0)
		"sun":
			for sd in [-1, 1]:
				fill(rrect(Vector2(fc.x + sd * ex, ey), r * 2.2, r * 1.5, 8), Color("#1d1b24"), 3.0)
				line(Vector2(fc.x + sd * ex - r * 0.6, ey - r * 0.3), Vector2(fc.x + sd * ex - r * 0.1, ey - r * 0.55), Color(1, 1, 1, 0.6), 3.0)
			line(Vector2(fc.x - ex + r, ey - 2), Vector2(fc.x + ex - r, ey - 2), col, 3.5)
		"monocle":
			ring(Vector2(fc.x + ex, ey), r, Color("#c9a227"), 3.5)
			line(Vector2(fc.x + ex, ey + r), Vector2(fc.x + ex + R * 0.2, ey + R * 0.9), Color("#c9a227"), 2.0)

func _draw_neck(c: Vector2, animal: bool) -> void:
	var nk: String = spec.neck
	var a: Color = C.accent
	match nk:
		"scarf":
			fill_sh(rrect(c + Vector2(0, 2), 58, 15, 7), a)
			var tail := PackedVector2Array([c + Vector2(10, 6), c + Vector2(24, 6), c + Vector2(22 + sin(t * 2.0) * 3.0, 40), c + Vector2(10, 38)])
			fill_sh(tail, a.darkened(0.08))
		"bowtie":
			fill(PackedVector2Array([c + Vector2(0, 4), c + Vector2(-15, -4), c + Vector2(-15, 12)]), a, 3.0)
			fill(PackedVector2Array([c + Vector2(0, 4), c + Vector2(15, -4), c + Vector2(15, 12)]), a, 3.0)
			circle_o(c + Vector2(0, 4), 4.5, a.darkened(0.2), 2.5)
		"collar", "bell":
			fill(rrect(c + Vector2(0, 2), 50 if not animal else 56, 9, 4), a if nk == "collar" else Color("#d6336c"), 3.0)
			if nk == "bell":
				circle_o(c + Vector2(0, 11), 8.0, Color("#f2c14e"), 3.0)
				line(c + Vector2(-4, 13), c + Vector2(4, 13), C.line, 2.0)
		"necklace":
			draw_arc(c + Vector2(0, -6), 20.0, 0.3, PI - 0.3, 14, Color("#e9c46a"), 2.5, true)
			fill(heart_pts(c + Vector2(0, 16), 7.0), a, 2.0)

# ================================================================== 植物
func _draw_plant() -> void:
	var R: float = L.R
	var hc: Vector2 = L.head + Vector2(p_head_dx, p_head_dy * 0.6)
	var potc: Color = C.second if not kind in ["flower", "sunflower", "tulip"] else Color("#c8693a")
	if kind in ["cactus", "sprout", "leafy", "tree"] and C.second.get_luminance() > 0.75:
		potc = Color("#c8693a")
	var potted := not kind in ["mushroom", "tree"]
	_xf(root)
	if potted:
		var pot := PackedVector2Array([Vector2(-42, -56), Vector2(42, -56), Vector2(34, -2), Vector2(-34, -2)])
		fill_sh(pot, potc)
		fill(rrect(Vector2(0, -58), 98, 18, 5), potc.lightened(0.08), LW)
		draw_colored_polygon(ell(Vector2(0, -66), 40, 6, 16), Color("#5a3b28"))
		_hits.append(["body", Rect2(-45, -70, 90, 70)])
	var hxf := root * Transform2D(p_head_rot + sin(t * 1.4) * 0.03, hc)
	match kind:
		"flower", "sunflower", "tulip":
			var stem := bez(Vector2(0, -64), Vector2(-6, -95), Vector2(6, -120), hc + Vector2(0, R * 0.6), 10)
			draw_polyline(stem, C.line, 12.0, true)
			draw_polyline(stem, Color("#5fae55"), 7.0, true)
			_leaf_arms(Vector2(0, -92), 30.0)
			_xf(hxf)
			if kind == "tulip":
				for i in 3:
					var a := -0.55 + i * 0.55
					var pp := ell(Vector2(0, -R * 0.55), R * 0.42, R * 0.9, 22)
					var pr := PackedVector2Array()
					for v in pp:
						pr.append(v.rotated(a) + Vector2(0, -R * 0.1))
					fill_sh(pr, C.main)
			else:
				var n := 8 if kind == "flower" else 16
				var pc: Color = C.main if kind == "flower" else Color("#f6c445")
				for i in n:
					var a2 := TAU * float(i) / float(n) + sin(t * 0.6) * 0.05
					var pp2 := ell(Vector2(R * 1.25, 0), R * 0.48, R * 0.28 if kind == "flower" else R * 0.18, 18)
					var pr2 := PackedVector2Array()
					for v in pp2:
						pr2.append(v.rotated(a2))
					fill_sh(pr2, pc)
			fill_sh(ell(Vector2.ZERO, R, R * 0.95, 34), C.face, LW, 0.6)
			_draw_face(Vector2(0, 0), R)
			_draw_brows(Vector2.ZERO, R)
			_hits.append(["head", hc + Vector2(0, -R * 0.4), R * 1.1])
			_hits.append(["face", hc + Vector2(0, R * 0.3), R * 0.8])
		"sprout", "leafy", "cactus":
			var bh := 70.0 if kind == "sprout" else (92.0 if kind == "cactus" else 80.0)
			var bw := 44.0 if kind != "cactus" else 38.0
			if kind == "cactus":
				_leaf_arms(Vector2(0, -105), 0.0)
			_xf(hxf)
			var body := PackedVector2Array()
			if kind == "leafy":
				body = PackedVector2Array()
				for i in 40:
					var a3 := TAU * float(i) / 40.0
					var rr := 1.0 - 0.3 * pow(maxf(-sin(a3), 0.0), 2.0) * 0.0
					var q := Vector2(cos(a3) * bw * rr, sin(a3) * bh * 0.5)
					if sin(a3) < 0.0:
						q.x *= 1.0 - 0.45 * pow(-sin(a3), 3.0)
						q.y *= 1.25
					body.append(q + Vector2(0, -bh * 0.1))
			elif kind == "cactus":
				body = cap(Vector2(0, bh * 0.45), Vector2(0, -bh * 0.5), bw, 12)
			else:
				body = ell(Vector2(0, 8), bw, bh * 0.5, 34)
			fill_sh(body, C.main)
			if kind == "cactus":
				for x in [-bw * 0.5, 0.0, bw * 0.5]:
					line(Vector2(x, -bh * 0.75), Vector2(x * 1.1, bh * 0.75), Color(C.main.darkened(0.25), 0.7), 2.5)
				for sp in [Vector2(-24, -30), Vector2(22, -10), Vector2(-20, 30), Vector2(26, 40), Vector2(0, -70)]:
					line(sp, sp + Vector2(4, -5), Color(1, 1, 1, 0.85), 2.0)
				for i in 5:
					var a4 := TAU * float(i) / 5.0
					circle_o(Vector2(0, -bh * 0.5 - bw * 0.95) + Vector2(cos(a4), sin(a4)) * 9.0, 7.0, C.accent, 2.0)
				circle_o(Vector2(0, -bh * 0.5 - bw * 0.95), 5.0, Color("#f4d35e"), 2.0)
			if kind == "sprout":
				for sd in [-1, 1]:
					var lp := ell(Vector2(sd * 22, -10), 24, 11, 20)
					var lr := PackedVector2Array()
					for v in lp:
						lr.append(v.rotated(sd * -0.5 + sin(t * 2.3 + sd) * 0.12) + Vector2(0, -bh * 0.48))
					line(Vector2(0, -bh * 0.42), Vector2(0, -bh * 0.55), C.line, 4.0)
					fill_sh(lr, Color("#7cc35a"))
				_leaf_arms(Vector2(0, -92), 0.0, true, 42.0)
				_xf(hxf)
			if kind == "leafy":
				line(Vector2(0, -bh * 0.75), Vector2(0, bh * 0.4), Color(C.main.darkened(0.25), 0.6), 3.0)
			_draw_face(Vector2(0, 2), R * 0.92)
			_draw_brows(Vector2(0, 2), R * 0.92)
			_hits.append(["head", hc + Vector2(0, -bh * 0.3), bw * 1.1])
			_hits.append(["face", hc + Vector2(0, 14), bw * 0.9])
		"mushroom":
			_xf(root)
			_leaf_arms(Vector2(0, -50), 0.0, true, 40.0)
			_xf(root)
			var stem2 := cap(Vector2(0, -24), Vector2(0, -66), 46, 12)
			fill_sh(stem2, C.face)
			for sd in [-1, 1]:
				fill(ell(Vector2(sd * 18, -6), 14, 7, 14), C.face.darkened(0.1), 3.0)
			_xf(hxf)
			var capp := ell_arc(Vector2(0, -40), 84, 70, PI, TAU, 24)
			capp.append(Vector2(74, -30))
			capp.append(Vector2(-74, -30))
			fill_sh(capp, C.main)
			for d in [Vector2(-38, -66), Vector2(10, -84), Vector2(44, -54), Vector2(-8, -50)]:
				fill(ell(d, 11, 8, 14), Color(1, 1, 1, 0.92), 0.0)
			_draw_face(Vector2(0, 4), R * 1.08)
			_draw_brows(Vector2(0, 4), R * 1.08)
			_hits.append(["head", hc + Vector2(0, -64), 60.0])
			_hits.append(["face", hc + Vector2(0, 4), 36.0])
			_hits.append(["body", Rect2(-40, -80, 80, 80)])
		"tree":
			_xf(root)
			fill_sh(PackedVector2Array([Vector2(-30, -6), Vector2(-24, -110), Vector2(24, -110), Vector2(30, -6)]), C.face)
			for sd in [-1, 1]:
				fill(PackedVector2Array([Vector2(sd * 28, -4), Vector2(sd * 44, 0), Vector2(sd * 24, -18)]), C.face.darkened(0.08), 3.0)
			_leaf_arms(Vector2(0, -88), 0.0, true, 24.0)
			_xf(root * Transform2D(sin(t * 1.2) * 0.03, Vector2(0, -150)))
			for cc in [Vector2(-50, 10), Vector2(50, 10), Vector2(0, -40), Vector2(-36, -24), Vector2(36, -24), Vector2(0, 16)]:
				circle_o(cc, 52.0, C.main)
			for cc2 in [Vector2(-28, -36), Vector2(20, -52), Vector2(40, 0)]:
				dot(cc2, 7.0, C.accent)
			_xf(root * Transform2D(p_head_rot * 0.5, Vector2(0, -62)))
			_draw_face(Vector2(0, 0), R * 0.85)
			_draw_brows(Vector2.ZERO, R * 0.85)
			_hits.append(["head", Vector2(0, -170), 80.0])
			_hits.append(["face", Vector2(0, -60), 36.0])
			_hits.append(["body", Rect2(-30, -110, 60, 110)])

func _leaf_arms(base: Vector2, spread: float, stick := false, hx := -1.0) -> void:
	for sd in [-1, 1]:
		var a: float = p_arm[0 if sd < 0 else 1]
		var r := -a * float(sd)
		var b := base + Vector2(sd * (hx if hx >= 0.0 else (spread * 0.3 + (14.0 if kind == "cactus" else 6.0))), 0)
		_xf(root * Transform2D(r - PI * 0.5 * float(sd) * 0.0, b))
		if kind == "cactus":
			var cp := PackedVector2Array()
			cp.append_array(cap(Vector2(sd * 16, 0), Vector2(sd * 30, 0), 11.0, 8))
			fill_sh(cp, C.main)
			fill_sh(cap(Vector2(sd * 34, 4), Vector2(sd * 34, -26), 11.0, 8), C.main)
			_hits.append(["hand", root.affine_inverse() * (root * Transform2D(r, b) * Vector2(sd * 34, -22)), 16.0])
		elif stick:
			line(Vector2.ZERO, Vector2(0, 30), C.line, 5.0)
			circle_o(Vector2(0, 32), 6.0, C.face if kind != "sprout" else C.main, 2.5)
			_hits.append(["hand", root.affine_inverse() * (root * Transform2D(r, b) * Vector2(0, 32)), 14.0])
		else:
			var lp := ell(Vector2(sd * 26, 0), 26, 11, 18)
			var lr := PackedVector2Array()
			for v in lp:
				lr.append(v.rotated(sd * 0.35))
			fill_sh(lr, Color("#6cc070"))
			line(Vector2(sd * 4, 0), Vector2(sd * 44, 8 * sd * 0.0 + 6), Color(0, 0, 0, 0.15), 2.0)
			_hits.append(["hand", root.affine_inverse() * (root * Transform2D(r, b) * Vector2(sd * 30, 4)), 16.0])

# ================================================================== 物品
func _stick_limbs(top_y: float, half_w: float, bottom_y: float, legs := true) -> void:
	var col: Color = C.line
	for sd in [-1, 1]:
		var a: float = p_arm[0 if sd < 0 else 1]
		var r := -a * float(sd)
		var sh := Vector2(sd * half_w, top_y)
		_xf(root * Transform2D(r, sh))
		line(Vector2.ZERO, Vector2(0, 34), col, 5.0)
		circle_o(Vector2(0, 36), 7.0, C.white if kind != "robot" else Color("#b8bcc8"), 3.0)
		_hits.append(["hand", root.affine_inverse() * (root * Transform2D(r, sh) * Vector2(0, 36)), 15.0])
	if legs:
		for sd in [-1, 1]:
			var lift: float = p_legl[0 if sd < 0 else 1]
			_xf(root * Transform2D(0.0, Vector2(sd * 18, bottom_y - lift)))
			var ll := -bottom_y - 6.0
			line(Vector2.ZERO, Vector2(0, ll), col, 5.0)
			fill(ell(Vector2(sd * 4, ll + 1), 11, 6, 14), Color("#3a2f45"), 2.5)

func _draw_object() -> void:
	var R: float = L.R
	var c: Vector2 = L.body
	var hxf := root * Transform2D(p_head_rot * 0.6, c + Vector2(p_head_dx, p_head_dy * 0.5))
	var m: Color = C.main
	var fc := Vector2.ZERO
	var top := -60.0
	var bottom := 60.0
	var hw := 56.0
	var legs := kind != "cloud"
	match kind:
		"mug":
			hw = 52.0
			top = -58.0
			bottom = 58.0
		"phone":
			hw = 42.0
			top = -76.0
			bottom = 76.0
		"book":
			hw = 52.0
		"lamp":
			top = -70.0
			bottom = 70.0
		"robot":
			top = -70.0
			bottom = 66.0
		"star", "heart", "ball", "gem", "rock", "potato":
			top = -58.0
			bottom = 56.0
	_stick_limbs(c.y + top * 0.15, hw * 0.92, c.y + bottom - 2.0, legs)
	_xf(hxf)
	match kind:
		"mug":
			draw_arc(Vector2(hw + 6, 2), 22.0, -PI * 0.5, PI * 0.5, 16, C.line, 20.0, true)
			draw_arc(Vector2(hw + 6, 2), 22.0, -PI * 0.5, PI * 0.5, 16, m, 12.0, true)
			var body := PackedVector2Array([Vector2(-hw, top), Vector2(hw, top), Vector2(hw * 0.9, bottom - 8), Vector2(hw * 0.78, bottom), Vector2(-hw * 0.78, bottom), Vector2(-hw * 0.9, bottom - 8)])
			fill_sh(body, m)
			fill(ell(Vector2(0, top), hw, 12, 26), m.lightened(0.15), LW)
			draw_colored_polygon(ell(Vector2(0, top + 1), hw * 0.84, 8, 22), Color("#6b3f26"))
			line(Vector2(-hw * 0.95, top + 22), Vector2(hw * 0.95, top + 22), Color(C.accent, 0.8), 6.0)
			fc = Vector2(0, 16)
			if rng.randf() < 0.02:
				_emote("steam")
		"phone":
			fill_sh(rrect(Vector2.ZERO, hw * 2, bottom * 2, 16), Color("#2a2d3a"))
			var sc := rrect(Vector2(0, 0), hw * 2 - 14, bottom * 2 - 26, 10)
			var cols := PackedColorArray()
			for v in sc:
				cols.append(m.lightened(0.25).lerp(m.darkened(0.2), (v.y + bottom) / (bottom * 2)))
			draw_polygon(sc, cols)
			dot(Vector2(0, -bottom + 7), 2.5, Color(1, 1, 1, 0.5))
			C.face = m
			fc = Vector2(0, -4)
		"book":
			fill_sh(rrect(Vector2(4, 0), hw * 2, 124, 6), Color("#f6f1e3"))
			fill_sh(rrect(Vector2(0, 0), hw * 2, 124, 6), m)
			fill(rrect(Vector2(-hw + 8, 0), 14, 124, 3), m.darkened(0.25), 2.5)
			fill(rrect(Vector2(8, -40), 54, 14, 3), C.accent, 2.5)
			fc = Vector2(8, 8)
		"lamp":
			fill_sh(PackedVector2Array([Vector2(-hw * 0.55, -70), Vector2(hw * 0.55, -70), Vector2(hw, 10), Vector2(-hw, 10)]), m)
			line(Vector2(0, 10), Vector2(0, 52), C.line, 8.0)
			fill(rrect(Vector2(0, 56), 70, 14, 6), m.darkened(0.3), LW)
			draw_colored_polygon(PackedVector2Array([Vector2(-hw, 12), Vector2(hw, 12), Vector2(hw * 1.6, 90), Vector2(-hw * 1.6, 90)]), Color(1, 0.95, 0.6, 0.12))
			fc = Vector2(0, -26)
		"box":
			fill_sh(rrect(Vector2.ZERO, hw * 2, 112, 4), Color("#d9a066"))
			fill(PackedVector2Array([Vector2(-hw, -56), Vector2(-hw - 14, -78 + sin(t * 2.0) * 3.0), Vector2(-6, -70), Vector2(0, -56)]), Color("#e0ac74"), LW)
			fill(PackedVector2Array([Vector2(hw, -56), Vector2(hw + 14, -78 - sin(t * 2.0) * 3.0), Vector2(6, -70), Vector2(0, -56)]), Color("#e0ac74"), LW)
			fill(rrect(Vector2(0, -50), 26, 12, 2), Color("#c8b88a"), 0.0)
			C.face = Color("#d9a066")
			fc = Vector2(0, 8)
		"ball":
			fill_sh(ell(Vector2.ZERO, 60, 58, 36), m)
			draw_arc(Vector2(-90, 0), 92.0, -0.6, 0.6, 16, C.white, 6.0, true)
			draw_arc(Vector2(90, 0), 92.0, PI - 0.6, PI + 0.6, 16, C.white, 6.0, true)
			fc = Vector2(0, 4)
		"star":
			var sp := star_pts(Vector2(0, 4), 70, 34)
			fill_sh(sp, m if m.get_luminance() > 0.3 else Color("#f4d35e"))
			C.face = m if m.get_luminance() > 0.3 else Color("#f4d35e")
			fc = Vector2(0, 10)
		"heart":
			fill_sh(heart_pts(Vector2(0, 2), 64), m)
			fc = Vector2(0, -2)
		"cloud":
			for cc in [Vector2(-44, 10), Vector2(44, 10), Vector2(0, -22), Vector2(-26, -12), Vector2(26, -14), Vector2(0, 18)]:
				circle_o(cc, 40.0, C.white.lerp(m, 0.2))
			for cc2 in [Vector2(-44, 10), Vector2(44, 10), Vector2(0, -22), Vector2(-26, -12), Vector2(26, -14), Vector2(0, 18)]:
				dot(cc2, 37.0, C.white.lerp(m, 0.2))
			C.face = C.white.lerp(m, 0.2)
			fc = Vector2(0, 4)
		"robot":
			fill_sh(rrect(Vector2(0, 30), 96, 70, 12), m.lerp(Color("#b8bcc8"), 0.4), LW, 1.4)
			fill(rrect(Vector2(0, 30), 40, 24, 5), C.accent, 3.0)
			fill_sh(rrect(Vector2(0, -38), 112, 84, 18), m.lerp(Color("#dfe3ea"), 0.4), LW, 1.4)
			fill(rrect(Vector2(0, -36), 92, 60, 12), Color("#1f2333"), 3.0)
			line(Vector2(0, -80), Vector2(0, -100), C.line, 4.0)
			var on := sin(t * 4.0) > 0.0
			circle_o(Vector2(0, -104), 7.0, C.accent if on else C.accent.darkened(0.5), 3.0)
			C.face = Color("#1f2333")
			fc = Vector2(0, -40)
		"teapot":
			draw_arc(Vector2(64, -8), 20.0, -PI * 0.6, PI * 0.6, 14, C.line, 18.0, true)
			draw_arc(Vector2(64, -8), 20.0, -PI * 0.6, PI * 0.6, 14, m, 10.0, true)
			fill_sh(PackedVector2Array([Vector2(-56, -6), Vector2(-96, -42), Vector2(-88, -48), Vector2(-50, -24)]), m)
			fill_sh(ell(Vector2(0, 8), 64, 52, 34), m)
			fill(ell(Vector2(0, -42), 30, 10, 20), m.darkened(0.12), LW)
			circle_o(Vector2(0, -54), 8.0, C.accent, 3.0)
			fc = Vector2(0, 14)
		"cake":
			fill_sh(rrect(Vector2(0, 26), 116, 56, 8), Color("#f7e1c6"))
			fill_sh(rrect(Vector2(0, -24), 96, 48, 8), m)
			fill(ell(Vector2(0, -48), 48, 10, 24), Color(1, 1, 1), LW)
			for x in [-30.0, -6.0, 18.0, 38.0]:
				fill(ell(Vector2(x, -38), 7, 11, 12), Color(1, 1, 1), 0.0)
			circle_o(Vector2(0, -60), 10.0, Color("#e8505b"), 3.0)
			C.face = Color("#f7e1c6")
			fc = Vector2(0, 26)
		"potato":
			var pp := PackedVector2Array()
			for i in 36:
				var a := TAU * float(i) / 36.0
				var rr := 1.0 + 0.06 * sin(a * 3.0 + 1.0) + 0.04 * sin(a * 5.0)
				pp.append(Vector2(cos(a) * 58 * rr, sin(a) * 52 * rr))
			fill_sh(pp, Color("#c69c6d") if m.get_luminance() > 0.85 else m)
			for d in [Vector2(-30, -26), Vector2(28, -30), Vector2(36, 24), Vector2(-40, 18)]:
				dot(d, 3.0, Color(0, 0, 0, 0.25))
			fc = Vector2(0, 4)
		"rock":
			var rp := PackedVector2Array([Vector2(-58, 40), Vector2(-62, -6), Vector2(-36, -48), Vector2(10, -56), Vector2(50, -34), Vector2(62, 6), Vector2(54, 44)])
			fill_sh(rp, m.lerp(Color("#9aa0ac"), 0.6), LW, 1.3)
			for d2 in [Vector2(-28, -22), Vector2(34, -18), Vector2(20, 30)]:
				dot(d2, 3.0, Color(0, 0, 0, 0.2))
			C.face = m.lerp(Color("#9aa0ac"), 0.6)
			fc = Vector2(0, 6)
		"gem":
			var gp := PackedVector2Array([Vector2(-60, -16), Vector2(-34, -54), Vector2(34, -54), Vector2(60, -16), Vector2(0, 60)])
			fill_sh(gp, m, LW, 1.6)
			line(Vector2(-60, -16), Vector2(60, -16), Color(1, 1, 1, 0.5), 2.5)
			line(Vector2(-34, -54), Vector2(-16, -16), Color(1, 1, 1, 0.4), 2.0)
			line(Vector2(34, -54), Vector2(16, -16), Color(1, 1, 1, 0.4), 2.0)
			draw_colored_polygon(PackedVector2Array([Vector2(-30, -46), Vector2(-14, -46), Vector2(-26, -24)]), Color(1, 1, 1, 0.55))
			fc = Vector2(0, 2)
		"bottle":
			var bp := PackedVector2Array([Vector2(-14, -80), Vector2(14, -80), Vector2(14, -58), Vector2(44, -30), Vector2(44, 62), Vector2(-44, 62), Vector2(-44, -30), Vector2(-14, -58)])
			fill_sh(bp, m.lerp(C.white, 0.35))
			draw_colored_polygon(PackedVector2Array([Vector2(-40, 0), Vector2(40, 0), Vector2(40, 58), Vector2(-40, 58)]), Color(m, 0.85))
			fill(rrect(Vector2(0, -84), 34, 12, 4), C.accent, 3.0)
			draw_colored_polygon(rrect(Vector2(-28, 10), 8, 60, 4), Color(1, 1, 1, 0.35))
			fc = Vector2(0, 18)
		"toast":
			var tp := PackedVector2Array()
			tp.append_array(ell_arc(Vector2(0, -26), 60, 36, PI, TAU, 18))
			tp.append(Vector2(52, 56))
			tp.append(Vector2(-52, 56))
			fill_sh(tp, Color("#c98a44"))
			var ti := PackedVector2Array()
			ti.append_array(ell_arc(Vector2(0, -24), 50, 28, PI, TAU, 18))
			ti.append(Vector2(44, 48))
			ti.append(Vector2(-44, 48))
			draw_colored_polygon(ti, Color("#f5d9a4"))
			C.face = Color("#f5d9a4")
			fc = Vector2(0, 8)
		"pudding":
			fill(ell(Vector2(0, 58), 76, 12, 24), Color(1, 1, 1), LW)
			fill_sh(PackedVector2Array([Vector2(-40, -40), Vector2(40, -40), Vector2(58, 52), Vector2(-58, 52)]), Color("#f4d06f"))
			fill_sh(PackedVector2Array([Vector2(-40, -40), Vector2(40, -40), Vector2(44, -20), Vector2(30, -14), Vector2(18, -22), Vector2(0, -12), Vector2(-20, -22), Vector2(-44, -18)]), Color("#8a4b1f"))
			C.face = Color("#f4d06f")
			fc = Vector2(0, 14)
		_:
			fill_sh(rrect(Vector2.ZERO, hw * 2, 116, 20), m)
			fc = Vector2(0, 4)
	if spec.material in ["shiny", "glass", "metal"] or kind in ["mug", "ball", "bottle"]:
		draw_colored_polygon(ell(Vector2(-hw * 0.55, top * 0.55), 7, 14, 12), Color(1, 1, 1, 0.35))
	_draw_face(fc, R)
	_draw_brows(fc, R)
	if spec.hat != "none":
		_xf(hxf * Transform2D(0.0, Vector2(0, top + R * 0.72)))
		_draw_hat(R * 0.9)
	_hits.append(["head", c + Vector2(0, top * 0.55), hw * 0.9])
	_hits.append(["face", c + fc, R * 0.7])
	_hits.append(["body", Rect2(c.x - hw, c.y + top, hw * 2, bottom - top)])

# ================================================================== 史莱姆 / 幽灵 / 精灵 / 鱼 / 水母 / 棉花糖
func _draw_blob() -> void:
	var R: float = L.R
	var m: Color = C.main
	var c: Vector2 = L.body
	var wob := sin(t * 3.0)
	_xf(root)
	match kind:
		"slime", "marshmallow":
			var w := 74.0 if kind == "slime" else 66.0
			var h := 62.0 if kind == "slime" else 70.0
			var p := PackedVector2Array()
			for i in 44:
				var a := TAU * float(i) / 44.0
				var q := Vector2(cos(a) * w * (1.0 + 0.03 * wob), sin(a) * h * (1.0 - 0.03 * wob))
				if sin(a) > 0.0:
					q.y *= 0.55 if kind == "slime" else 0.75
					q.x *= 1.0 + 0.12 * sin(a)
				p.append(q + c + Vector2(0, 18))
			var col: Color = Color(m, 0.92) if kind == "slime" else m
			fill_sh(p, col, LW, 0.8)
			if kind == "slime":
				draw_colored_polygon(ell(c + Vector2(-34, -16), 14, 9, 14), Color(1, 1, 1, 0.5))
				dot(c + Vector2(-18, -30), 4.0, Color(1, 1, 1, 0.55))
			_stub_arms(c + Vector2(0, 30), w * 0.95)
			_xf(root * Transform2D(p_head_rot * 0.5, Vector2(p_head_dx, p_head_dy * 0.4)))
			_draw_face(c + Vector2(0, 8), R)
			_draw_brows(c + Vector2(0, 8), R)
			_hits.append(["head", c + Vector2(0, -30), 50.0])
			_hits.append(["face", c + Vector2(0, 14), 40.0])
			_hits.append(["body", Rect2(c.x - w, c.y - 20, w * 2, 70)])
		"ghost":
			var p2 := PackedVector2Array()
			p2.append_array(ell_arc(c + Vector2(0, -6), 60, 66, PI, TAU, 22))
			for i in 9:
				var u := float(i) / 8.0
				var x := lerpf(60.0, -60.0, u)
				p2.append(c + Vector2(x, 66 + sin(u * TAU * 2.0 + t * 4.0) * 8.0))
			fill_sh(p2, Color(m, 0.92), LW, 0.6)
			_stub_arms(c + Vector2(0, 10), 58.0)
			_xf(root * Transform2D(p_head_rot * 0.5, Vector2(0, p_head_dy * 0.4)))
			_draw_face(c + Vector2(0, -6), R)
			_draw_brows(c + Vector2(0, -6), R)
			_hits.append(["head", c + Vector2(0, -40), 50.0])
			_hits.append(["face", c + Vector2(0, 0), 40.0])
			_hits.append(["body", Rect2(c.x - 60, c.y + 10, 120, 60)])
		"spirit":
			var p3 := PackedVector2Array()
			for i in 40:
				var a2 := TAU * float(i) / 40.0
				var q2 := Vector2(cos(a2) * 54.0, sin(a2) * 54.0)
				if sin(a2) < 0.0:
					q2.x *= 1.0 - 0.55 * pow(-sin(a2), 2.0)
					q2.y *= 1.6
					q2.x += sin(t * 3.0 + q2.y * 0.05) * 6.0 * (-sin(a2))
				p3.append(q2 + c + Vector2(0, 14))
			for i in 4:
				draw_colored_polygon(ell(c + Vector2(0, 10), 80.0 - i * 12.0, 80.0 - i * 12.0, 24), Color(m, 0.05))
			fill_sh(p3, m, LW, 0.6)
			_stub_arms(c + Vector2(0, 26), 52.0)
			_xf(root)
			_draw_face(c + Vector2(0, 18), R * 0.92)
			_draw_brows(c + Vector2(0, 18), R * 0.92)
			_hits.append(["head", c + Vector2(0, -36), 48.0])
			_hits.append(["face", c + Vector2(0, 20), 40.0])
		"fish":
			var tl := PackedVector2Array([c + Vector2(50, 0), c + Vector2(96, -34 + wob * 6.0), c + Vector2(86, 0), c + Vector2(96, 34 + wob * 6.0)])
			fill_sh(tl, C.accent)
			fill_sh(PackedVector2Array([c + Vector2(-10, -44), c + Vector2(20, -76), c + Vector2(36, -40)]), C.accent)
			fill_sh(ell(c, 70, 50, 36), m)
			for i in 3:
				draw_arc(c + Vector2(10 + i * 14, 0), 26.0, -0.9, 0.9, 8, Color(m.darkened(0.2), 0.7), 2.5, true)
			_stub_arms(c + Vector2(0, 26), 40.0)
			_draw_face(c + Vector2(-18, 0), R * 0.85)
			_draw_brows(c + Vector2(-18, 0), R * 0.85)
			_hits.append(["head", c + Vector2(-20, -24), 42.0])
			_hits.append(["face", c + Vector2(-18, 10), 36.0])
			_hits.append(["tail", c + Vector2(86, 0), 26.0])
		"jelly":
			for i in 5:
				var x2 := -36.0 + i * 18.0
				var tpts := PackedVector2Array()
				for k in 8:
					var u2 := float(k) / 7.0
					tpts.append(c + Vector2(x2 + sin(t * 3.0 + i + u2 * 4.0) * 6.0 * u2, 30.0 + u2 * 70.0))
				draw_polyline(tpts, C.line, 8.0, true)
				draw_polyline(tpts, m.lightened(0.2), 4.0, true)
			var bell := ell_arc(c + Vector2(0, 30), 66, 76, PI, TAU, 24)
			for i in 7:
				var u3 := float(i) / 6.0
				bell.append(c + Vector2(lerpf(66.0, -66.0, u3), 30.0 + (8.0 if i % 2 == 1 else 0.0)))
			fill_sh(bell, Color(m, 0.85), LW, 0.6)
			_draw_face(c + Vector2(0, -6), R * 0.95)
			_draw_brows(c + Vector2(0, -6), R * 0.95)
			_hits.append(["head", c + Vector2(0, -30), 50.0])
			_hits.append(["face", c + Vector2(0, 0), 40.0])

func _stub_arms(base: Vector2, hw: float) -> void:
	for sd in [-1, 1]:
		var a: float = p_arm[0 if sd < 0 else 1]
		var r := -a * float(sd) * 0.8
		var sh := base + Vector2(sd * hw * 0.92, 0)
		_xf(root * Transform2D(r, sh))
		fill_sh(ell(Vector2(0, 10), 10, 15, 14), C.main.darkened(0.05))
		_hits.append(["hand", root.affine_inverse() * (root * Transform2D(r, sh) * Vector2(0, 16)), 18.0])

# ================================================================== 粒子 / 表情符号
func _emote_for(emo: String) -> void:
	match emo:
		"love":
			for i in 3:
				_emote("heart")
		"happy":
			if rng.randf() < 0.5:
				_emote("sparkle")
		"excited":
			_emote("sparkle")
			_emote("note")
		"angry":
			_emote("anger")
		"surprised":
			_emote("exclaim")
		"scared":
			_emote("sweat")
		"shy":
			_emote("sweat")
		"sad":
			_emote("rain")
		"thinking":
			_emote("question")
		"sleepy":
			_emote("zzz")
		"smug":
			_emote("sparkle")

func emote(k: String) -> void:
	_emote(k)

func _emote(k: String) -> void:
	var top := Vector2(0, -230)
	if L.has("head"):
		top = L.head + Vector2(L.R * 0.75, -L.R * 0.95)
	var p := {"k": k, "pos": top + Vector2(rng.randf_range(-20, 30), rng.randf_range(-10, 10)), "vel": Vector2(rng.randf_range(-20, 20), -50), "life": 0.0, "max": 1.6, "s": 1.0, "r": rng.randf_range(-0.3, 0.3)}
	match k:
		"heart":
			p.vel = Vector2(rng.randf_range(-40, 40), rng.randf_range(-90, -50))
			p.max = 1.8
		"sweat":
			p.pos = (L.head + Vector2(-L.R * 0.9, -L.R * 0.3)) if L.has("head") else top
			p.vel = Vector2(-10, 30)
			p.max = 1.2
		"anger":
			p.vel = Vector2.ZERO
			p.max = 1.4
		"exclaim", "question":
			p.vel = Vector2(0, -20)
			p.max = 1.3
		"zzz":
			p.vel = Vector2(25, -35)
			p.max = 2.4
		"steam":
			p.pos = Vector2(rng.randf_range(-20, 20), -170)
			p.vel = Vector2(rng.randf_range(-6, 6), -40)
			p.max = 1.6
		"rain":
			p.pos = top + Vector2(-20, -30)
			p.vel = Vector2.ZERO
			p.max = 1.6
	parts.append(p)
	if parts.size() > 40:
		parts.pop_front()

func _update_parts(delta: float) -> void:
	if sleeping and fmod(t, 1.4) < delta:
		_emote("zzz")
	if speaking and emotion == "excited" and fmod(t, 0.9) < delta:
		_emote("note")
	var au: String = spec.get("aura", "none")
	if au != "none" and au != "glow":
		_aura_t -= delta
		if _aura_t <= 0.0:
			_aura_t = 0.45
			var p := {"k": "aura_" + au, "pos": Vector2(rng.randf_range(-110, 110), rng.randf_range(-260, -20)), "vel": Vector2(rng.randf_range(-10, 10), -25), "life": 0.0, "max": 2.2, "s": rng.randf_range(0.6, 1.1), "r": rng.randf() * TAU}
			if au == "snow":
				p.pos.y = -280
				p.vel = Vector2(rng.randf_range(-15, 15), 40)
			if au == "petals":
				p.pos.y = -280
				p.vel = Vector2(rng.randf_range(10, 30), 45)
			parts.append(p)
	var i := parts.size() - 1
	while i >= 0:
		var q: Dictionary = parts[i]
		q.life += delta
		q.pos += q.vel * delta
		if q.k == "sweat":
			q.vel.y += 60.0 * delta
		if q.life >= q.max:
			parts.remove_at(i)
		i -= 1

func _draw_parts(s: float) -> void:
	_xf(Transform2D(0.0, Vector2(s, s), 0.0, Vector2(0, p_lift + p_float * s)))
	var f: Font = font if font != null else ThemeDB.fallback_font
	for q in parts:
		var a: float = clampf(1.0 - pow(q.life / q.max, 2.0), 0.0, 1.0)
		var pp: Vector2 = q.pos
		match String(q.k):
			"heart", "aura_hearts":
				fill(heart_pts(pp, 13.0 * q.s), Color(1.0, 0.36, 0.5, a), 0.0)
			"sparkle", "aura_sparkle":
				var r: float = 10.0 * q.s * (0.6 + 0.4 * sin(q.life * 10.0))
				draw_colored_polygon(star_pts(pp, r, r * 0.3, 4, 0.0), Color(1.0, 0.95, 0.6, a))
			"note", "aura_notes":
				dot(pp, 5.0, Color(C.line, a))
				draw_line(pp + Vector2(4, 0), pp + Vector2(4, -16), Color(C.line, a), 2.5, true)
				draw_line(pp + Vector2(4, -16), pp + Vector2(11, -12), Color(C.line, a), 2.5, true)
			"sweat":
				draw_colored_polygon(_tear_pts(pp, 6.0), Color(0.55, 0.8, 1.0, a))
			"anger":
				var c := Color(0.92, 0.22, 0.25, a)
				var sz := 9.0 + sin(q.life * 14.0) * 1.5
				for k in 4:
					var ang := PI * 0.5 * k + PI * 0.25
					var d := Vector2(cos(ang), sin(ang))
					draw_arc(pp + d * sz, sz * 0.7, ang + PI * 0.75, ang + PI * 1.25, 6, c, 3.0, true)
			"exclaim", "question", "zzz":
				var txt: String = {"exclaim": "!", "question": "?", "zzz": "Z"}[q.k]
				var fs := 34 if q.k != "zzz" else int(20 + q.life * 6.0)
				draw_string_outline(f, pp, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 6, Color(1, 1, 1, a))
				draw_string(f, pp, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(C.line, a))
			"steam":
				dot(pp, 6.0 + q.life * 6.0, Color(1, 1, 1, a * 0.35))
			"rain":
				draw_colored_polygon(ell(pp, 20, 10, 16), Color(0.55, 0.6, 0.7, a * 0.8))
				for k2 in 3:
					var x := pp.x - 10.0 + k2 * 10.0
					var y := pp.y + 12.0 + fmod(q.life * 60.0 + k2 * 7.0, 20.0)
					draw_line(Vector2(x, y), Vector2(x - 2, y + 6), Color(0.55, 0.8, 1.0, a), 2.0, true)
			"aura_snow":
				dot(pp, 3.5 * q.s, Color(1, 1, 1, a))
			"aura_fire":
				draw_colored_polygon(_tear_pts(pp, 6.0 * q.s), Color(1.0, 0.55, 0.2, a * 0.8))
			"aura_bubbles":
				draw_arc(pp, 7.0 * q.s, 0, TAU, 14, Color(0.8, 0.95, 1.0, a), 2.0, true)
			"aura_petals":
				var pe := ell(Vector2.ZERO, 7.0 * q.s, 4.0 * q.s, 10)
				var pr := PackedVector2Array()
				for v in pe:
					pr.append(v.rotated(q.r + q.life * 2.0) + pp)
				draw_colored_polygon(pr, Color(1.0, 0.72, 0.8, a))

# ================================================================== 触摸
func _to_char(vp: Vector2) -> Vector2:
	var lp := get_global_transform_with_canvas().affine_inverse() * vp
	return root.affine_inverse() * lp

func hit_zone(vp: Vector2) -> String:
	var cp := _to_char(vp)
	var best := ""
	var order := ["tail", "hand", "face", "head", "body"]
	for z in order:
		for h in _hits:
			if h[0] != z:
				continue
			if h.size() == 3:
				if cp.distance_to(h[1]) <= float(h[2]) + 6.0:
					return z
			elif h.size() == 2 and h[1] is Rect2:
				if (h[1] as Rect2).grow(6.0).has_point(cp):
					best = z
	return best

func handle_input(ev: InputEvent) -> bool:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		if ev.pressed:
			var z := hit_zone(ev.position)
			if z == "":
				return false
			_press = true
			_press_pos = ev.position
			_press_time = t
			_press_zone = z
			_moved = 0.0
			_strokes = 0
			_last_dx = 0.0
			_intent = ""
			_pet_dist = 0.0
			_prev_finger = ev.position
			finger_global = ev.position
			return true
		else:
			if not _press:
				return false
			_press = false
			finger_global = Vector2.INF
			if carried:
				carried = false
				airborne = true
				vel = Vector2(clampf(vel.x, -900, 900), clampf(vel.y, -900, 300))
				touched.emit("drop", "drop")
			elif _intent == "pet":
				pass
			elif _moved < 14.0 and t - _press_time < 0.45:
				if sleeping:
					wake()
					touched.emit(_press_zone, "wake")
					return true
				var dbl := t - _last_tap_t < 0.32
				_last_tap_t = t
				_taps.append(t)
				_taps = _taps.filter(func(x): return t - float(x) < 2.5)
				if _taps.size() >= 6:
					_taps.clear()
					touched.emit(_press_zone, "spam")
				elif dbl:
					_last_tap_t = -9.0
					touched.emit(_press_zone, "double")
				else:
					touched.emit(_press_zone, "tap")
			return true
	if ev is InputEventMouseMotion and _press:
		var dpos: Vector2 = ev.position - _prev_finger
		_prev_finger = ev.position
		finger_global = ev.position
		_moved += dpos.length()
		if carried:
			var parent_inv := (get_parent() as CanvasItem).get_global_transform_with_canvas().affine_inverse()
			var np: Vector2 = parent_inv * ev.position + _grab_off
			var dtt := maxf(get_process_delta_time(), 0.001)
			vel = vel.lerp((np - position) / dtt, 0.35)
			position = np
			return true
		# 判断意图：在头/脸上横向划 = 抚摸；往上/竖着拖 = 拎起来
		if _intent == "" and _moved > 12.0:
			var tot: Vector2 = ev.position - _press_pos
			if _press_zone in ["head", "face"] and absf(tot.x) > absf(tot.y) * 1.1:
				_intent = "pet"
			else:
				_intent = "carry"
		if _intent == "pet":
			_pet_dist += absf(dpos.x) + absf(dpos.y) * 0.3
			if absf(dpos.x) > 2.0:
				if _last_dx != 0.0 and signf(dpos.x) != signf(_last_dx):
					_strokes += 1
				_last_dx = dpos.x
			if _pet_dist > 50.0:
				petting = 0.6
				if t - _last_pet_emit > 1.4:
					_last_pet_emit = t
					_strokes = maxi(_strokes, 2)
					touched.emit(_press_zone, "pet")
			return true
		if _intent == "carry" and _moved > 20.0 and not sleeping:
			_start_carry()
		return true
	return false

func _start_carry() -> void:
	if carried:
		return
	carried = true
	sitting = false
	walk_target = INF
	if sleeping:
		sleeping = false
	var parent_inv := (get_parent() as CanvasItem).get_global_transform_with_canvas().affine_inverse()
	_grab_off = position - parent_inv * _prev_finger
	_grab_off.y = maxf(_grab_off.y, 40.0)
	vel = Vector2.ZERO
	touched.emit(_press_zone, "carry")

func cancel_touch() -> void:
	_press = false
	finger_global = Vector2.INF
	if carried:
		carried = false
		airborne = true
