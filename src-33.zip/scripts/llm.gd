extends Node
# 灵伴：AI 接口客户端（OpenAI 兼容格式）。
# 聊天 /chat/completions，语音识别 /audio/transcriptions，语音合成 /audio/speech，画像 /images/generations。
# Key 由用户自己填写，token 费用用户自己承担。

signal usage_changed

const PRESETS := {
	"deepseek": {"name": "DeepSeek（深度求索）", "base": "https://api.deepseek.com", "models": ["deepseek-flash", "deepseek-v4-pro"], "site": "platform.deepseek.com"},
	"dashscope": {"name": "通义千问（阿里云百炼）", "base": "https://dashscope.aliyuncs.com/compatible-mode/v1", "models": ["qwen-plus", "qwen-turbo", "qwen-max"], "site": "bailian.console.aliyun.com"},
	"doubao": {"name": "豆包（火山方舟）", "base": "https://ark.cn-beijing.volces.com/api/v3", "models": ["doubao-seed-1-6-250615", "doubao-1-5-pro-32k-250115"], "site": "console.volcengine.com/ark（模型名也可填你创建的接入点 ep-xxx）"},
	"hunyuan": {"name": "元宝（腾讯混元）", "base": "https://api.hunyuan.cloud.tencent.com/v1", "models": ["hunyuan-turbos-latest", "hunyuan-lite"], "site": "console.cloud.tencent.com/hunyuan"},
	"moonshot": {"name": "Kimi（月之暗面）", "base": "https://api.moonshot.cn/v1", "models": ["moonshot-v1-8k", "kimi-k2-0905-preview"], "site": "platform.moonshot.cn"},
	"zhipu": {"name": "智谱 GLM", "base": "https://open.bigmodel.cn/api/paas/v4", "models": ["glm-4-flash", "glm-4-plus"], "site": "open.bigmodel.cn"},
	"siliconflow": {"name": "硅基流动（多模型聚合）", "base": "https://api.siliconflow.cn/v1", "models": ["deepseek-ai/DeepSeek-V3", "Qwen/Qwen2.5-72B-Instruct", "Qwen/Qwen2.5-7B-Instruct"], "site": "cloud.siliconflow.cn"},
	"openai": {"name": "ChatGPT（OpenAI）", "base": "https://api.openai.com/v1", "models": ["gpt-4o-mini", "gpt-4.1-mini", "gpt-4o"], "site": "platform.openai.com（需能访问国外网络）"},
	"claude": {"name": "Claude（Anthropic）", "base": "https://api.anthropic.com/v1", "models": ["claude-sonnet-4-5", "claude-haiku-4-5"], "site": "console.anthropic.com（需国外网络）", "claude": true},
	"gemini": {"name": "Gemini（Google）", "base": "https://generativelanguage.googleapis.com/v1beta/openai", "models": ["gemini-2.5-flash", "gemini-2.5-pro"], "site": "aistudio.google.com（需国外网络）"},
	"grok": {"name": "Grok（xAI）", "base": "https://api.x.ai/v1", "models": ["grok-4", "grok-3-mini"], "site": "console.x.ai（需国外网络）"},
	"openrouter": {"name": "OpenRouter（一个 Key 用所有模型）", "base": "https://openrouter.ai/api/v1", "models": ["openai/gpt-4o-mini", "anthropic/claude-sonnet-4.5", "google/gemini-2.5-flash"], "site": "openrouter.ai（需国外网络）"},
	"custom": {"name": "自定义（任何 OpenAI 兼容平台）", "base": "", "models": [], "site": ""},
}
const PRESET_ORDER := ["deepseek", "dashscope", "doubao", "hunyuan", "moonshot", "zhipu", "siliconflow", "openai", "claude", "gemini", "grok", "openrouter", "custom"]

var store

func setup(s) -> void:
	store = s

func has_chat() -> bool:
	return store != null and store.key("chat") != "" and String(store.settings.chat.get("base", "")).strip_edges() != ""

func has_stt() -> bool:
	return store != null and store.settings.stt.get("mode", "ime") == "api" and store.key("stt") != ""

func has_tts_api() -> bool:
	return store != null and store.settings.tts.get("mode", "system") == "api" and store.key("tts") != ""

func has_img() -> bool:
	return store != null and store.key("img") != ""

static func join_url(base: String, path: String) -> String:
	var b := base.strip_edges()
	while b.ends_with("/"):
		b = b.left(b.length() - 1)
	if b.ends_with(path):
		return b
	return b + path

static func err_text(code: int, body: String) -> String:
	var msg := ""
	var j = JSON.parse_string(body) if body != "" else null
	if typeof(j) == TYPE_DICTIONARY:
		var e = j.get("error", j.get("message", ""))
		if typeof(e) == TYPE_DICTIONARY:
			msg = String(e.get("message", ""))
		else:
			msg = String(e)
	match code:
		0:
			return "网络连接失败，请检查网络"
		400:
			return "请求格式有误（400）" + ("：" + msg.left(60) if msg != "" else "")
		401, 403:
			return "API Key 无效或没有权限（%d）" % code
		402:
			return "账户余额不足（402）"
		404:
			return "接口地址或模型名不对（404）"
		429:
			return "请求太频繁或额度用完了（429）"
	if code >= 500:
		return "AI 服务器出错了（%d），稍后再试" % code
	return "请求失败（%d）%s" % [code, ("：" + msg.left(60)) if msg != "" else ""]

func _req(url: String, headers: PackedStringArray, method: int, body, timeout: float, cb: Callable, raw := false) -> void:
	var h := HTTPRequest.new()
	h.timeout = timeout
	h.use_threads = true
	add_child(h)
	h.request_completed.connect(func(result: int, code: int, _hd: PackedStringArray, data: PackedByteArray):
		h.queue_free()
		if result != HTTPRequest.RESULT_SUCCESS:
			var why := "网络连接失败，请检查网络"
			if result == HTTPRequest.RESULT_TIMEOUT:
				why = "请求超时，网络慢或服务器忙"
			elif result in [HTTPRequest.RESULT_CANT_RESOLVE, HTTPRequest.RESULT_CANT_CONNECT]:
				why = "连不上服务器，检查网络或接口地址"
			elif result == HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR:
				why = "安全连接失败（TLS）"
			cb.call(false, PackedByteArray(), why, 0)
			return
		if code < 200 or code >= 300:
			cb.call(false, data, err_text(code, data.get_string_from_utf8()), code)
			return
		cb.call(true, data, "", code))
	var err := OK
	if raw:
		err = h.request_raw(url, headers, method, body)
	else:
		err = h.request(url, headers, method, String(body))
	if err != OK:
		h.queue_free()
		cb.call(false, PackedByteArray(), "无法发起请求（地址格式不对？）", 0)

# 聊天：cb.call(ok: bool, content: String, err: String)
func chat(messages: Array, cb: Callable, opts := {}) -> void:
	if not has_chat():
		cb.call(false, "", "还没有设置 AI 的 API Key")
		return
	var cs: Dictionary = store.settings.chat
	var model := String(opts.get("model", cs.get("model", ""))).strip_edges()
	if model == "":
		cb.call(false, "", "还没有填写模型名")
		return
	var body := {"model": model, "messages": messages, "temperature": float(opts.get("temp", cs.get("temp", 0.9))), "max_tokens": int(opts.get("max_tokens", 2000)), "stream": false}
	if bool(opts.get("json", cs.get("json", true))):
		body["response_format"] = {"type": "json_object"}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + store.key("chat")])
	var url := join_url(String(cs.base), "/chat/completions")
	_req(url, headers, HTTPClient.METHOD_POST, JSON.stringify(body), float(opts.get("timeout", 60.0)), func(ok: bool, data: PackedByteArray, err: String, code: int):
		if not ok:
			# 有的服务商不支持 JSON 模式：自动关掉再试一次
			if code == 400 and body.has("response_format") and not opts.get("_retry", false):
				var o2: Dictionary = opts.duplicate()
				o2["json"] = false
				o2["_retry"] = true
				chat(messages, cb, o2)
				return
			cb.call(false, "", err)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		if typeof(j) != TYPE_DICTIONARY:
			cb.call(false, "", "AI 返回的内容看不懂")
			return
		var u = j.get("usage", {})
		if typeof(u) == TYPE_DICTIONARY:
			store.stats.prompt = int(store.stats.get("prompt", 0)) + int(u.get("prompt_tokens", 0))
			store.stats.completion = int(store.stats.get("completion", 0)) + int(u.get("completion_tokens", 0))
		store.stats.requests = int(store.stats.get("requests", 0)) + 1
		store.save_stats()
		usage_changed.emit()
		var content := ""
		var ch = j.get("choices", [])
		if typeof(ch) == TYPE_ARRAY and not ch.is_empty():
			var m = ch[0].get("message", {})
			if typeof(m) == TYPE_DICTIONARY:
				content = String(m.get("content", ""))
		if content == "":
			cb.call(false, "", "AI 没有返回内容")
			return
		cb.call(true, content, ""))

# 看图说话：把一张图片 + 一句话发给视觉模型，cb.call(ok, text, err)
func has_vision() -> bool:
	return store != null and store.key("vision") != ""

func vision_chat(img: Image, text: String, cb: Callable) -> void:
	var k: String = store.key("vision")
	if k == "":
		cb.call(false, "", "还没有设置视觉模型的 Key（设置→高级自定义→陪看视觉接口，或填好阿里云 Key）")
		return
	var vb := String(store.settings.vision.get("base", "")).strip_edges()
	if vb.find("aliyuncs.com") >= 0 or vb == "":
		vb = "https://dashscope.aliyuncs.com/compatible-mode/v1"
	var work := img.duplicate()
	var mx: int = maxi(work.get_width(), work.get_height())
	if mx > 1280:
		var sc := 1280.0 / float(mx)
		work.resize(int(work.get_width() * sc), int(work.get_height() * sc), Image.INTERPOLATE_LANCZOS)
	var uri := "data:image/jpeg;base64," + Marshalls.raw_to_base64(work.save_jpg_to_buffer(0.85))
	var saved := String(store.settings.vision.get("model", "")).strip_edges()
	var list: Array = []
	if saved != "" and saved.find("vl") >= 0 and saved != "qwen3-vl-flash":
		list.append(saved)
	for d in ["qwen3-vl-plus", "qwen-vl-plus", "qwen-vl-max", "qwen-vl-max-latest"]:
		if not list.has(d):
			list.append(d)
	_vision_try(vb, uri, text, k, cb, list, 0, "")

func _vision_try(vb: String, uri: String, text: String, k: String, cb: Callable, list: Array, i: int, last: String) -> void:
	if i >= list.size():
		cb.call(false, "", last)
		return
	var content := [{"type": "text", "text": text}, {"type": "image_url", "image_url": {"url": uri}}]
	var body := {"model": list[i], "messages": [{"role": "user", "content": content}], "max_tokens": 1500}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + k])
	_req(join_url(vb, "/chat/completions"), headers, HTTPClient.METHOD_POST, JSON.stringify(body), 90.0, func(ok: bool, data: PackedByteArray, err: String, code: int):
		if not ok:
			var rawv := data.get_string_from_utf8().strip_edges().replace("\n", " ").left(120)
			var trail := last + ("；" if last != "" else "") + "%s→%s" % [list[i], (rawv if rawv != "" else err)]
			if (code == 404 or err.find("not exist") >= 0 or err.find("model") >= 0) and i + 1 < list.size():
				_vision_try(vb, uri, text, k, cb, list, i + 1, trail)
				return
			cb.call(false, "", trail)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var out := ""
		if typeof(j) == TYPE_DICTIONARY:
			var ch = j.get("choices", [])
			if typeof(ch) == TYPE_ARRAY and not ch.is_empty():
				var m = ch[0].get("message", {})
				if typeof(m) == TYPE_DICTIONARY:
					var c2 = m.get("content", "")
					if typeof(c2) == TYPE_ARRAY:
						for part in c2:
							if typeof(part) == TYPE_DICTIONARY:
								out += String(part.get("text", ""))
					else:
						out = String(c2)
			var u = j.get("usage", {})
			if typeof(u) == TYPE_DICTIONARY:
				store.stats.prompt = int(store.stats.get("prompt", 0)) + int(u.get("prompt_tokens", 0))
				store.stats.completion = int(store.stats.get("completion", 0)) + int(u.get("completion_tokens", 0))
				store.stats.requests = int(store.stats.get("requests", 0)) + 1
				store.save_stats()
				usage_changed.emit()
		if out.strip_edges() == "":
			cb.call(false, "", "视觉模型没有返回内容")
			return
		# 记住这次成功的模型，下次直接用
		store.settings.vision["model"] = list[i]
		store.save_settings()
		cb.call(true, out.strip_edges(), ""))

# 语音识别：cb.call(ok, text, err)
func transcribe(wav: PackedByteArray, cb: Callable) -> void:
	var ss: Dictionary = store.settings.stt
	var k: String = store.key("stt")
	if k == "":
		cb.call(false, "", "还没有设置语音识别的 API Key")
		return
	if String(ss.base).find("aliyuncs.com") >= 0:
		_transcribe_ds(wav, k, cb)
		return
	var boundary := "----LingBan%d" % (randi() % 1000000000)
	var body := PackedByteArray()
	var head := "--%s\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\n%s\r\n" % [boundary, String(ss.model)]
	head += "--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voice.wav\"\r\nContent-Type: audio/wav\r\n\r\n" % boundary
	body.append_array(head.to_utf8_buffer())
	body.append_array(wav)
	body.append_array(("\r\n--%s--\r\n" % boundary).to_utf8_buffer())
	var headers := PackedStringArray(["Content-Type: multipart/form-data; boundary=" + boundary, "Authorization: Bearer " + k])
	_req(join_url(String(ss.base), "/audio/transcriptions"), headers, HTTPClient.METHOD_POST, body, 40.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		if not ok:
			cb.call(false, "", err)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var txt := String(j.get("text", "")) if typeof(j) == TYPE_DICTIONARY else ""
		cb.call(true, txt.strip_edges(), ""), true)

# 阿里云百炼语音识别：qwen3-asr-flash，走兼容模式 chat/completions，音频用 base64 传
func _transcribe_ds(wav: PackedByteArray, key: String, cb: Callable) -> void:
	var ss: Dictionary = store.settings.stt
	var model := String(ss.get("model", "")).strip_edges()
	if model == "" or model.find("/") >= 0:
		model = "qwen3-asr-flash"
	var base := String(ss.base).strip_edges().rstrip("/")
	if base.find("/compatible-mode") < 0:
		var i := base.find("/api/")
		base = (base.left(i) if i >= 0 else base) + "/compatible-mode/v1"
	var body := {"model": model, "stream": false, "messages": [{"role": "user", "content": [{"type": "input_audio", "input_audio": {"data": "data:audio/wav;base64," + Marshalls.raw_to_base64(wav)}}]}], "asr_options": {"enable_itn": false}}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + key])
	_req(base + "/chat/completions", headers, HTTPClient.METHOD_POST, JSON.stringify(body), 40.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		if not ok:
			var raw := data.get_string_from_utf8().strip_edges().replace("\n", " ").left(140)
			cb.call(false, "", err + ("｜" + raw if raw != "" else ""))
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var txt := ""
		if typeof(j) == TYPE_DICTIONARY and typeof(j.get("choices")) == TYPE_ARRAY and not j.choices.is_empty():
			var m = j.choices[0].get("message", {})
			if typeof(m) == TYPE_DICTIONARY:
				txt = String(m.get("content", ""))
		cb.call(true, txt.strip_edges(), ""))

# 语音合成：cb.call(ok, mp3_bytes, err)
func speech(text: String, voice: String, speed: float, cb: Callable) -> void:
	var ts: Dictionary = store.settings.tts
	var k: String = store.key("tts")
	if k == "":
		cb.call(false, PackedByteArray(), "还没有设置语音合成的 API Key")
		return
	if is_dashscope_tts(ts):
		_speech_dashscope(text, voice, k, cb)
		return
	var body := {"model": String(ts.model), "input": text, "voice": voice, "response_format": "mp3", "speed": clampf(speed, 0.5, 2.0)}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + k])
	_req(join_url(String(ts.base), "/audio/speech"), headers, HTTPClient.METHOD_POST, JSON.stringify(body), 40.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		cb.call(ok, data, err))

static func is_dashscope_tts(ts: Dictionary) -> bool:
	var m := String(ts.get("model", ""))
	return String(ts.get("base", "")).find("aliyuncs.com") >= 0 or m.begins_with("qwen") or m.begins_with("cosyvoice")

# 实际使用的阿里云模型：专属域名（maas.aliyuncs.com）上只有 CosyVoice，旧设置里的 qwen3-tts 自动换成 CosyVoice
static func ds_model(ts: Dictionary) -> String:
	var m := String(ts.get("model", "")).strip_edges()
	if m == "" or m.find("/") >= 0:
		m = "cosyvoice-v3-flash"
	if m.begins_with("qwen") and String(ts.get("base", "")).find("maas.aliyuncs.com") >= 0:
		m = "cosyvoice-v3-flash"
	return m

# 阿里云百炼语音：先拿到音频地址，再下载 WAV。CosyVoice 走 SpeechSynthesizer，Qwen3-TTS 走 multimodal-generation
func _speech_dashscope(text: String, voice: String, key: String, cb: Callable) -> void:
	var ts: Dictionary = store.settings.tts
	var model := ds_model(ts)
	var body: Dictionary
	var path := ""
	if model.begins_with("cosyvoice"):
		path = "/services/audio/tts/SpeechSynthesizer"
		body = {"model": model, "input": {"text": text.left(500), "voice": voice, "format": "wav", "sample_rate": 24000}}
	else:
		path = "/services/aigc/multimodal-generation/generation"
		body = {"model": model, "input": {"text": text.left(580), "voice": voice, "language_type": "Auto"}}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + key])
	var url := join_url(String(ts.base), path)
	_req(url, headers, HTTPClient.METHOD_POST, JSON.stringify(body), 40.0, func(ok: bool, data: PackedByteArray, err: String, _code: int):
		if not ok:
			var raw := data.get_string_from_utf8().strip_edges().replace("\n", " ").left(140)
			cb.call(false, PackedByteArray(), err + ("｜" + raw if raw != "" else ""))
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var au := ""
		if typeof(j) == TYPE_DICTIONARY and typeof(j.get("output")) == TYPE_DICTIONARY and typeof(j.output.get("audio")) == TYPE_DICTIONARY:
			au = String(j.output.audio.get("url", ""))
		if au == "":
			cb.call(false, PackedByteArray(), "阿里云没有返回声音｜" + data.get_string_from_utf8().strip_edges().left(140))
			return
		_req(au if au.find("127.0.0.1") >= 0 else au.replace("http://", "https://"), PackedStringArray(), HTTPClient.METHOD_GET, "", 40.0, func(ok2: bool, d2: PackedByteArray, e2: String, _c2: int):
			cb.call(ok2, d2, e2)))

# 画像：cb.call(ok, Image, err)。兼容 OpenAI（data[].url/b64_json）和硅基流动（images[].url）两种返回
func image(prompt: String, cb: Callable, portrait := false) -> void:
	var isec: Dictionary = store.settings.img
	var k: String = store.key("img")
	if k == "":
		cb.call(false, null, "还没有设置画像的 API Key")
		return
	var model := String(isec.model)
	if String(isec.base).find("aliyuncs.com") >= 0:
		_image_ds(prompt, k, cb, portrait)
		return
	var body := {"model": model, "prompt": prompt}
	if String(isec.base).find("siliconflow") >= 0:
		body["image_size"] = "768x1024" if portrait else "1024x1024"
		body["batch_size"] = 1
	else:
		body["size"] = "1024x1024"
		body["n"] = 1
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + k])
	_req(join_url(String(isec.base), "/images/generations"), headers, HTTPClient.METHOD_POST, JSON.stringify(body), 120.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		if not ok:
			cb.call(false, null, err)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		if typeof(j) != TYPE_DICTIONARY:
			cb.call(false, null, "画像接口返回看不懂")
			return
		var arr = j.get("images", j.get("data", []))
		if typeof(arr) != TYPE_ARRAY or arr.is_empty():
			cb.call(false, null, "没有生成图片")
			return
		var it = arr[0]
		if typeof(it) == TYPE_DICTIONARY and String(it.get("b64_json", "")) != "":
			cb.call(true, _img_from_bytes(Marshalls.base64_to_raw(String(it.b64_json))), "")
			return
		var url := String(it.get("url", "")) if typeof(it) == TYPE_DICTIONARY else ""
		if url == "":
			cb.call(false, null, "没有图片地址")
			return
		_req(url, PackedStringArray(), HTTPClient.METHOD_GET, "", 60.0, func(ok2: bool, d2: PackedByteArray, e2: String, _c2: int):
			if not ok2:
				cb.call(false, null, e2)
				return
			var img := _img_from_bytes(d2)
			cb.call(img != null, img, "" if img != null else "图片格式不支持")))

# 阿里云百炼画像：通义千问 Image，同步接口，返回图片地址
func _image_ds(prompt: String, key: String, cb: Callable, portrait := false) -> void:
	var isec: Dictionary = store.settings.img
	var m := String(isec.get("model", "")).strip_edges()
	var list: Array = []
	if m.begins_with("qwen-image") and m.find("edit") < 0 and m != "qwen-image-plus":
		list.append(m)
	for d in ["qwen-image-2.0", "qwen-image-2.0-pro", "qwen-image-plus", "qwen-image-max"]:
		if not list.has(d):
			list.append(d)
	_image_ds_try(prompt, key, cb, portrait, list, 0, "")

func _image_ds_try(prompt: String, key: String, cb: Callable, portrait: bool, list: Array, i: int, last: String) -> void:
	if i >= list.size():
		cb.call(false, null, last)
		return
	var body := {"model": list[i], "input": {"messages": [{"role": "user", "content": [{"text": prompt.left(780)}]}]}, "parameters": {"size": "928*1664" if portrait else "1328*1328", "watermark": false, "prompt_extend": true}}
	_ds_image_call(body, key, func(ok: bool, img, err: String):
		if ok or (err.find("404") < 0 and err.find("not exist") < 0):
			cb.call(ok, img, err)
		else:
			_image_ds_try(prompt, key, cb, portrait, list, i + 1, "%s：%s" % [list[i], err]))

# 阿里云百炼改图：拿一张立绘换表情（qwen-image-edit），cb.call(ok, Image, err)
func image_edit(img: Image, prompt: String, cb: Callable) -> void:
	var k: String = store.key("img")
	if k == "" or String(store.settings.img.base).find("aliyuncs.com") < 0:
		cb.call(false, null, "多表情需要阿里云百炼的画像接口和 Key")
		return
	var jpg := img.save_jpg_to_buffer(0.92)
	var b64 := "data:image/jpeg;base64," + Marshalls.raw_to_base64(jpg)
	_image_edit_try(b64, prompt, k, cb, ["qwen-image-2.0", "qwen-image-edit-plus", "qwen-image-edit"], 0, "")

func _image_edit_try(b64: String, prompt: String, k: String, cb: Callable, list: Array, i: int, last: String) -> void:
	if i >= list.size():
		cb.call(false, null, last)
		return
	var body := {"model": list[i], "input": {"messages": [{"role": "user", "content": [{"image": b64}, {"text": prompt.left(780)}]}]}, "parameters": {"watermark": false}}
	_ds_image_call(body, k, func(ok: bool, im, err: String):
		if ok or (err.find("404") < 0 and err.find("not exist") < 0):
			cb.call(ok, im, err)
		else:
			_image_edit_try(b64, prompt, k, cb, list, i + 1, "%s：%s" % [list[i], err]))

func _ds_image_call(body: Dictionary, key: String, cb: Callable) -> void:
	var isec: Dictionary = store.settings.img
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + key])
	_req(join_url(String(isec.base), "/services/aigc/multimodal-generation/generation"), headers, HTTPClient.METHOD_POST, JSON.stringify(body), 150.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		var raw := data.get_string_from_utf8().strip_edges().replace("\n", " ").left(140)
		if not ok:
			cb.call(false, null, err + ("｜" + raw if raw != "" else ""))
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var url := ""
		if typeof(j) == TYPE_DICTIONARY and typeof(j.get("output")) == TYPE_DICTIONARY:
			var ch = j.output.get("choices", [])
			if typeof(ch) == TYPE_ARRAY and not ch.is_empty():
				var ct = ch[0].get("message", {}).get("content", [])
				if typeof(ct) == TYPE_ARRAY:
					for it in ct:
						if typeof(it) == TYPE_DICTIONARY and String(it.get("image", "")) != "":
							url = String(it.image)
		if url == "":
			cb.call(false, null, "阿里云没有返回图片｜" + raw)
			return
		_req(url.replace("http://", "https://"), PackedStringArray(), HTTPClient.METHOD_GET, "", 60.0, func(ok2: bool, d2: PackedByteArray, e2: String, _c2: int):
			if not ok2:
				cb.call(false, null, e2)
				return
			var img := _img_from_bytes(d2)
			cb.call(img != null, img, "" if img != null else "图片格式不支持")))

static func _img_from_bytes(b: PackedByteArray) -> Image:
	if b.is_empty():
		return null
	var img := Image.new()
	var e := ERR_FILE_UNRECOGNIZED
	if b.size() > 4 and b[0] == 0x89 and b[1] == 0x50:
		e = img.load_png_from_buffer(b)
	elif b.size() > 4 and b[0] == 0xFF and b[1] == 0xD8:
		e = img.load_jpg_from_buffer(b)
	elif b.size() > 12 and b[8] == 0x57 and b[9] == 0x45:
		e = img.load_webp_from_buffer(b)
	else:
		e = img.load_png_from_buffer(b)
		if e != OK:
			e = img.load_jpg_from_buffer(b)
	return img if e == OK else null

# 从模型回复中取出 JSON 对象（容忍 ```json 代码块和前后废话）
static func _quiet_parse(s: String):
	var jj := JSON.new()
	if jj.parse(s) == OK:
		return jj.data
	return null

static func extract_json(content: String):
	var s := content.strip_edges()
	var j = _quiet_parse(s) if s.begins_with("{") else null
	if typeof(j) == TYPE_DICTIONARY:
		return j
	var a := s.find("{")
	var b := s.rfind("}")
	if a >= 0 and b > a:
		j = _quiet_parse(s.substr(a, b - a + 1))
		if typeof(j) == TYPE_DICTIONARY:
			return j
	return null
