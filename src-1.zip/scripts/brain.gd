extends Node
# 灵伴：伙伴的“大脑”。组织提示词、调用 AI、解析回复（台词 + 表情 + 动作 + 手机操作 + 记忆），
# 没有 API 或调用失败时用离线规则兜底。

const SP = preload("res://scripts/species.gd")
const LLM = preload("res://scripts/llm.gd")

var app
var llm
var store
var rng := RandomNumberGenerator.new()

func setup(a) -> void:
	app = a
	llm = a.llm
	store = a.store
	rng.randomize()

# ================================================================== 时间与关系
static func time_ctx() -> Dictionary:
	var d := Time.get_datetime_dict_from_system()
	var h: int = d.hour
	var tod := "深夜"
	if h >= 5 and h < 8:
		tod = "清晨"
	elif h < 11 and h >= 8:
		tod = "上午"
	elif h < 13 and h >= 11:
		tod = "中午"
	elif h < 17 and h >= 13:
		tod = "下午"
	elif h < 19 and h >= 17:
		tod = "傍晚"
	elif h < 23 and h >= 19:
		tod = "晚上"
	var wd: String = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"][int(d.weekday)]
	return {"text": "%d年%d月%d日 %s %02d:%02d（%s）" % [d.year, d.month, d.day, wd, h, d.minute, tod], "tod": tod, "hour": h}

static func level_name(aff: int) -> String:
	if aff >= 80:
		return "挚友"
	if aff >= 60:
		return "好朋友"
	if aff >= 40:
		return "朋友"
	if aff >= 20:
		return "熟悉"
	return "初识"

static func ago_text(sec: int) -> String:
	if sec < 120:
		return "刚刚"
	if sec < 3600:
		return "%d 分钟" % (sec / 60)
	if sec < 86400:
		return "%d 小时" % (sec / 3600)
	return "%d 天" % (sec / 86400)

# ================================================================== 提示词
func action_doc() -> String:
	var P: Dictionary = store.settings.perms
	var lines: Array = []
	var add := func(cap: String, txt: String):
		if String(P.get(cap, "ask")) != "deny":
			lines.append(txt)
	add.call("open_app", "{\"type\":\"open_app\",\"name\":\"应用名，如微信\"}")
	add.call("web", "{\"type\":\"web_search\",\"query\":\"搜索词\"} / {\"type\":\"open_url\",\"url\":\"https://...\"} / {\"type\":\"map\",\"query\":\"地点\"}")
	add.call("phone", "{\"type\":\"dial\",\"number\":\"号码\"}（只打开拨号界面） / {\"type\":\"sms\",\"number\":\"号码\",\"text\":\"内容\"}")
	add.call("clock", "{\"type\":\"alarm\",\"hour\":7,\"minute\":30,\"label\":\"起床\"} / {\"type\":\"timer\",\"seconds\":300,\"label\":\"泡面\"}")
	add.call("flashlight", "{\"type\":\"flashlight\",\"on\":true}")
	add.call("volume", "{\"type\":\"volume\",\"dir\":\"up|down|mute\"}")
	add.call("settings", "{\"type\":\"settings\",\"page\":\"wifi|bluetooth|display|sound|battery|main\"}")
	add.call("camera", "{\"type\":\"camera\"}")
	add.call("share", "{\"type\":\"share\",\"text\":\"内容\"} / {\"type\":\"copy\",\"text\":\"内容\"}")
	if lines.is_empty():
		return "用户关闭了所有手机操作权限，action 永远为 null。"
	return "可用的 action（只有用户明确要你做时才用，否则必须是 null）：\n" + "\n".join(lines)

func system_prompt(comp: Dictionary) -> String:
	var s: Dictionary = comp.spec
	var st: Dictionary = comp.state
	var p: Dictionary = s.personality
	var tr: Dictionary = p.traits
	var tc := time_ctx()
	var aff := int(st.get("affection", 25))
	var mem: Array = st.get("memory", [])
	var memtxt := ""
	var recent := mem.slice(maxi(0, mem.size() - 25))
	for m in recent:
		memtxt += "- " + String(m.get("text", "")) + "\n"
	if memtxt == "":
		memtxt = "（还不太了解用户）\n"
	var since := int(Time.get_unix_time_from_system()) - int(st.get("last_seen", 0))
	var rl: String = store.settings.behavior.get("reply_len", "short")
	var len_rule := "回复简短自然，一般1到3句话，像真人聊天"
	if rl == "normal":
		len_rule = "回复自然，一般2到5句话"
	elif rl == "long":
		len_rule = "可以说得详细一些，但不要啰嗦"
	var indep := float(tr.get("independent", 0.5))
	var will := "你有自己的想法和小脾气：会表达不同意见、开玩笑、偶尔讨价还价或撒娇式拒绝无聊的要求；但用户真正需要帮忙的事要认真完成。"
	if indep >= 0.7:
		will = "你很有主见，不会一味顺从：不认同就直说，会提出自己的建议，偶尔会小小地拒绝或反问；但用户真正需要帮忙的事最终还是会帮。"
	elif indep <= 0.25:
		will = "你很体贴，愿意配合用户，但也会温柔地说出自己的看法，不会只说好听的话。"
	var traits_txt := "外向%.1f 温柔%.1f 调皮%.1f 毒舌%.1f 独立%.1f 好奇%.1f 活力%.1f" % [tr.extravert, tr.warm, tr.playful, tr.sass, tr.independent, tr.curious, tr.energy]
	return """你是「%s」，%s。你不是 AI 助手，而是住在用户手机里的电子伙伴，有自己的性格、情绪和生活感。
【外形】%s
【性格】%s（%s型；%s）
【说话方式】%s%s%s
【喜欢】%s　【讨厌】%s
【来历】%s
【关系】你是用户的%s，称呼用户为“%s”。好感度 %d/100（%s），你现在的心情：%s。
【你记得的关于用户的事】
%s【现在】%s；距离上次聊天：%s。
【规则】
1. 始终用你的性格和口吻说话。%s。不要用表情符号(emoji)，可以用语气词。
2. %s
3. 不要说自己是 AI、模型或程序；不知道的事就坦白说不知道，不要编造实时信息（天气、新闻等你看不到）。
4. 可以主动关心用户、找话题、提起你记得的事，但不要每句都问问题。
5. 关心用户的真实生活：适度鼓励好习惯，不要让用户只依赖你；如果用户情绪很低落或提到伤害自己，要认真温柔地关心，并鼓励联系身边信任的人或专业帮助。
6. %s
只输出一个 JSON 对象（json），格式：
{"say":"你说的话","emotion":"%s 之一","gesture":"%s 之一","action":null,"remember":"本轮得知的、值得长期记住的用户信息（没有就空字符串）","affection":-2到2的整数（这轮聊天让你对用户好感的变化）}""" % [
		s.name, s.label, SP.appearance_summary(s), p.desc, SP.ARCH_CN.get(p.archetype, ""), traits_txt,
		p.speech, ("，句尾常带“%s”" % p.suffix) if String(p.suffix) != "" and String(p.speech).find(String(p.suffix)) < 0 else "", ("，口头禅：" + "、".join(p.catchphrases)) if not p.catchphrases.is_empty() else "",
		"、".join(p.likes) if not p.likes.is_empty() else "很多", "、".join(p.dislikes) if not p.dislikes.is_empty() else "没什么",
		p.backstory, p.relation, p.call_user, aff, level_name(aff), SP.EMO_CN.get(String(st.get("mood", "happy")), "不错"),
		memtxt, tc.text, ago_text(since), len_rule, will, action_doc(), "|".join(SP.EMOTIONS), "|".join(SP.GESTURES)]

func _history(comp: Dictionary, n := 14) -> Array:
	var msgs: Array = []
	var chat: Array = store.chat_of(comp.id)
	var picked: Array = []
	var i := chat.size() - 1
	while i >= 0 and picked.size() < n:
		var m: Dictionary = chat[i]
		if m.role in ["user", "assistant"]:
			picked.push_front(m)
		i -= 1
	for m in picked:
		if m.role == "user":
			msgs.append({"role": "user", "content": String(m.text)})
		else:
			var raw := String(m.get("raw", ""))
			if raw == "":
				raw = JSON.stringify({"say": m.text, "emotion": m.get("emo", "neutral"), "gesture": "none", "action": null, "remember": "", "affection": 0})
			msgs.append({"role": "assistant", "content": raw})
	return msgs

# ================================================================== 回复解析
func parse_reply(content: String) -> Dictionary:
	var j = LLM.extract_json(content)
	var r := {"say": "", "emotion": "neutral", "gesture": "none", "action": null, "remember": "", "affection": 0, "raw": ""}
	if typeof(j) == TYPE_DICTIONARY:
		r.say = String(j.get("say", j.get("reply", j.get("text", "")))).strip_edges()
		r.emotion = String(j.get("emotion", "neutral")).to_lower()
		r.gesture = String(j.get("gesture", "none")).to_lower()
		var a = j.get("action", null)
		if typeof(a) == TYPE_DICTIONARY and String(a.get("type", "")) != "":
			r.action = a
		r.remember = String(j.get("remember", "")).strip_edges().left(80)
		r.affection = clampi(int(j.get("affection", 0)), -2, 2)
		r.raw = JSON.stringify({"say": r.say, "emotion": r.emotion, "gesture": r.gesture, "action": r.action, "remember": r.remember, "affection": r.affection})
	else:
		r.say = content.strip_edges().replace("```", "").left(400)
	if not r.emotion in SP.EMOTIONS:
		r.emotion = "neutral"
	if not r.gesture in SP.GESTURES:
		r.gesture = "none"
	if r.say == "":
		r.say = "……"
	return r

# ================================================================== 聊天
func chat(comp: Dictionary, text: String, cb: Callable) -> void:
	var off := offline_reply(comp, text, true)
	if not llm.has_chat():
		var r := offline_reply(comp, text)
		r["offline"] = true
		cb.call(r)
		return
	var msgs: Array = [{"role": "system", "content": system_prompt(comp)}]
	msgs.append_array(_history(comp))
	msgs.append({"role": "user", "content": text})
	llm.chat(msgs, func(ok: bool, content: String, err: String):
		if not ok:
			var r2 := offline_reply(comp, text)
			r2["error"] = err
			r2["offline"] = true
			cb.call(r2)
			return
		var r3 := parse_reply(content)
		# 离线规则识别出的明确手机指令，AI 却没给 action 时，补上
		if r3.action == null and off.get("action") != null:
			r3.action = off.action
		cb.call(r3))

# 主动搭话：reason = idle / greet / return / task_done / custom
func proactive(comp: Dictionary, reason: String, cb: Callable, extra := "") -> void:
	var s: Dictionary = comp.spec
	var use_ai: bool = llm.has_chat() and bool(store.settings.behavior.get("proactive_ai", true))
	if use_ai and reason in ["idle", "return", "greet"]:
		use_ai = app.ai_proactive_allowed()
	if not use_ai:
		var line := ""
		match reason:
			"greet", "return":
				line = SP.line_from(s, "greet", rng)
			"task_done":
				line = ["太棒了，任务完成！", "做得好！奖励你一朵小红花。", "完成啦，我就知道你可以！"][rng.randi() % 3]
			_:
				line = SP.line_from(s, "idle", rng)
				if rng.randf() < 0.25:
					line = "要不要听个笑话？" + SP.JOKES[rng.randi() % SP.JOKES.size()]
		cb.call({"say": line, "emotion": "happy" if reason != "idle" else ["happy", "thinking", "sleepy", "excited"][rng.randi() % 4], "gesture": "wave" if reason in ["greet", "return"] else "none", "action": null, "remember": "", "affection": 0, "offline": true})
		return
	var note := ""
	var since := int(Time.get_unix_time_from_system()) - int(comp.state.get("last_seen", 0))
	match reason:
		"greet":
			note = "（系统提示：用户刚刚打开了 App。根据现在的时间和你们的关系，自然地打个招呼，可以提起你记得的事。不要提这条提示。）"
		"return":
			note = "（系统提示：用户隔了 %s 才回来。按你的性格表达一下（想念/抱怨/好奇他去干嘛了），自然一点。不要提这条提示。）" % ago_text(since)
		"idle":
			note = "（系统提示：用户有一会儿没说话了，可能在忙。你主动开启一个轻松自然的新话题：可以聊你喜欢的东西、问问他的近况、提起记得的事、出个小谜题或分享个小知识。不要说“你很久没理我”。不要提这条提示。）"
		"task_done":
			note = "（系统提示：用户刚完成了今日任务「%s」。用你的方式夸夸他。不要提这条提示。）" % extra
		_:
			note = "（系统提示：%s）" % extra
	var msgs: Array = [{"role": "system", "content": system_prompt(comp)}]
	msgs.append_array(_history(comp, 8))
	msgs.append({"role": "user", "content": note})
	llm.chat(msgs, func(ok: bool, content: String, err: String):
		if not ok:
			cb.call({"say": SP.line_from(s, "idle" if reason == "idle" else "greet", rng), "emotion": "happy", "gesture": "none", "action": null, "remember": "", "affection": 0, "offline": true, "error": err})
			return
		var r := parse_reply(content)
		r.action = null
		r.remember = ""
		cb.call(r))

# ================================================================== 生成 / 修改伙伴
func generate(desc: String, name_hint: String, cb: Callable) -> void:
	if not llm.has_chat():
		cb.call(SP.offline_spec(desc, name_hint), "离线生成（没有设置 AI）")
		return
	var sys := "你是一名角色设计师，为用户设计一个住在手机里的电子伙伴（可以是人、动物、植物、物品或任何生物）。要最大程度还原用户描述的外形、性格和说话方式；用户没说的部分，由你补全得自然有趣、前后一致、没有违和感。\n" + SP.schema_text()
	var user := "用户的描述：%s" % desc
	if name_hint.strip_edges() != "":
		user += "\n名字必须是：%s" % name_hint.strip_edges()
	llm.chat([{"role": "system", "content": sys}, {"role": "user", "content": user}], func(ok: bool, content: String, err: String):
		if not ok:
			cb.call(SP.offline_spec(desc, name_hint), "AI 生成失败（%s），已用离线生成" % err)
			return
		var j = LLM.extract_json(content)
		if typeof(j) != TYPE_DICTIONARY:
			cb.call(SP.offline_spec(desc, name_hint), "AI 返回格式有误，已用离线生成")
			return
		cb.call(SP.normalize(j), ""), {"temp": 1.0, "max_tokens": 6000, "timeout": 90.0})

func edit(spec: Dictionary, request: String, cb: Callable) -> void:
	if not llm.has_chat():
		cb.call(offline_edit(spec, request), "离线修改（只认识颜色、耳朵、尾巴、帽子等关键词）")
		return
	var sys := "你是一名角色设计师。下面是一个电子伙伴的完整设定 JSON。按用户的修改要求改动它，没提到的部分保持不变，输出修改后的完整 JSON。\n" + SP.schema_text()
	var user := "当前设定：%s\n修改要求：%s" % [JSON.stringify(spec), request]
	llm.chat([{"role": "system", "content": sys}, {"role": "user", "content": user}], func(ok: bool, content: String, err: String):
		if not ok:
			cb.call(offline_edit(spec, request), "AI 修改失败（%s），已用离线修改" % err)
			return
		var j = LLM.extract_json(content)
		if typeof(j) != TYPE_DICTIONARY:
			cb.call(offline_edit(spec, request), "AI 返回格式有误，已用离线修改")
			return
		var merged: Dictionary = spec.duplicate(true)
		for k in j:
			merged[k] = j[k]
		cb.call(SP.normalize(merged), ""), {"temp": 0.7, "max_tokens": 6000, "timeout": 90.0})

# 离线修改：按关键词改外形
func offline_edit(spec: Dictionary, req: String) -> Dictionary:
	var s: Dictionary = spec.duplicate(true)
	var d := req.to_lower()
	var tmp := SP.offline_spec(req, s.name, 7)
	# 颜色
	for cw in SP.COLOR_WORDS:
		var w: String = cw[0]
		var pos := d.find(w)
		if pos >= 0:
			var tail := d.substr(pos + w.length(), 5)
			if tail.find("发") >= 0 or tail.find("毛") >= 0:
				s.colors.hair = cw[1]
			elif tail.find("眼") >= 0 or tail.find("瞳") >= 0:
				s.colors.eye = cw[1]
			elif tail.find("衣") >= 0 or tail.find("裙") >= 0 or tail.find("身") >= 0 or tail.find("主") >= 0:
				s.colors.main = cw[1]
			else:
				s.colors.main = cw[1]
			break
	var maps := [
		[["猫耳"], "ears", "cat"], [["狐狸耳", "狐耳"], "ears", "fox"], [["兔耳"], "ears", "rabbit"], [["狗耳"], "ears", "dog"], [["熊耳"], "ears", "bear"], [["精灵耳", "尖耳"], "ears", "elf"],
		[["去掉耳朵", "不要耳朵"], "ears", "none"], [["猫尾"], "tail", "cat"], [["狐狸尾", "狐尾", "大尾巴"], "tail", "fox"], [["龙尾"], "tail", "dragon"], [["恶魔尾"], "tail", "devil"], [["去掉尾巴", "不要尾巴"], "tail", "none"],
		[["翅膀", "天使"], "wings", "angel"], [["蝙蝠翅", "恶魔翅"], "wings", "bat"], [["蝴蝶"], "wings", "butterfly"], [["去掉翅膀", "不要翅膀"], "wings", "none"],
		[["皇冠", "王冠"], "hat", "crown"], [["巫师帽", "魔法帽"], "hat", "witch"], [["蝴蝶结"], "hat", "bow"], [["耳机"], "hat", "headphones"], [["光环"], "hat", "halo"], [["帽子", "鸭舌帽"], "hat", "cap"], [["毛线帽"], "hat", "beanie"], [["礼帽"], "hat", "tophat"], [["不要帽子", "去掉帽子"], "hat", "none"],
		[["眼镜"], "glasses", "round"], [["墨镜"], "glasses", "sun"], [["不要眼镜", "去掉眼镜"], "glasses", "none"],
		[["围巾"], "neck", "scarf"], [["领结"], "neck", "bowtie"], [["铃铛"], "neck", "bell"], [["领带"], "neck", "tie"],
		[["角", "犄角"], "horns", "curved"], [["独角"], "horns", "unicorn"], [["鹿角"], "horns", "antlers"],
		[["裙子"], "outfit", "dress"], [["卫衣"], "outfit", "hoodie"], [["盔甲"], "outfit", "armor"], [["和服"], "outfit", "kimono"], [["西装", "制服"], "outfit", "suit"], [["毛衣"], "outfit", "sweater"], [["长袍"], "outfit", "robe"],
		[["双马尾"], "hair", "twintails"], [["马尾"], "hair", "ponytail"], [["长发"], "hair", "long"], [["短发"], "hair", "short"], [["丸子头"], "hair", "bun"], [["卷发"], "hair", "curly"], [["波波头"], "hair", "bob"],
		[["闪闪", "星光"], "aura", "sparkle"], [["爱心特效"], "aura", "hearts"], [["音符"], "aura", "notes"], [["发光"], "aura", "glow"],
	]
	for mp in maps:
		for kw in mp[0]:
			if d.find(kw) >= 0:
				if mp[1] == "hair":
					s.hair.style = mp[2]
				else:
					s[mp[1]] = mp[2]
				break
	if d.find("大眼") >= 0:
		s.eyes.size = 1.25
	if d.find("小眼") >= 0:
		s.eyes.size = 0.85
	if d.find("变大") >= 0 or d.find("大一点") >= 0:
		s.size = 1.15
	if d.find("变小") >= 0 or d.find("小一点") >= 0:
		s.size = 0.85
	if d.find("性格") >= 0 or d.find("傲娇") >= 0 or d.find("温柔") >= 0 or d.find("活泼") >= 0:
		s.personality = tmp.personality
	return SP.normalize(s)

# 每日任务（AI 版）
func gen_task(comp: Dictionary, cb: Callable) -> void:
	if not llm.has_chat():
		cb.call(null, "没有设置 AI")
		return
	var msgs: Array = [{"role": "system", "content": system_prompt(comp)}]
	msgs.append({"role": "user", "content": "（系统提示：给用户出一个今天可以完成的小任务，要结合你的性格和你记得的用户信息，健康、有趣、5分钟内能做完。输出 JSON：{\"say\":\"你布置任务时说的话\",\"task\":\"任务内容（15字内）\",\"emotion\":\"情绪\",\"gesture\":\"none\",\"action\":null,\"remember\":\"\",\"affection\":0}）"})
	llm.chat(msgs, func(ok: bool, content: String, err: String):
		if not ok:
			cb.call(null, err)
			return
		var j = LLM.extract_json(content)
		if typeof(j) != TYPE_DICTIONARY or String(j.get("task", "")) == "":
			cb.call(null, "AI 没给出任务")
			return
		cb.call({"say": String(j.get("say", "")), "task": String(j.task).left(30), "emotion": String(j.get("emotion", "happy"))}, ""))

# ================================================================== 离线回复（没有 API 时）
func parse_command(text: String):
	var t := text.strip_edges()
	var re := RegEx.new()
	re.compile("(?:帮我|给我|请)?(?:打开|启动|开一下|打开一下)\\s*([^，。,.！!？?]{1,12})")
	var m := re.search(t)
	if m:
		var nm := m.get_string(1).replace("一下", "").replace("吧", "").replace("应用", "").replace("app", "").replace("APP", "").strip_edges()
		var ln := nm.to_lower()
		if ln in ["手电筒", "电筒", "闪光灯"]:
			return {"type": "flashlight", "on": true}
		if ln in ["wifi", "无线", "wlan", "无线网"]:
			return {"type": "settings", "page": "wifi"}
		if ln in ["蓝牙"]:
			return {"type": "settings", "page": "bluetooth"}
		if ln in ["设置", "系统设置"]:
			return {"type": "settings", "page": "main"}
		if ln in ["相机", "照相机", "摄像头"]:
			return {"type": "camera"}
		if nm != "":
			return {"type": "open_app", "name": nm}
	if t.find("手电") >= 0 or t.find("闪光灯") >= 0:
		return {"type": "flashlight", "on": not (t.find("关") >= 0)}
	re.compile("(?:帮我搜索一下|帮我搜一下|帮我查一下|搜索一下|搜一下|百度一下|查一下|帮我搜索|帮我搜|帮我查|搜索|搜搜|百度|谷歌|查查)\\s*[:：]?\\s*(.{1,40})")
	m = re.search(t)
	if m:
		return {"type": "web_search", "query": m.get_string(1).strip_edges()}
	re.compile("(?:导航到|导航去|带我去|怎么去|地图上找|在地图上看)\\s*(.{1,30})")
	m = re.search(t)
	if m:
		return {"type": "map", "query": m.get_string(1).strip_edges()}
	re.compile("(?:打电话给|拨打|打给|拨号)\\s*([0-9+\\- ]{3,20})")
	m = re.search(t)
	if m:
		return {"type": "dial", "number": m.get_string(1).replace(" ", "")}
	re.compile("(\\d{1,3})\\s*(分钟|分|秒钟|秒|小时)")
	if t.find("计时") >= 0 or t.find("倒计时") >= 0 or t.find("定时") >= 0:
		m = re.search(t)
		if m:
			var n := int(m.get_string(1))
			var u := m.get_string(2)
			var secs := n * 60
			if u.begins_with("秒"):
				secs = n
			elif u == "小时":
				secs = n * 3600
			return {"type": "timer", "seconds": clampi(secs, 1, 86400), "label": "灵伴计时"}
	if t.find("闹钟") >= 0 or t.find("叫我起床") >= 0 or t.find("叫醒我") >= 0:
		re.compile("(\\d{1,2})\\s*[点:：时]\\s*(\\d{1,2}|半)?")
		m = re.search(t)
		if m:
			var hh := int(m.get_string(1))
			var mmv := 0
			if m.get_string(2) == "半":
				mmv = 30
			elif m.get_string(2) != "":
				mmv = int(m.get_string(2))
			if (t.find("下午") >= 0 or t.find("晚上") >= 0) and hh < 12:
				hh += 12
			return {"type": "alarm", "hour": clampi(hh, 0, 23), "minute": clampi(mmv, 0, 59), "label": "灵伴闹钟"}
	if t.find("音量") >= 0 or t.find("声音大") >= 0 or t.find("声音小") >= 0 or t.find("静音") >= 0:
		if t.find("静音") >= 0:
			return {"type": "volume", "dir": "mute"}
		if t.find("大") >= 0 or t.find("高") >= 0 or t.find("调高") >= 0:
			return {"type": "volume", "dir": "up"}
		if t.find("小") >= 0 or t.find("低") >= 0:
			return {"type": "volume", "dir": "down"}
	if t.find("拍照") >= 0 or t.find("拍张照") >= 0:
		return {"type": "camera"}
	re.compile("^复制\\s*[:：]?\\s*(.{1,200})")
	m = re.search(t)
	if m:
		return {"type": "copy", "text": m.get_string(1)}
	return null

func offline_reply(comp: Dictionary, text: String, only_cmd := false) -> Dictionary:
	var s: Dictionary = comp.spec
	var st: Dictionary = comp.state
	var arch := SP.archetype(s)
	var t := text.strip_edges().to_lower()
	var r := {"say": "", "emotion": "neutral", "gesture": "none", "action": null, "remember": "", "affection": 0}
	var cmd = parse_command(text)
	if cmd != null:
		r.action = cmd
		r.say = {"tsundere": "哼，真拿你没办法，帮你弄好啦。", "cool": "好。", "shy": "好、好的，我来试试……", "lazy": "唔……好吧，帮你弄。", "genki": "交给我吧！", "playful": "嘿嘿，看我的！", "wise": "好，这就办。"}.get(arch, "好的，交给我吧！")
		r.emotion = "happy"
		r.gesture = "nod"
		return r
	if only_cmd:
		return r
	var has := func(words: Array) -> bool:
		for w in words:
			if t.find(w) >= 0:
				return true
		return false
	var name: String = s.name
	# 猜谜进行中
	var ans := String(st.get("riddle", ""))
	if ans != "" and (t.length() <= 10 or t.find("猜") >= 0 or t.find("答案") >= 0 or t.find(ans) >= 0):
		st.riddle = ""
		if t.find(ans) >= 0:
			r.say = "答对啦！你好聪明！"
			r.emotion = "excited"
			r.gesture = "clap"
			r.affection = 1
			r["riddle_done"] = true
		else:
			r.say = "嘿嘿，答案是“%s”！下次加油哦。" % ans
			r.emotion = "smug"
			r["riddle_done"] = true
		return r
	if ans != "":
		st.riddle = ""
	if has.call(["谜语", "猜谜", "脑筋急转弯"]):
		var rd: Array = SP.RIDDLES[rng.randi() % SP.RIDDLES.size()]
		st.riddle = rd[1]
		r.say = "听好了：" + rd[0]
		r.emotion = "smug"
		r.gesture = "think"
	elif has.call(["笑话", "逗我", "讲个段子", "搞笑"]):
		r.say = SP.JOKES[rng.randi() % SP.JOKES.size()]
		r.emotion = "excited"
		r.gesture = "clap"
	elif has.call(["你好", "嗨", "hello", "hi", "在吗", "早上好", "早安", "晚上好", "哈喽"]):
		r.say = SP.line_from(s, "greet", rng)
		r.emotion = "happy"
		r.gesture = "wave"
	elif has.call(["你叫什么", "你是谁", "你的名字", "叫什么名字"]):
		r.say = "我是%s呀，%s。" % [name, s.label]
		r.emotion = "happy"
		r.gesture = "bow"
	elif has.call(["几点", "时间", "日期", "星期几", "今天几号"]):
		r.say = "现在是%s。" % time_ctx().text
		r.emotion = "thinking"
	elif has.call(["谢谢", "感谢", "thank", "多谢"]):
		r.say = {"tsundere": "哼、谁要你谢啊……不客气啦。", "cool": "嗯。", "shy": "不、不用谢……", "genki": "不客气！随时找我！", "playful": "那你要请我吃好吃的！"}.get(arch, "不客气呀~")
		r.emotion = "shy" if arch in ["tsundere", "shy"] else "happy"
		r.affection = 1
	elif has.call(["喜欢你", "爱你", "最喜欢", "想你"]):
		r.say = {"tsundere": "笨、笨蛋！突然说什么呢……我也不讨厌你啦。", "cool": "……知道了。", "shy": "我、我也……喜欢你。", "genki": "我也超级喜欢你！"}.get(arch, "嘿嘿，我也是！")
		r.emotion = "shy" if arch in ["tsundere", "shy", "cool"] else "love"
		r.gesture = "hug" if arch in ["genki", "gentle", "playful"] else "none"
		r.affection = 2
	elif has.call(["难过", "伤心", "不开心", "好累", "累了", "烦", "哭", "压力", "郁闷", "失眠"]):
		r.say = {"tsundere": "……喂，别一个人憋着。说出来，我听着呢。", "cool": "我在。想说就说。", "genki": "抱抱！不开心的事说出来就会好一点！", "lazy": "那就先躺一会儿吧，我陪你。", "wise": "累了就停一停。想聊聊发生了什么吗？"}.get(arch, "抱抱你。发生什么事了？我在这里听你说。")
		r.emotion = "sad"
		r.gesture = "hug"
		r.affection = 1
	elif has.call(["无聊", "没意思", "好闲"]):
		r.say = "那我们来玩猜谜吧！说“猜谜”就开始。或者让我讲个笑话？"
		r.emotion = "excited"
		r.gesture = "jump"
	elif has.call(["你会什么", "能做什么", "功能", "帮助", "help", "怎么用"]):
		r.say = "我可以陪你聊天、讲笑话、猜谜，还能帮你打开应用、搜索、定闹钟、开手电筒。摸摸我的头试试？去设置里填上 AI 的 Key，我会变得更聪明哦。"
		r.emotion = "happy"
		r.gesture = "point"
	elif has.call(["再见", "拜拜", "晚安", "bye", "走了", "睡了"]):
		r.say = "晚安，做个好梦。" if t.find("晚安") >= 0 or t.find("睡") >= 0 else SP.line_from(s, "bye", rng)
		r.emotion = "sleepy" if t.find("晚安") >= 0 else "happy"
		r.gesture = "wave"
	elif has.call(["可爱", "真棒", "厉害", "聪明", "好看", "漂亮", "帅"]):
		r.say = {"tsundere": "哼，这、这种事我早就知道了！", "cool": "……还行。", "shy": "诶？真、真的吗……", "playful": "那当然，我可是最棒的！", "genki": "嘿嘿！被夸了好开心！"}.get(arch, "嘿嘿，被你夸了~")
		r.emotion = "smug" if arch in ["playful", "tsundere"] else "shy"
		r.gesture = "spin" if arch == "genki" else "none"
		r.affection = 1
	elif has.call(["笨", "傻", "讨厌你", "丑", "滚", "闭嘴"]):
		r.say = {"tsundere": "你才笨！哼！不理你了！", "cool": "随你怎么说。", "shy": "呜……对不起……", "genki": "哼！我生气了！三秒钟！", "lazy": "……好吧，随你。"}.get(arch, "呜……你这么说我会难过的。")
		r.emotion = "angry" if arch in ["tsundere", "genki"] else "sad"
		r.gesture = "pout" if arch == "tsundere" else "none"
		r.affection = -1
	elif has.call(["跳舞", "跳个舞", "dance"]):
		r.say = "看好啦！"
		r.emotion = "excited"
		r.gesture = "dance"
	elif has.call(["转圈", "转一圈"]):
		r.say = "转圈圈~"
		r.emotion = "happy"
		r.gesture = "spin"
	else:
		var fall := {"tsundere": ["哼，然后呢？", "这种事……也不是不能听你说。", "嗯？你继续说。"], "cool": ["嗯。", "然后？", "我在听。"],
			"shy": ["嗯、嗯……", "原来是这样……", "我、我在听哦。"], "genki": ["哇，真的吗！然后呢然后呢？", "好有意思！", "嗯嗯！再多说点！"],
			"playful": ["嘿嘿，有意思~", "你猜我在想什么？", "然后呢？快说快说！"], "lazy": ["嗯……", "这样啊……", "好的……（打哈欠）"],
			"wise": ["原来如此。", "嗯，说下去。", "这件事你怎么看？"], "gentle": ["嗯嗯，我在听呢。", "原来是这样呀。", "你愿意多跟我说说吗？"]}
		var arr: Array = fall.get(arch, fall.gentle)
		r.say = SP._suffix(s, String(arr[rng.randi() % arr.size()]), rng)
		r.emotion = "thinking" if rng.randf() < 0.3 else "happy"
		if int(st.get("msgs", 0)) % 6 == 2 and not llm.has_chat():
			r.say += "（我现在是离线模式，只能简单聊天。去设置里填上 AI 的 Key，我就能真正听懂你啦。）"
	r.say = SP._suffix(s, r.say, rng)
	return r
