extends RefCounted
# 灵伴：本地存储。设置、伙伴、聊天记录、任务全部只保存在这台设备上。
# API Key 单独加密保存（keys.dat），不会写进任何导出文件或分享码。

const SP = preload("res://scripts/species.gd")
var DIR := "user://lingban"

var settings: Dictionary = {}
var keys: Dictionary = {}
var companions: Array = []
var current_id := ""
var chats: Dictionary = {}
var stats: Dictionary = {}
var tasks: Dictionary = {}

static func default_settings() -> Dictionary:
	return {
		"chat": {"preset": "deepseek", "base": "https://api.deepseek.com", "model": "deepseek-flash", "json": true, "temp": 0.9},
		"tts": {"mode": "system", "base": "https://api.siliconflow.cn/v1", "model": "FunAudioLLM/CosyVoice2-0.5B", "voice": "", "same_key": false, "sys_voice": "", "volume": 80},
		"stt": {"mode": "ime", "base": "https://api.siliconflow.cn/v1", "model": "FunAudioLLM/SenseVoiceSmall", "same_key": false},
		"img": {"base": "https://api.siliconflow.cn/v1", "model": "Kwai-Kolors/Kolors", "same_key": false},
		"behavior": {"proactive_min": 8, "proactive_ai": true, "ai_per_hour": 3, "roam": true, "reply_len": "short", "touch_voice": true, "search": "bing", "vad": 0.5, "sleep_min": 20, "ui_mode": "auto"},
		"perms": {"open_app": "ask", "web": "ask", "phone": "ask", "clock": "ask", "flashlight": "ask", "volume": "ask", "settings": "ask", "camera": "ask", "share": "ask"},
		"price": {"in": 0.0, "out": 0.0},
		"overlay": {"size": 150, "wander": true},
		"seen_intro": false,
	}

static func new_state() -> Dictionary:
	var now := int(Time.get_unix_time_from_system())
	return {"affection": 25, "mood": "happy", "memory": [], "last_seen": now, "created": now, "pets_day": "", "pets_today": 0,
		"spam_today": 0, "msgs": 0, "portrait": "", "look": "drawn", "riddle": "", "last_greet_day": "", "chat_tokens": 0}

func _p(name: String) -> String:
	return DIR + "/" + name

func _read_json(path: String, dflt):
	if not FileAccess.file_exists(path):
		return dflt
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return dflt
	var txt := f.get_as_text()
	f.close()
	var j = JSON.parse_string(txt)
	return j if j != null else dflt

func _write_json(path: String, data) -> void:
	DirAccess.make_dir_recursive_absolute(path.get_base_dir())
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(data, "", false))
	f.close()
	DirAccess.rename_absolute(tmp, path)

static func _merge(dst: Dictionary, src: Dictionary) -> Dictionary:
	for k in src:
		if dst.has(k) and typeof(dst[k]) == TYPE_DICTIONARY and typeof(src[k]) == TYPE_DICTIONARY:
			_merge(dst[k], src[k])
		else:
			dst[k] = src[k]
	return dst

func _key_pass() -> String:
	var uid := OS.get_unique_id()
	if uid == "":
		uid = "lingban-local"
	return "lb:" + uid.sha256_text().left(24)

func load_all() -> void:
	DirAccess.make_dir_recursive_absolute(DIR + "/chats")
	settings = _merge(default_settings(), _read_json(_p("settings.json"), {}))
	var cdata = _read_json(_p("companions.json"), {})
	companions = []
	if typeof(cdata) == TYPE_DICTIONARY:
		for c in cdata.get("list", []):
			if typeof(c) == TYPE_DICTIONARY and c.has("spec"):
				c.spec = SP.normalize(c.spec)
				c.state = _merge(new_state(), c.get("state", {}))
				companions.append(c)
		current_id = String(cdata.get("current", ""))
	if current() == null and not companions.is_empty():
		current_id = companions[0].id
	stats = _merge({"prompt": 0, "completion": 0, "requests": 0, "since": Time.get_date_string_from_system()}, _read_json(_p("stats.json"), {}))
	tasks = _read_json(_p("tasks.json"), {})
	if typeof(tasks) != TYPE_DICTIONARY:
		tasks = {}
	keys = {}
	if FileAccess.file_exists(_p("keys.dat")):
		var f := FileAccess.open_encrypted_with_pass(_p("keys.dat"), FileAccess.READ, _key_pass())
		if f != null:
			var j = JSON.parse_string(f.get_as_text())
			f.close()
			if typeof(j) == TYPE_DICTIONARY:
				keys = j

func save_settings() -> void:
	_write_json(_p("settings.json"), settings)

func save_keys() -> void:
	DirAccess.make_dir_recursive_absolute(DIR)
	var f := FileAccess.open_encrypted_with_pass(_p("keys.dat"), FileAccess.WRITE, _key_pass())
	if f != null:
		f.store_string(JSON.stringify(keys))
		f.close()

func save_companions() -> void:
	_write_json(_p("companions.json"), {"current": current_id, "list": companions})

func save_stats() -> void:
	_write_json(_p("stats.json"), stats)

func save_tasks() -> void:
	_write_json(_p("tasks.json"), tasks)

func key(which: String) -> String:
	var k := String(keys.get(which, "")).strip_edges()
	if k == "" and which != "chat":
		var sec: Dictionary = settings.get(which, {})
		if bool(sec.get("same_key", false)):
			return String(keys.get("chat", "")).strip_edges()
	return k

func set_key(which: String, v: String) -> void:
	keys[which] = v.strip_edges()
	save_keys()

# ---------------------------------------------------------------- 伙伴
func current():
	for c in companions:
		if c.id == current_id:
			return c
	return null

func add_companion(spec: Dictionary) -> Dictionary:
	var id := "c%d%04d" % [int(Time.get_unix_time_from_system()), randi() % 10000]
	var c := {"id": id, "spec": SP.normalize(spec), "state": new_state()}
	companions.append(c)
	current_id = id
	chats[id] = []
	save_companions()
	return c

func delete_companion(id: String) -> void:
	for i in companions.size():
		if companions[i].id == id:
			companions.remove_at(i)
			break
	chats.erase(id)
	if FileAccess.file_exists(_p("chats/%s.json" % id)):
		DirAccess.remove_absolute(_p("chats/%s.json" % id))
	if current_id == id:
		current_id = companions[0].id if not companions.is_empty() else ""
	save_companions()

func chat_of(id: String) -> Array:
	if not chats.has(id):
		var arr = _read_json(_p("chats/%s.json" % id), [])
		chats[id] = arr if typeof(arr) == TYPE_ARRAY else []
	return chats[id]

func save_chat(id: String) -> void:
	var arr: Array = chat_of(id)
	if arr.size() > 400:
		arr = arr.slice(arr.size() - 400)
		chats[id] = arr
	_write_json(_p("chats/%s.json" % id), arr)

func clear_chat(id: String) -> void:
	chats[id] = []
	save_chat(id)

# ---------------------------------------------------------------- 分享码（只含外形和性格，不含聊天和 Key）
static func share_code(spec: Dictionary) -> String:
	var j := JSON.stringify(spec)
	var raw := j.to_utf8_buffer()
	var z := raw.compress(FileAccess.COMPRESSION_GZIP)
	return "LB1:%d:%s" % [raw.size(), Marshalls.raw_to_base64(z)]

static func parse_share_code(code: String):
	var s := code.strip_edges()
	var i := s.find("LB1:")
	if i < 0:
		return null
	s = s.substr(i + 4)
	var parts := s.split(":", false, 1)
	if parts.size() < 2:
		return null
	var sz := int(parts[0])
	var b64 := parts[1].strip_edges().split("\n")[0].split(" ")[0]
	var z := Marshalls.base64_to_raw(b64)
	if z.is_empty() or sz <= 0 or sz > 200000:
		return null
	var raw := z.decompress(sz, FileAccess.COMPRESSION_GZIP)
	var j = JSON.parse_string(raw.get_string_from_utf8())
	if typeof(j) != TYPE_DICTIONARY:
		return null
	return SP.normalize(j)
