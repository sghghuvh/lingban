extends Node
# 灵伴：AI 接口客户端（OpenAI 兼容格式）。
# 聊天 /chat/completions，语音识别 /audio/transcriptions，语音合成 /audio/speech，画像 /images/generations。
# Key 由用户自己填写，token 费用用户自己承担。

signal usage_changed

const PRESETS := {
	"deepseek": {"name": "DeepSeek", "base": "https://api.deepseek.com", "models": ["deepseek-flash", "deepseek-v4-pro", "deepseek-chat"]},
	"siliconflow": {"name": "硅基流动 SiliconFlow", "base": "https://api.siliconflow.cn/v1", "models": ["deepseek-ai/DeepSeek-V3", "Qwen/Qwen2.5-72B-Instruct", "Qwen/Qwen2.5-7B-Instruct"]},
	"openai": {"name": "OpenAI", "base": "https://api.openai.com/v1", "models": ["gpt-4o-mini", "gpt-4.1-mini"]},
	"moonshot": {"name": "Kimi 月之暗面", "base": "https://api.moonshot.cn/v1", "models": ["moonshot-v1-8k"]},
	"dashscope": {"name": "通义千问", "base": "https://dashscope.aliyuncs.com/compatible-mode/v1", "models": ["qwen-plus", "qwen-turbo"]},
	"custom": {"name": "自定义（OpenAI 兼容）", "base": "", "models": []},
}
const PRESET_ORDER := ["deepseek", "siliconflow", "openai", "moonshot", "dashscope", "custom"]

var store

func setup(s) -> void:
	store = s

func has_chat() -> bool:
	return store != null and store.key("chat") != "" and String(store.settings.chat.get("base", "")).strip_edges() != ""

func has_stt() -> bool:
	return store != null and store.settings.stt.get("mode", "ime") == "api" and store.key("stt") != ""

func has_tts_api() -> bool:
	return store != null and store.settings.tts.get("mode", "system") == "api" and store.key("tts") != ""

func has_img() -> bool:
	return store != null and store.key("img") != ""

static func join_url(base: String, path: String) -> String:
	var b := base.strip_edges()
	while b.ends_with("/"):
		b = b.left(b.length() - 1)
	if b.ends_with(path):
		return b
	return b + path

static func err_text(code: int, body: String) -> String:
	var msg := ""
	var j = JSON.parse_string(body) if body != "" else null
	if typeof(j) == TYPE_DICTIONARY:
		var e = j.get("error", j.get("message", ""))
		if typeof(e) == TYPE_DICTIONARY:
			msg = String(e.get("message", ""))
		else:
			msg = String(e)
	match code:
		0:
			return "网络连接失败，请检查网络"
		400:
			return "请求格式有误（400）" + ("：" + msg.left(60) if msg != "" else "")
		401, 403:
			return "API Key 无效或没有权限（%d）" % code
		402:
			return "账户余额不足（402）"
		404:
			return "接口地址或模型名不对（404）"
		429:
			return "请求太频繁或额度用完了（429）"
	if code >= 500:
		return "AI 服务器出错了（%d），稍后再试" % code
	return "请求失败（%d）%s" % [code, ("：" + msg.left(60)) if msg != "" else ""]

func _req(url: String, headers: PackedStringArray, method: int, body, timeout: float, cb: Callable, raw := false) -> void:
	var h := HTTPRequest.new()
	h.timeout = timeout
	h.use_threads = true
	add_child(h)
	h.request_completed.connect(func(result: int, code: int, _hd: PackedStringArray, data: PackedByteArray):
		h.queue_free()
		if result != HTTPRequest.RESULT_SUCCESS:
			var why := "网络连接失败，请检查网络"
			if result == HTTPRequest.RESULT_TIMEOUT:
				why = "请求超时，网络慢或服务器忙"
			elif result in [HTTPRequest.RESULT_CANT_RESOLVE, HTTPRequest.RESULT_CANT_CONNECT]:
				why = "连不上服务器，检查网络或接口地址"
			elif result == HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR:
				why = "安全连接失败（TLS）"
			cb.call(false, PackedByteArray(), why, 0)
			return
		if code < 200 or code >= 300:
			cb.call(false, data, err_text(code, data.get_string_from_utf8()), code)
			return
		cb.call(true, data, "", code))
	var err := OK
	if raw:
		err = h.request_raw(url, headers, method, body)
	else:
		err = h.request(url, headers, method, String(body))
	if err != OK:
		h.queue_free()
		cb.call(false, PackedByteArray(), "无法发起请求（地址格式不对？）", 0)

# 聊天：cb.call(ok: bool, content: String, err: String)
func chat(messages: Array, cb: Callable, opts := {}) -> void:
	if not has_chat():
		cb.call(false, "", "还没有设置 AI 的 API Key")
		return
	var cs: Dictionary = store.settings.chat
	var model := String(opts.get("model", cs.get("model", ""))).strip_edges()
	if model == "":
		cb.call(false, "", "还没有填写模型名")
		return
	var body := {"model": model, "messages": messages, "temperature": float(opts.get("temp", cs.get("temp", 0.9))), "max_tokens": int(opts.get("max_tokens", 2000)), "stream": false}
	if bool(opts.get("json", cs.get("json", true))):
		body["response_format"] = {"type": "json_object"}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + store.key("chat")])
	var url := join_url(String(cs.base), "/chat/completions")
	_req(url, headers, HTTPClient.METHOD_POST, JSON.stringify(body), float(opts.get("timeout", 60.0)), func(ok: bool, data: PackedByteArray, err: String, code: int):
		if not ok:
			# 有的服务商不支持 JSON 模式：自动关掉再试一次
			if code == 400 and body.has("response_format") and not opts.get("_retry", false):
				var o2: Dictionary = opts.duplicate()
				o2["json"] = false
				o2["_retry"] = true
				chat(messages, cb, o2)
				return
			cb.call(false, "", err)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		if typeof(j) != TYPE_DICTIONARY:
			cb.call(false, "", "AI 返回的内容看不懂")
			return
		var u = j.get("usage", {})
		if typeof(u) == TYPE_DICTIONARY:
			store.stats.prompt = int(store.stats.get("prompt", 0)) + int(u.get("prompt_tokens", 0))
			store.stats.completion = int(store.stats.get("completion", 0)) + int(u.get("completion_tokens", 0))
		store.stats.requests = int(store.stats.get("requests", 0)) + 1
		store.save_stats()
		usage_changed.emit()
		var content := ""
		var ch = j.get("choices", [])
		if typeof(ch) == TYPE_ARRAY and not ch.is_empty():
			var m = ch[0].get("message", {})
			if typeof(m) == TYPE_DICTIONARY:
				content = String(m.get("content", ""))
		if content == "":
			cb.call(false, "", "AI 没有返回内容")
			return
		cb.call(true, content, ""))

# 语音识别：cb.call(ok, text, err)
func transcribe(wav: PackedByteArray, cb: Callable) -> void:
	var ss: Dictionary = store.settings.stt
	var k: String = store.key("stt")
	if k == "":
		cb.call(false, "", "还没有设置语音识别的 API Key")
		return
	var boundary := "----LingBan%d" % (randi() % 1000000000)
	var body := PackedByteArray()
	var head := "--%s\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\n%s\r\n" % [boundary, String(ss.model)]
	head += "--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voice.wav\"\r\nContent-Type: audio/wav\r\n\r\n" % boundary
	body.append_array(head.to_utf8_buffer())
	body.append_array(wav)
	body.append_array(("\r\n--%s--\r\n" % boundary).to_utf8_buffer())
	var headers := PackedStringArray(["Content-Type: multipart/form-data; boundary=" + boundary, "Authorization: Bearer " + k])
	_req(join_url(String(ss.base), "/audio/transcriptions"), headers, HTTPClient.METHOD_POST, body, 40.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		if not ok:
			cb.call(false, "", err)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var txt := String(j.get("text", "")) if typeof(j) == TYPE_DICTIONARY else ""
		cb.call(true, txt.strip_edges(), ""), true)

# 语音合成：cb.call(ok, mp3_bytes, err)
func speech(text: String, voice: String, speed: float, cb: Callable) -> void:
	var ts: Dictionary = store.settings.tts
	var k: String = store.key("tts")
	if k == "":
		cb.call(false, PackedByteArray(), "还没有设置语音合成的 API Key")
		return
	if is_dashscope_tts(ts):
		_speech_dashscope(text, voice, k, cb)
		return
	var body := {"model": String(ts.model), "input": text, "voice": voice, "response_format": "mp3", "speed": clampf(speed, 0.5, 2.0)}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + k])
	_req(join_url(String(ts.base), "/audio/speech"), headers, HTTPClient.METHOD_POST, JSON.stringify(body), 40.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		cb.call(ok, data, err))

static func is_dashscope_tts(ts: Dictionary) -> bool:
	var m := String(ts.get("model", ""))
	return String(ts.get("base", "")).find("aliyuncs.com") >= 0 or m.begins_with("qwen") or m.begins_with("cosyvoice")

# 实际使用的阿里云模型：专属域名（maas.aliyuncs.com）上只有 CosyVoice，旧设置里的 qwen3-tts 自动换成 CosyVoice
static func ds_model(ts: Dictionary) -> String:
	var m := String(ts.get("model", "")).strip_edges()
	if m == "" or m.find("/") >= 0:
		m = "cosyvoice-v3-flash"
	if m.begins_with("qwen") and String(ts.get("base", "")).find("maas.aliyuncs.com") >= 0:
		m = "cosyvoice-v3-flash"
	return m

# 阿里云百炼语音：先拿到音频地址，再下载 WAV。CosyVoice 走 SpeechSynthesizer，Qwen3-TTS 走 multimodal-generation
func _speech_dashscope(text: String, voice: String, key: String, cb: Callable) -> void:
	var ts: Dictionary = store.settings.tts
	var model := ds_model(ts)
	var body: Dictionary
	var path := ""
	if model.begins_with("cosyvoice"):
		path = "/services/audio/tts/SpeechSynthesizer"
		body = {"model": model, "input": {"text": text.left(500), "voice": voice, "format": "wav", "sample_rate": 24000}}
	else:
		path = "/services/aigc/multimodal-generation/generation"
		body = {"model": model, "input": {"text": text.left(580), "voice": voice, "language_type": "Auto"}}
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + key])
	var url := join_url(String(ts.base), path)
	_req(url, headers, HTTPClient.METHOD_POST, JSON.stringify(body), 40.0, func(ok: bool, data: PackedByteArray, err: String, _code: int):
		if not ok:
			var raw := data.get_string_from_utf8().strip_edges().replace("\n", " ").left(140)
			cb.call(false, PackedByteArray(), err + ("｜" + raw if raw != "" else ""))
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		var au := ""
		if typeof(j) == TYPE_DICTIONARY and typeof(j.get("output")) == TYPE_DICTIONARY and typeof(j.output.get("audio")) == TYPE_DICTIONARY:
			au = String(j.output.audio.get("url", ""))
		if au == "":
			cb.call(false, PackedByteArray(), "阿里云没有返回声音｜" + data.get_string_from_utf8().strip_edges().left(140))
			return
		_req(au if au.find("127.0.0.1") >= 0 else au.replace("http://", "https://"), PackedStringArray(), HTTPClient.METHOD_GET, "", 40.0, func(ok2: bool, d2: PackedByteArray, e2: String, _c2: int):
			cb.call(ok2, d2, e2)))

# 画像：cb.call(ok, Image, err)。兼容 OpenAI（data[].url/b64_json）和硅基流动（images[].url）两种返回
func image(prompt: String, cb: Callable) -> void:
	var isec: Dictionary = store.settings.img
	var k: String = store.key("img")
	if k == "":
		cb.call(false, null, "还没有设置画像的 API Key")
		return
	var model := String(isec.model)
	var body := {"model": model, "prompt": prompt}
	if String(isec.base).find("siliconflow") >= 0:
		body["image_size"] = "1024x1024"
		body["batch_size"] = 1
	else:
		body["size"] = "1024x1024"
		body["n"] = 1
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + k])
	_req(join_url(String(isec.base), "/images/generations"), headers, HTTPClient.METHOD_POST, JSON.stringify(body), 120.0, func(ok: bool, data: PackedByteArray, err: String, _c: int):
		if not ok:
			cb.call(false, null, err)
			return
		var j = JSON.parse_string(data.get_string_from_utf8())
		if typeof(j) != TYPE_DICTIONARY:
			cb.call(false, null, "画像接口返回看不懂")
			return
		var arr = j.get("images", j.get("data", []))
		if typeof(arr) != TYPE_ARRAY or arr.is_empty():
			cb.call(false, null, "没有生成图片")
			return
		var it = arr[0]
		if typeof(it) == TYPE_DICTIONARY and String(it.get("b64_json", "")) != "":
			cb.call(true, _img_from_bytes(Marshalls.base64_to_raw(String(it.b64_json))), "")
			return
		var url := String(it.get("url", "")) if typeof(it) == TYPE_DICTIONARY else ""
		if url == "":
			cb.call(false, null, "没有图片地址")
			return
		_req(url, PackedStringArray(), HTTPClient.METHOD_GET, "", 60.0, func(ok2: bool, d2: PackedByteArray, e2: String, _c2: int):
			if not ok2:
				cb.call(false, null, e2)
				return
			var img := _img_from_bytes(d2)
			cb.call(img != null, img, "" if img != null else "图片格式不支持")))

static func _img_from_bytes(b: PackedByteArray) -> Image:
	if b.is_empty():
		return null
	var img := Image.new()
	var e := ERR_FILE_UNRECOGNIZED
	if b.size() > 4 and b[0] == 0x89 and b[1] == 0x50:
		e = img.load_png_from_buffer(b)
	elif b.size() > 4 and b[0] == 0xFF and b[1] == 0xD8:
		e = img.load_jpg_from_buffer(b)
	elif b.size() > 12 and b[8] == 0x57 and b[9] == 0x45:
		e = img.load_webp_from_buffer(b)
	else:
		e = img.load_png_from_buffer(b)
		if e != OK:
			e = img.load_jpg_from_buffer(b)
	return img if e == OK else null

# 从模型回复中取出 JSON 对象（容忍 ```json 代码块和前后废话）
static func _quiet_parse(s: String):
	var jj := JSON.new()
	if jj.parse(s) == OK:
		return jj.data
	return null

static func extract_json(content: String):
	var s := content.strip_edges()
	var j = _quiet_parse(s) if s.begins_with("{") else null
	if typeof(j) == TYPE_DICTIONARY:
		return j
	var a := s.find("{")
	var b := s.rfind("}")
	if a >= 0 and b > a:
		j = _quiet_parse(s.substr(a, b - a + 1))
		if typeof(j) == TYPE_DICTIONARY:
			return j
	return null
