extends Node
# 灵伴：桌面悬浮。
# 做法：先把伙伴渲染成一组透明图片（各种表情、说话、眨眼、睡觉），写进应用私有目录，
# 再启动原生安卓悬浮服务（android_native/OverlayService.java），由它在桌面上显示、走动、聊天。
# 原生服务只在用 GitHub 云端编译的“悬浮版”APK 里才有；普通版 APK 里调用会失败，界面会提示。

const SP = preload("res://scripts/species.gd")
const CR = preload("res://scripts/creature.gd")
const SERVICE := "com.godot.game.overlay.OverlayService"

var app
var busy := false
var last_error := ""
var test_dir := ""   # 测试时指定输出目录

func setup(a) -> void:
	app = a

func is_android() -> bool:
	return OS.get_name() == "Android" and Engine.has_singleton("AndroidRuntime")

func _act():
	if not Engine.has_singleton("AndroidRuntime"):
		return null
	return Engine.get_singleton("AndroidRuntime").getActivity()

func has_native_service() -> bool:
	# 悬浮版 APK 的清单里会声明这个服务
	var act = _act()
	if act == null:
		return false
	var pm = act.getPackageManager()
	var CN = JavaClassWrapper.wrap("android.content.ComponentName")
	if pm == null or CN == null:
		return false
	var cn = CN.ComponentName(String(act.getPackageName()), SERVICE)
	var info = null
	# getServiceInfo 找不到会抛异常，Godot 里表现为返回 null
	info = pm.getServiceInfo(cn, 0)
	return info != null

func can_draw() -> bool:
	var act = _act()
	var St = JavaClassWrapper.wrap("android.provider.Settings")
	if act == null or St == null:
		return false
	return bool(St.canDrawOverlays(act))

func ask_permission() -> void:
	var act = _act()
	if act == null:
		return
	app.device._intent_uri("intent:package:%s#Intent;action=android.settings.action.MANAGE_OVERLAY_PERMISSION;end" % String(act.getPackageName()))

# ------------------------------------------------------------------ 渲染图片
func _wait(s: float) -> void:
	await get_tree().create_timer(s).timeout

func render_frames(comp: Dictionary, dir: String) -> Dictionary:
	DirAccess.make_dir_recursive_absolute(dir)
	var vp := SubViewport.new()
	vp.size = Vector2i(400, 460)
	vp.transparent_bg = true
	vp.disable_3d = true
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	var c = CR.new()
	c.font = app.font
	c.set_spec(comp.spec)
	c.wander = false
	c.x_min = -9999.0
	c.x_max = 9999.0
	c.position = Vector2(200, 420)
	c.home_y = 420.0
	vp.add_child(c)
	c._blink_t = 999.0
	await _wait(0.6)
	var imgs := {}
	for emo in SP.EMOTIONS:
		c.paused = false
		c.sleeping = false
		c.react(emo, "none", 99.0)
		await _wait(0.55)
		c.paused = true
		c.blink = 0.0
		c.talk = 0.0
		c.queue_redraw()
		await RenderingServer.frame_post_draw
		imgs["e_" + emo] = _grab(vp)
		c.talk = 1.0
		c.queue_redraw()
		await RenderingServer.frame_post_draw
		imgs["t_" + emo] = _grab(vp)
		if emo == "neutral":
			c.talk = 0.0
			c.blink = 1.0
			c.queue_redraw()
			await RenderingServer.frame_post_draw
			imgs["blink"] = _grab(vp)
	c.paused = false
	c.react("sleepy", "none", 99.0)
	c.go_sleep()
	await _wait(1.0)
	c.paused = true
	c.queue_redraw()
	await RenderingServer.frame_post_draw
	imgs["sleep"] = _grab(vp)
	vp.queue_free()
	# 所有帧用同一个裁剪框，保证切换表情时不跳动
	var rect := Rect2i()
	var first := true
	for k in ["e_neutral", "t_neutral", "blink", "e_sad", "e_surprised"]:
		var r: Rect2i = imgs[k].get_used_rect()
		if r.size.x <= 0:
			continue
		rect = r if first else rect.merge(r)
		first = false
	rect = rect.grow(14).intersection(Rect2i(0, 0, 400, 460))
	var frames := {}
	for k in imgs:
		var im: Image = imgs[k].get_region(rect)
		var fn := "%s.png" % k
		im.save_png(dir.path_join(fn))
		frames[k] = fn
	return {"frames": frames, "w": rect.size.x, "h": rect.size.y}

func _grab(vp: SubViewport) -> Image:
	var im := vp.get_texture().get_image()
	im.convert(Image.FORMAT_RGBA8)
	return im

# ------------------------------------------------------------------ 配置
func build_config(comp: Dictionary, info: Dictionary) -> Dictionary:
	var S: Dictionary = app.store.settings
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var idle: Array = []
	for i in 14:
		var ln := String(SP.line_from(comp.spec, "idle", rng))
		if ln != "" and not idle.has(ln):
			idle.append(ln)
	for d in ["嗯？", "你在忙吗？", "我在这儿呢。", "要不要休息一下？", "点我一下就能聊天哦。"]:
		if idle.size() < 6 and not idle.has(d):
			idle.append(d)
	var greet := String(SP.line_from(comp.spec, "greet", rng))
	var touch: Array = []
	for z in ["head", "head", "body", "body", "tail"]:
		var t: Array = SP.touch_line(comp.spec, z, rng)
		touch.append([String(t[0]), String(t[1])])
	var extra := "\n【当前场景】你现在以小窗形式浮在用户的桌面上，用户点你才会聊天。这里不能执行手机操作，action 一律填 null。回复要更短，一般一两句话。"
	var ov: Dictionary = S.get("overlay", {})
	return {
		"name": String(comp.spec.name),
		"frames": info.frames,
		"fw": info.w, "fh": info.h,
		"size_dp": int(ov.get("size", 150)),
		"wander": bool(ov.get("wander", true)),
		"base": String(S.chat.base),
		"model": String(S.chat.model),
		"key": app.store.key("chat"),
		"temp": float(S.chat.get("temp", 0.9)),
		"json": bool(S.chat.get("json", true)),
		"system": app.brain.system_prompt(comp) + extra,
		"idle_lines": idle,
		"greet": greet,
		"touch_lines": touch,
		"call_user": String(comp.spec.personality.get("call_user", "你")),
		"tts": _tts_cfg(comp),
	}

# 悬浮里说话用的声音设置（和灵伴里的语音设置保持一致）
func _tts_cfg(comp: Dictionary) -> Dictionary:
	var ts: Dictionary = app.store.settings.tts
	var vo: Dictionary = comp.spec.get("voice", {})
	var mode := String(ts.get("mode", "system"))
	var api_ok: bool = mode == "api" and app.llm.has_tts_api()
	var ds: bool = api_ok and app.llm.is_dashscope_tts(ts)
	return {
		"mode": "api" if api_ok else ("off" if mode == "off" else "system"),
		"dashscope": ds,
		"base": String(ts.get("base", "")),
		"model": app.llm.ds_model(ts) if ds else String(ts.get("model", "")),
		"key": app.store.key("tts") if api_ok else "",
		"voice": app.voice.api_voice_for(comp.spec) if api_ok else "",
		"rate": float(vo.get("rate", 1.0)),
		"pitch": float(vo.get("pitch", 1.0)),
		"volume": int(ts.get("volume", 80)),
	}

# ------------------------------------------------------------------ 启动 / 关闭
func start(comp: Dictionary) -> String:
	# 返回空字符串表示成功，否则是给用户看的原因
	if busy:
		return "正在准备中，请稍等"
	if not is_android() and test_dir == "":
		return "只有安卓上才能使用桌面悬浮"
	if test_dir == "":
		if not has_native_service():
			return "这个安装包里没有悬浮功能。请安装带“悬浮版”标记的灵伴（用 GitHub 云端编译的版本）"
		if not can_draw():
			ask_permission()
			return "请在打开的页面里允许“显示在其他应用上层”，然后回到灵伴再点一次开启"
	busy = true
	var dir := test_dir if test_dir != "" else OS.get_user_data_dir().path_join("overlay")
	var info: Dictionary = await render_frames(comp, dir)
	var cfg := build_config(comp, info)
	var f := FileAccess.open(dir.path_join("config.json"), FileAccess.WRITE)
	if f == null:
		busy = false
		return "写入悬浮配置失败"
	f.store_string(JSON.stringify(cfg))
	f.close()
	busy = false
	if test_dir != "":
		return ""
	var act = _act()
	var IntentC = JavaClassWrapper.wrap("android.content.Intent")
	if act == null or IntentC == null:
		return "启动悬浮失败"
	var it = IntentC.Intent()
	it.setClassName(String(act.getPackageName()), SERVICE)
	it.putExtra("dir", dir)
	app.device._on_ui(func(): act.startForegroundService(it))
	return ""

func stop() -> void:
	var act = _act()
	var IntentC = JavaClassWrapper.wrap("android.content.Intent")
	if act == null or IntentC == null:
		return
	var it = IntentC.Intent()
	it.setClassName(String(act.getPackageName()), SERVICE)
	app.device._on_ui(func(): act.stopService(it))
