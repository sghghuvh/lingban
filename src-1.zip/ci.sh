#!/bin/bash
set -x
set -e
cd "$(dirname "$0")"
export GODOT_VER=4.4.1
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH=$PWD/ks/debug.keystore
export GODOT_ANDROID_KEYSTORE_DEBUG_USER=androiddebugkey
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD=android
export ANDROID_HOME=${ANDROID_HOME:-$ANDROID_SDK_ROOT}
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses >/dev/null || true
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0" "ndk;23.2.8568313" "cmake;3.10.2.4988404"
echo "ANDROID_HOME=$ANDROID_HOME" >> $GITHUB_ENV

B=https://github.com/godotengine/godot-builds/releases/download/${GODOT_VER}-stable
curl -fsSL -o godot.zip $B/Godot_v${GODOT_VER}-stable_linux.x86_64.zip
curl -fsSL -o tpz.zip $B/Godot_v${GODOT_VER}-stable_export_templates.tpz
unzip -q godot.zip && mv Godot_v${GODOT_VER}-stable_linux.x86_64 /usr/local/bin/godot && chmod +x /usr/local/bin/godot
mkdir -p ~/.local/share/godot/export_templates/${GODOT_VER}.stable
unzip -q tpz.zip -d tpz && cp -r tpz/templates/* ~/.local/share/godot/export_templates/${GODOT_VER}.stable/
mkdir -p ~/.config/godot
cat > ~/.config/godot/editor_settings-4.4.tres <<EOT
[gd_resource type="EditorSettings" format=3]
[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
export/android/debug_keystore = "$GODOT_ANDROID_KEYSTORE_DEBUG_PATH"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOT

mkdir -p android/build
unzip -q ~/.local/share/godot/export_templates/${GODOT_VER}.stable/android_source.zip -d android/build
echo "${GODOT_VER}.stable" > android/.build_version
touch android/build/.gdignore
cp android_native/AndroidManifest.xml android/build/AndroidManifest.xml
mkdir -p android/build/src/com/godot/game/overlay
cp android_native/OverlayService.java android/build/src/com/godot/game/overlay/

mkdir -p out
godot --headless --export-debug "Android" out/LingBan.apk || true
if [ ! -s out/LingBan.apk ]; then echo GRADLE_FAILED; FALLBACK=1; fi
if [ -n "$FALLBACK" ]; then
mkdir -p out
godot --headless --export-debug "AndroidPlain" out/LingBan-plain.apk
test -s out/LingBan-plain.apk
fi