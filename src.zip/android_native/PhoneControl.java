package com.godot.game.overlay;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

/** 无障碍服务：只在用户在悬浮窗里下达“代操作”指令时，由 OverlayService 调用。 */
public class PhoneControl extends AccessibilityService {
    public static volatile PhoneControl inst;
    private final ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
    public int sw = 1080, sh = 1920;

    @Override
    protected void onServiceConnected() {
        inst = this;
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            sw = dm.widthPixels;
            sh = dm.heightPixels;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent i) {
        inst = null;
        return super.onUnbind(i);
    }

    public static boolean on() {
        return inst != null;
    }

    /** 读屏：返回带编号的可见元素列表，供 AI 选择。 */
    public synchronized String dump() {
        nodes.clear();
        StringBuilder sb = new StringBuilder();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            return "（读不到屏幕内容）";
        }
        sb.append("当前应用：").append(root.getPackageName()).append("\n");
        walk(root, sb, 0);
        return sb.toString();
    }

    private void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || nodes.size() >= 70 || depth > 30) {
            return;
        }
        if (n.isVisibleToUser()) {
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            String label = t != null && t.length() > 0 ? t.toString() : (d != null ? d.toString() : "");
            boolean act = n.isClickable() || n.isEditable() || n.isScrollable() || n.isCheckable();
            if (label.length() > 0 || act) {
                if (label.length() > 40) {
                    label = label.substring(0, 40);
                }
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                nodes.add(n);
                sb.append(nodes.size() - 1).append(": ");
                sb.append(label.isEmpty() ? "(无文字)" : label);
                if (n.isEditable()) {
                    sb.append(" [输入框]");
                } else if (n.isClickable()) {
                    sb.append(" [可点]");
                }
                if (n.isScrollable()) {
                    sb.append(" [可滚动]");
                }
                sb.append(" @").append(r.centerX()).append(",").append(r.centerY()).append("\n");
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            walk(n.getChild(i), sb, depth + 1);
        }
    }

    public synchronized String labelOf(int i) {
        if (i < 0 || i >= nodes.size()) {
            return "";
        }
        AccessibilityNodeInfo n = nodes.get(i);
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        return t != null ? t.toString() : (d != null ? d.toString() : "");
    }

    public synchronized boolean click(int i) {
        if (i < 0 || i >= nodes.size()) {
            return false;
        }
        AccessibilityNodeInfo n = nodes.get(i);
        AccessibilityNodeInfo p = n;
        for (int k = 0; k < 6 && p != null; k++) {
            if (p.isClickable() && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
            p = p.getParent();
        }
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        return tap(r.centerX(), r.centerY());
    }

    public synchronized boolean type(int i, String text) {
        AccessibilityNodeInfo n = null;
        if (i >= 0 && i < nodes.size()) {
            n = nodes.get(i);
        }
        if (n == null) {
            n = getRootInActiveWindow() != null ? getRootInActiveWindow().findFocus(AccessibilityNodeInfo.FOCUS_INPUT) : null;
        }
        if (n == null) {
            return false;
        }
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    public boolean tap(int x, int y) {
        Path p = new Path();
        p.moveTo(x, y);
        return gesture(p, 60);
    }

    public boolean swipe(String dir) {
        float cx = sw / 2f;
        float cy = sh / 2f;
        Path p = new Path();
        switch (dir) {
            case "上": // 内容向上滚（手指向上划）
                p.moveTo(cx, sh * 0.75f);
                p.lineTo(cx, sh * 0.25f);
                break;
            case "下":
                p.moveTo(cx, sh * 0.25f);
                p.lineTo(cx, sh * 0.75f);
                break;
            case "左":
                p.moveTo(sw * 0.8f, cy);
                p.lineTo(sw * 0.2f, cy);
                break;
            default:
                p.moveTo(sw * 0.2f, cy);
                p.lineTo(sw * 0.8f, cy);
        }
        return gesture(p, 350);
    }

    private boolean gesture(Path p, long dur) {
        try {
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p, 0, dur));
            return dispatchGesture(b.build(), null, null);
        } catch (Throwable e) {
            return false;
        }
    }

    public boolean back() {
        return performGlobalAction(GLOBAL_ACTION_BACK);
    }

    public boolean home() {
        return performGlobalAction(GLOBAL_ACTION_HOME);
    }

    public boolean recents() {
        return performGlobalAction(GLOBAL_ACTION_RECENTS);
    }

    /** 按应用名（或包含的字）打开应用。 */
    public String openApp(String name) {
        try {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
            String best = null;
            String bestLabel = "";
            for (ResolveInfo ri : l) {
                String lb = String.valueOf(ri.loadLabel(pm));
                if (lb.equals(name) || (best == null && (lb.contains(name) || name.contains(lb)) && lb.length() > 1)) {
                    best = ri.activityInfo.packageName;
                    bestLabel = lb;
                    if (lb.equals(name)) {
                        break;
                    }
                }
            }
            if (best == null) {
                return null;
            }
            Intent it = pm.getLaunchIntentForPackage(best);
            if (it == null) {
                return null;
            }
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(it);
            return bestLabel;
        } catch (Throwable e) {
            return null;
        }
    }
}
