package com.godot.game.overlay;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

// 透明小页面：只负责弹出系统的“录制/投射屏幕”授权框，把结果交给悬浮服务
public class ProjectionActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), 77);
        } catch (Throwable e) {
            OverlayService s = OverlayService.instance;
            if (s != null) {
                s.onProjectionDenied("无法弹出屏幕授权：" + e.getMessage());
            }
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        OverlayService s = OverlayService.instance;
        if (s != null) {
            if (res == RESULT_OK && data != null) {
                s.onProjection(res, data);
            } else {
                s.onProjectionDenied("你没有允许屏幕授权，所以我看不到屏幕。");
            }
        }
        finish();
    }
}
