package com.godot.game.overlay;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

// 桌宠物语：相册 / 文件选择器。
// Godot 在安卓上拿到的是 content:// 地址读不了，所以这里用系统选择器，
// 把选中的文件原样复制到 App 自己的目录（user://lingban/pick_out），
// 再写一个标记文件告诉 GDScript「选好了」。GDScript 轮询这个标记即可。
public class PickerActivity extends Activity {
    private static final int REQ = 7001;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            String type = getIntent() != null ? getIntent().getStringExtra("lb_type") : null;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            if ("file".equals(type)) i.setType("*/*");
            else if ("video".equals(type)) i.setType("video/*");
            else i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "选择"), REQ);
        } catch (Exception e) {
            finishMark(false, "", "");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ && res == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            String name = displayName(uri);
            String mime = "";
            try { mime = getContentResolver().getType(uri); } catch (Exception e) {}
            if (mime == null) mime = "";
            boolean ok;
            String kind;
            if (mime.startsWith("video/") || name.toLowerCase().endsWith(".mp4") || name.toLowerCase().endsWith(".mov")) {
                ok = saveVideoFrame(uri);
                kind = ok ? "image" : "video"; // 抽帧成功就当图片，失败就标记 video
            } else {
                ok = save(uri);
                kind = mime.isEmpty() ? "file" : mime;
            }
            finishMark(ok, name, kind);
        } else {
            finishMark(false, "", "");
        }
    }

    // 视频抽一帧，存成 JPEG，让 AI 能"看"视频内容
    private boolean saveVideoFrame(Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        FileOutputStream fo = null;
        try {
            r.setDataSource(this, uri);
            Bitmap bm = r.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (bm == null) bm = r.getFrameAtTime();
            if (bm == null) return false;
            File dir = new File(getFilesDir(), "lingban");
            dir.mkdirs();
            fo = new FileOutputStream(new File(dir, "pick_out"));
            bm.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (fo != null) fo.close(); } catch (Exception e) {}
            try { r.release(); } catch (Exception e) {}
        }
    }

    private String displayName(Uri uri) {
        try {
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                String n = "";
                if (idx >= 0 && c.moveToFirst()) n = c.getString(idx);
                c.close();
                if (n != null) return n;
            }
        } catch (Exception e) {}
        return "";
    }

    private boolean save(Uri uri) {
        InputStream in = null;
        FileOutputStream fo = null;
        try {
            File dir = new File(getFilesDir(), "lingban");
            dir.mkdirs();
            File out = new File(dir, "pick_out");
            in = getContentResolver().openInputStream(uri);
            fo = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                fo.write(buf, 0, n);
                total += n;
                if (total > 80L * 1024 * 1024) break; // 最多 80MB，防止超大视频
            }
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (fo != null) fo.close(); } catch (Exception e) {}
            try { if (in != null) in.close(); } catch (Exception e) {}
        }
    }

    private void finishMark(boolean ok, String name, String kind) {
        FileOutputStream fo = null;
        try {
            File dir = new File(getFilesDir(), "lingban");
            dir.mkdirs();
            File mark = new File(dir, "pick_ready");
            fo = new FileOutputStream(mark);
            fo.write(((ok ? "1" : "0") + "\n" + (name == null ? "" : name) + "\n" + (kind == null ? "" : kind)).getBytes("UTF-8"));
        } catch (Exception e) {
        } finally {
            try { if (fo != null) fo.close(); } catch (Exception e) {}
        }
        finish();
    }
}
