extends Node
# 桌宠物语：真实对战画面。服务器给出每一回合（谁打谁、伤害、暴击、剩余血量），这里把它演出来：冲过去撞、击飞、掉血条。

const UI = preload("res://scripts/ui.gd")
const CR = preload("res://scripts/creature.gd")
const SP = preload("res://scripts/species.gd")
const ART = preload("res://scripts/art.gd")
const StageScript = preload("res://scripts/stage.gd")

var app
var stage
var layer: Control
var skip := false
var fighters: Array = []
var bars: Array = []
var homes: Array = [0.0, 0.0]
var sc := 0.8

func _wait(s: float) -> void:
	if skip:
		return
	await get_tree().create_timer(s).timeout

func _alive() -> bool:
	return is_instance_valid(stage) and is_instance_valid(layer)

func _arrive(c: Node, timeout := 2.5) -> void:
	var t0 := Time.get_ticks_msec()
	while is_instance_valid(c) and c.walk_target != INF and (Time.get_ticks_msec() - t0) < int(timeout * 1000.0) and not skip:
		await get_tree().process_frame

func _bar(title: String, left: bool) -> Dictionary:
	var box := UI.vb(4)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var nm := UI.label(title, 22, UI.TXT)
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT if left else HORIZONTAL_ALIGNMENT_RIGHT
	box.add_child(nm)
	var back := ColorRect.new()
	back.color = Color(1, 1, 1, 0.15)
	back.custom_minimum_size = Vector2(0, 18)
	back.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var fill := ColorRect.new()
	fill.color = Color("#6fcf7f")
	fill.anchor_bottom = 1.0
	fill.anchor_right = 1.0
	back.add_child(fill)
	box.add_child(back)
	var hp := UI.label("", 18, UI.MUTED)
	hp.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT if left else HORIZONTAL_ALIGNMENT_RIGHT
	box.add_child(hp)
	return {"box": box, "fill": fill, "hp": hp}

func _set_hp(i: int, hp: int, mx: int) -> void:
	var b: Dictionary = bars[i]
	var r := clampf(float(hp) / maxf(1.0, float(mx)), 0.0, 1.0)
	var f: ColorRect = b.fill
	var tw := create_tween()
	tw.tween_property(f, "anchor_right", r, 0.35)
	f.color = Color("#6fcf7f") if r > 0.5 else (Color("#e8c15a") if r > 0.25 else Color("#e0605a"))
	(b.hp as Label).text = "%d / %d" % [hp, mx]

func _float(c: Node, text: String, col: Color, size: int) -> void:
	if not _alive():
		return
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(l)
	var hp: Vector2 = c.head_top_global() - layer.get_global_rect().position
	l.position = hp + Vector2(-30, -20)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 80, 0.9)
	tw.tween_property(l, "modulate:a", 0.0, 0.9)
	tw.chain().tween_callback(l.queue_free)

func play(a, j: Dictionary, my_comp: Dictionary) -> void:
	app = a
	var me: Dictionary = j.get("me", {})
	var op: Dictionary = j.get("opponent", {})
	var win := bool(j.get("win", false))
	var turns: Array = j.get("turns", [])
	var v: VBoxContainer = app._modal("对战", 920.0)
	var top := UI.hb(16)
	bars = [_bar(String(me.get("name", "我")), true), _bar("%s 的 %s" % [String(op.get("owner", "")), String(op.get("name", ""))], false)]
	top.add_child(bars[0].box)
	top.add_child(UI.label("VS", 28, UI.MUTED))
	top.add_child(bars[1].box)
	v.add_child(top)
	stage = StageScript.new()
	stage.custom_minimum_size = Vector2(860, 340)
	stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(stage)
	layer = Control.new()
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	stage.add_child(layer)
	var info := UI.label("", 22, UI.TXT, true)
	v.add_child(info)
	var skb := UI.btn("跳过", func(): skip = true, "ghost", 22)
	v.add_child(skb)
	await get_tree().process_frame
	await get_tree().process_frame
	if not _alive():
		queue_free()
		return
	var W: float = stage.size.x
	var gy: float = stage.ground_y()
	sc = clampf(stage.size.y / 480.0, 0.4, 0.85)
	homes = [W * 0.24, W * 0.76]
	var specs: Array = []
	specs.append(my_comp.get("spec", {}))
	var os = j.get("opp_spec", null)
	if typeof(os) != TYPE_DICTIONARY:
		os = SP.offline_spec("野生小怪", String(op.get("name", "野生小怪")), 77)
	specs.append(SP.normalize(os))
	for i in 2:
		var c = CR.new()
		c.font = app.font
		c.set_spec(SP.normalize(specs[i]) if i == 1 else specs[i])
		if i == 0:
			c.set_art(ART.load_for(my_comp))
		c.scale = Vector2.ONE * sc
		c.wander = false
		c.position = Vector2(homes[i], gy)
		layer.add_child(c)
		c.set_ground(gy, 40.0, W - 40.0)
		c.facing = 1.0 if i == 0 else -1.0
		fighters.append(c)
	var mx := [int(me.get("hp", 100)), int(op.get("hp", 100))]
	_set_hp(0, mx[0], mx[0])
	_set_hp(1, mx[1], mx[1])
	info.text = "对战开始！"
	fighters[0].react("excited", "jump", 1.2)
	fighters[1].react("angry", "none", 1.2)
	await _wait(1.0)
	var n := 0
	for t in turns:
		if not _alive():
			queue_free()
			return
		n += 1
		var s := int(t.get("s", 0))
		var att = fighters[s]
		var df = fighters[1 - s]
		var dmg := int(t.get("dmg", 0))
		var crit := bool(t.get("crit", false))
		var dirx := 1.0 if df.position.x > att.position.x else -1.0
		att.walk_speed = 420.0
		att.walk_to(df.position.x - dirx * 110.0 * sc)
		await _arrive(att, 1.6)
		att.facing = dirx
		df.facing = -dirx
		att.react("angry", "jump", 0.9)
		await _wait(0.15)
		if not _alive():
			queue_free()
			return
		df.airborne = true
		df.vel = Vector2(dirx * (700.0 if crit else 420.0), -520.0 if crit else -380.0)
		df.react("scared", "shake", 1.2)
		_float(df, ("暴击！ -%d" % dmg) if crit else ("-%d" % dmg), Color("#ff7a6a") if crit else Color("#ffd27a"), 40 if crit else 30)
		var ha := int(t.get("ha", 0))
		var hb := int(t.get("hb", 0))
		_set_hp(0, ha, mx[0])
		_set_hp(1, hb, mx[1])
		info.text = "%s 对 %s 造成 %d 点伤害%s" % [String(me.name if s == 0 else op.name), String(op.name if s == 0 else me.name), dmg, "（暴击！）" if crit else ""]
		await _wait(0.8 if n < 9 else 0.45)
		if not _alive():
			queue_free()
			return
		att.walk_speed = 260.0
		att.walk_to(homes[s])
		df.walk_speed = 260.0
		df.walk_to(homes[1 - s])
		await _wait(0.5 if n < 9 else 0.25)
		await _arrive(att, 1.2)
	if not _alive():
		queue_free()
		return
	skb.queue_free()
	var loser = fighters[1] if win else fighters[0]
	var winner = fighters[0] if win else fighters[1]
	_set_hp(0, int(turns.back().get("ha", 0)) if not turns.is_empty() else mx[0], mx[0])
	_set_hp(1, int(turns.back().get("hb", 0)) if not turns.is_empty() else mx[1], mx[1])
	winner.walk_to(homes[0] if win else homes[1])
	winner.react("happy", "cheer", 4.0)
	loser.react("sad", "sit", 4.0)
	v.add_child(UI.title(("🏆 你赢了！" if win else "💔 这次输了"), 34, UI.GOOD if win else UI.BAD))
	if bool(j.get("friendly", false)):
		v.add_child(UI.hint("友谊赛，不加减积分。"))
	else:
		v.add_child(UI.label("积分 %+d → %d　（%d 胜 %d 负，今天还能打 %d 次）" % [int(j.get("delta", 0)), int(j.get("score", 0)), int(j.get("wins", 0)), int(j.get("losses", 0)), int(j.get("left", 0))], 23, UI.TXT, true))
	v.add_child(UI.btn("关闭", func(): app.close_modal(), "primary", 24))
	info.text = ""
	await get_tree().create_timer(6.0).timeout
	queue_free()
