extends Node
# 桌宠物语：轻量音效。全部用代码合成，不打包音频文件（省体积）。

const RATE := 22050
var _players: Array = []
var _cache: Dictionary = {}
var on := true

func setup() -> void:
	for i in 4:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_players.append(p)

func _wav(samples: PackedFloat32Array) -> AudioStreamWAV:
	var buf := PackedByteArray()
	buf.resize(samples.size() * 2)
	for i in samples.size():
		var v := int(clampf(samples[i], -1.0, 1.0) * 32767.0)
		buf.encode_s16(i * 2, v)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = buf
	return w

func _tone(freqs: Array, dur: float, kind := "sine") -> AudioStreamWAV:
	var n := int(RATE * dur)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / RATE
		var prog := float(i) / n
		var env := exp(-prog * 4.0) * minf(1.0, prog * 40.0)
		var v := 0.0
		for f in freqs:
			var ph := t * float(f) * TAU
			if kind == "square":
				v += (1.0 if sin(ph) > 0.0 else -1.0)
			else:
				v += sin(ph)
		s[i] = v / float(freqs.size()) * env * 0.5
	return _wav(s)

func _snd(name: String) -> AudioStreamWAV:
	if _cache.has(name):
		return _cache[name]
	var w: AudioStreamWAV
	match name:
		"chime":
			w = _tone([660.0, 990.0], 0.18)
			var w2 := _tone([880.0, 1320.0], 0.3)
			var merged := PackedByteArray()
			merged.append_array(w.data)
			merged.append_array(w2.data)
			w.data = merged
		"pop":
			w = _tone([520.0, 780.0], 0.09)
		"tap":
			w = _tone([880.0], 0.05)
		"happy":
			w = _tone([784.0], 0.1)
			var w3 := _tone([1047.0], 0.16)
			var m2 := PackedByteArray()
			m2.append_array(w.data)
			m2.append_array(w3.data)
			w.data = m2
		_:
			w = _tone([660.0], 0.08)
	_cache[name] = w
	return w

func play(name: String) -> void:
	if not on or _players.is_empty():
		return
	for p in _players:
		if not p.playing:
			p.stream = _snd(name)
			p.play()
			return
	_players[0].stream = _snd(name)
	_players[0].play()
