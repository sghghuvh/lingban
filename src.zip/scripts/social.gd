extends RefCounted
# 桌宠物语：好友 / 私信 / 拜访好友的伙伴 / 两只伙伴对话 / PK（全部走自己的服务器）

const UI = preload("res://scripts/ui.gd")
const PKView = preload("res://scripts/pkview.gd")
const SPc = preload("res://scripts/species.gd")
const GET := HTTPClient.METHOD_GET
const POST := HTTPClient.METHOD_POST

var app
var friends: Array = []
var reqs: Array = []
var box: VBoxContainer

func _call(path: String, method: int, body: Dictionary, cb: Callable) -> void:
	app.llm.srv_call(path, method, body, cb)

static func card_of(c: Dictionary) -> Dictionary:
	var s: Dictionary = c.spec
	var p: Dictionary = s.personality
	var persona := "%s。性格：%s。说话：%s。喜欢：%s。来历：%s" % [String(s.get("label", "")), String(p.get("desc", "")), String(p.get("speech", "")), "、".join(p.get("likes", [])), String(p.get("backstory", ""))]
	return {"name": String(s.name), "species": String(s.get("label", "")), "affection": int(c.state.get("affection", 0)), "msgs": int(c.state.get("msgs", 0)), "persona": persona.left(600)}

func _my_card() -> Dictionary:
	var cur = app.store.current()
	if cur == null:
		return {}
	var c := card_of(cur)
	c["spec"] = cur.spec
	return c

# ------------------------------------------------------------------ 页面
func build(a) -> void:
	app = a
	var body: VBoxContainer = app._scroll_page("好友与 PK", "settings")
	if not app.store.logged():
		var s0: VBoxContainer = app._section(body, "")
		s0.add_child(UI.label("先到 设置 → 账号与共享服务 注册或登录，才能加好友、PK 和聊天。", 24, UI.TXT, true))
		s0.add_child(UI.btn("去设置", func(): app.show_screen("settings"), "primary", 24))
		return
	var mc := _my_card()
	if not mc.is_empty():
		_call("/api/card", POST, mc, func(_ok: bool, _j: Dictionary, _e: String): pass)
	var add: VBoxContainer = app._section(body, "添加好友")
	add.add_child(UI.hint("输入对方的昵称（让朋友先注册，把昵称告诉你）。对方同意后就成为好友。"))
	var row := UI.hb(12)
	var fn := UI.le("对方昵称")
	row.add_child(fn)
	var res := UI.hint("")
	row.add_child(UI.btn("添加", func():
		var nm := fn.text.strip_edges()
		if nm == "":
			return
		res.text = "请稍等…"
		_call("/api/friend", POST, {"name": nm}, func(ok: bool, j: Dictionary, err: String):
			if not is_instance_valid(res):
				return
			if not ok:
				res.text = "✕ " + err
				return
			var st := String(j.get("status", ""))
			res.text = {"sent": "已发出申请，等对方同意", "friends": "已经成为好友了！", "already": "你们已经是好友了"}.get(st, "完成")
			fn.text = ""
			refresh()), "primary", 24))
	add.add_child(row)
	add.add_child(res)
	box = UI.vb(18)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(box)
	box.add_child(UI.hint("加载中…"))
	refresh()
	var pk: VBoxContainer = app._section(body, "排位 PK")
	pk.add_child(UI.hint("和别的玩家的伙伴在擂台上真打一场（每天 10 次）：冲撞、击飞、暴击，血条打光就输。赢了加分，输了扣分。实力由伙伴的好感度和聊天量决定，所以多陪陪它。"))
	var pr := UI.hb(12)
	pr.add_child(UI.btn("开始排位", func(): _pk_popup(null), "primary", 24))
	pr.add_child(UI.btn("排行榜", func(): _rank_popup(), "ghost", 24))
	pk.add_child(pr)
	var vs: VBoxContainer = app._section(body, "查看别人的主页")
	var vr := UI.hb(10)
	var vn := UI.le("输入对方昵称")
	vr.add_child(vn)
	vr.add_child(UI.btn("查看", func():
		if vn.text.strip_edges() != "":
			show_profile(vn.text.strip_edges()), "primary", 24))
	vs.add_child(vr)
	_showcase_section(body)

func refresh() -> void:
	_call("/api/friends", GET, {}, func(ok: bool, j: Dictionary, err: String):
		if not is_instance_valid(box):
			return
		for ch in box.get_children():
			ch.queue_free()
		if not ok:
			box.add_child(UI.hint("✕ " + err))
			return
		friends = j.get("friends", [])
		reqs = j.get("reqs", [])
		if not reqs.is_empty():
			var rs: VBoxContainer = app._section(box, "好友申请")
			for r in reqs:
				var rid := String(r.id)
				var rr := UI.hb(12)
				rr.add_child(UI.grow(UI.label(String(r.name), 26, UI.TXT)))
				rr.add_child(UI.btn("同意", func(): _answer(rid, true), "primary", 22))
				rr.add_child(UI.btn("拒绝", func(): _answer(rid, false), "ghost", 22))
				rs.add_child(rr)
		var fs: VBoxContainer = app._section(box, "我的好友（%d）" % friends.size())
		if friends.is_empty():
			fs.add_child(UI.hint("还没有好友。把你的昵称告诉朋友，让 TA 也下载桌宠物语注册，再互相添加吧。"))
		for f in friends:
			_friend_row(fs, f))

func _answer(id: String, accept: bool) -> void:
	_call("/api/friend/answer", POST, {"id": id, "accept": accept}, func(_ok: bool, _j: Dictionary, _e: String): refresh())

func _friend_row(parent: Control, f: Dictionary) -> void:
	var comp = f.get("comp", null)
	var cname := String(comp.get("name", "")) if typeof(comp) == TYPE_DICTIONARY else ""
	var unread := int(f.get("unread", 0))
	var p := UI.panel(UI.BG.lightened(0.04), 18, 16)
	var v := UI.vb(8)
	p.add_child(v)
	v.add_child(UI.title(String(f.name) + ("　（%d 条新消息）" % unread if unread > 0 else ""), 27))
	v.add_child(UI.label(("TA 的伙伴：%s　积分 %d" % [cname, int(f.get("score", 1000))]) if cname != "" else "TA 的伙伴还没登记（让 TA 打开一次这个页面）", 21, UI.MUTED, true))
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 10)
	fl.add_theme_constant_override("v_separation", 10)
	fl.add_child(UI.btn("聊天", func(): _dm_popup(f), "primary", 22))
	fl.add_child(UI.btn("主页", func(): show_profile(String(f.name)), "ghost", 22))
	if cname != "":
		fl.add_child(UI.btn("找 TA 的伙伴聊", func(): _visit_popup(f), "ghost", 22))
		fl.add_child(UI.btn("让两只伙伴聊", func(): _duet_popup(f), "ghost", 22))
		fl.add_child(UI.btn("切磋 PK", func(): _pk_popup(f), "ghost", 22))
	fl.add_child(UI.btn("删除", func():
		_call("/api/friend/remove", POST, {"id": String(f.id)}, func(_ok: bool, _j: Dictionary, _e: String): refresh()), "flat", 20))
	v.add_child(fl)
	parent.add_child(p)

# ------------------------------------------------------------------ 私信
func _dm_popup(f: Dictionary) -> void:
	var fid := String(f.id)
	var v: VBoxContainer = app._modal("和 %s 聊天" % String(f.name), 700.0)
	var lst := UI.vb(8)
	v.add_child(lst)
	var inp := UI.le("说点什么…")
	var load := func(): pass
	load = func():
		_call("/api/dm?with=" + fid, GET, {}, func(ok: bool, j: Dictionary, err: String):
			if not is_instance_valid(lst):
				return
			for ch in lst.get_children():
				ch.queue_free()
			if not ok:
				lst.add_child(UI.hint("✕ " + err))
				return
			var msgs: Array = j.get("msgs", [])
			if msgs.is_empty():
				lst.add_child(UI.hint("还没有消息，打个招呼吧。"))
			for m in msgs:
				var mine := bool(m.get("me", false))
				lst.add_child(UI.label(("我：" if mine else (String(f.name) + "：")) + String(m.get("text", "")), 23, UI.TXT if not mine else UI.GOOD, true)))
	var send := func():
		var t := inp.text.strip_edges()
		if t == "":
			return
		inp.text = ""
		_call("/api/dm", POST, {"to": fid, "text": t}, func(ok: bool, _j: Dictionary, err: String):
			if not ok:
				app.toast(err)
			load.call())
	var row := UI.hb(10)
	row.add_child(inp)
	row.add_child(UI.btn("发送", send, "primary", 24))
	v.add_child(row)
	inp.text_submitted.connect(func(_t): send.call())
	load.call()
	var tm := Timer.new()
	tm.wait_time = 5.0
	tm.autostart = true
	app.add_child(tm)
	tm.timeout.connect(func():
		if not is_instance_valid(lst):
			tm.queue_free()
			return
		load.call())

# ------------------------------------------------------------------ 找朋友的伙伴聊天
func _visit_popup(f: Dictionary) -> void:
	var fid := String(f.id)
	var cname := String(f.comp.get("name", "TA 的伙伴"))
	var v: VBoxContainer = app._modal("拜访 %s" % cname, 700.0)
	v.add_child(UI.hint("%s 会按它自己的性格回答你（每句消耗 1 点额度）。" % cname))
	var lst := UI.vb(8)
	v.add_child(lst)
	var hist: Array = []
	var inp := UI.le("对 %s 说…" % cname)
	var send := func():
		var t := inp.text.strip_edges()
		if t == "":
			return
		inp.text = ""
		lst.add_child(UI.label("我：" + t, 23, UI.GOOD, true))
		var waitl := UI.hint("……")
		lst.add_child(waitl)
		var sent := hist.duplicate()
		hist.append({"me": true, "text": t})
		_call("/api/visit", POST, {"friend": fid, "text": t, "history": sent}, func(ok: bool, j: Dictionary, err: String):
			if not is_instance_valid(lst):
				return
			waitl.queue_free()
			if not ok:
				lst.add_child(UI.hint("✕ " + err))
				return
			var rp := String(j.get("reply", ""))
			hist.append({"me": false, "text": rp})
			lst.add_child(UI.label("%s：%s" % [cname, rp], 23, UI.TXT, true)))
	var row := UI.hb(10)
	row.add_child(inp)
	row.add_child(UI.btn("发送", send, "primary", 24))
	v.add_child(row)
	inp.text_submitted.connect(func(_t): send.call())

# ------------------------------------------------------------------ 两只伙伴聊天
func _duet_popup(f: Dictionary) -> void:
	var fid := String(f.id)
	var mc := _my_card()
	var v: VBoxContainer = app._modal("伙伴见面会", 700.0)
	v.add_child(UI.hint("让你的 %s 和 TA 的 %s 聊一会儿（每次消耗 2 点额度）。" % [String(mc.get("name", "伙伴")), String(f.comp.get("name", "伙伴"))]))
	var topic := UI.le("话题（可不填）")
	v.add_child(topic)
	var lst := UI.vb(8)
	v.add_child(lst)
	var go := func():
		for ch in lst.get_children():
			ch.queue_free()
		lst.add_child(UI.hint("它们正在聊…"))
		_call("/api/card", POST, mc, func(_ok: bool, _j: Dictionary, _e: String):
			_call("/api/duet", POST, {"friend": fid, "topic": topic.text.strip_edges()}, func(ok: bool, j: Dictionary, err: String):
				if not is_instance_valid(lst):
					return
				for ch in lst.get_children():
					ch.queue_free()
				if not ok:
					lst.add_child(UI.hint("✕ " + err))
					return
				for ln in j.get("lines", []):
					lst.add_child(UI.label("%s：%s" % [String(ln.get("name", "")), String(ln.get("text", ""))], 24, UI.GOOD if String(ln.get("who", "")) == "me" else UI.TXT, true))))
	v.add_child(UI.btn("开始聊天", go, "primary", 24))

# ------------------------------------------------------------------ PK
func _pk_popup(f) -> void:
	var mc := _my_card()
	if mc.is_empty():
		app.toast("先创造一个伙伴")
		return
	var cur_c = app.store.current()
	var v: VBoxContainer = app._modal("切磋中…" if f != null else "排位 PK", 700.0)
	var lst := UI.vb(8)
	v.add_child(lst)
	lst.add_child(UI.hint("正在匹配对手…"))
	var body := {"companion": mc}
	if f != null:
		body["vs"] = String(f.id)
	_call("/api/pk", POST, body, func(ok: bool, j: Dictionary, err: String):
		if not is_instance_valid(lst):
			return
		for ch in lst.get_children():
			ch.queue_free()
		if not ok:
			lst.add_child(UI.hint("✕ " + err))
			return
		if not j.get("turns", []).is_empty():
			var pv = PKView.new()
			app.add_child(pv)
			pv.play(app, j, cur_c)
			return
		var me: Dictionary = j.get("me", {})
		var op: Dictionary = j.get("opponent", {})
		var win := bool(j.get("win", false))
		lst.add_child(UI.title(("🏆 你赢了！" if win else "💔 你输了"), 34, UI.GOOD if win else UI.BAD))
		lst.add_child(UI.label("%s（生命 %d 攻击 %d）  对战  %s 的 %s（生命 %d 攻击 %d）" % [String(me.get("name", "")), int(me.get("hp", 0)), int(me.get("atk", 0)), String(op.get("owner", "")), String(op.get("name", "")), int(op.get("hp", 0)), int(op.get("atk", 0))], 22, UI.MUTED, true))
		if bool(j.get("friendly", false)):
			lst.add_child(UI.hint("友谊赛，不加减积分。"))
		else:
			lst.add_child(UI.label("积分 %+d → %d　（%d 胜 %d 负，今天还能打 %d 次）" % [int(j.get("delta", 0)), int(j.get("score", 0)), int(j.get("wins", 0)), int(j.get("losses", 0)), int(j.get("left", 0))], 23, UI.TXT, true))
		var lg: Array = j.get("log", [])
		for ln in lg:
			lst.add_child(UI.label(String(ln), 20, UI.MUTED, true)))

func _rank_popup() -> void:
	var v: VBoxContainer = app._modal("排行榜", 700.0)
	var lst := UI.vb(8)
	v.add_child(lst)
	lst.add_child(UI.hint("加载中…"))
	_call("/api/rank", GET, {}, func(ok: bool, j: Dictionary, err: String):
		if not is_instance_valid(lst):
			return
		for ch in lst.get_children():
			ch.queue_free()
		if not ok:
			lst.add_child(UI.hint("✕ " + err))
			return
		var mine = j.get("mine", null)
		if typeof(mine) == TYPE_DICTIONARY:
			lst.add_child(UI.label("我：积分 %d（%d 胜 %d 负）" % [int(mine.get("score", 0)), int(mine.get("wins", 0)), int(mine.get("losses", 0))], 24, UI.GOOD, true))
		for r in j.get("list", []):
			var rn := String(r.get("name", ""))
			var rr := UI.hb(10)
			rr.add_child(UI.grow(UI.label("#%d  %s　%s　%d 分" % [int(r.get("rank", 0)), rn, String(r.get("companion", "")), int(r.get("score", 0))], 22, UI.TXT, true)))
			rr.add_child(UI.btn("主页", func(): show_profile(rn), "flat", 20))
			lst.add_child(rr))

# ================================================================== 伙伴市场
var mk_sort := "hot"
var mk_q := ""
var mk_box: VBoxContainer

func build_market(a) -> void:
	app = a
	var body: VBoxContainer = app._scroll_page("伙伴市场", "settings")
	if not app.store.logged():
		var s0: VBoxContainer = app._section(body, "")
		s0.add_child(UI.label("先到 设置 → 账号与共享服务 注册或登录，才能逛市场。", 24, UI.TXT, true))
		s0.add_child(UI.btn("去设置", func(): app.show_screen("settings"), "primary", 24))
		return
	var cur = app.store.current()
	var pub: VBoxContainer = app._section(body, "发布我的伙伴")
	if cur == null:
		pub.add_child(UI.hint("先创造一个伙伴，才能发布。"))
	else:
		pub.add_child(UI.hint("把「%s」发布到市场，别人可以收藏它，放到自己的桌面上。只会公开外形和性格，不含聊天记录和记忆。" % String(cur.spec.name)))
		var ft := UI.le("标题", String(cur.spec.name))
		var fd := UI.le("一句话介绍（可不填）")
		pub.add_child(ft)
		pub.add_child(fd)
		var res := UI.hint("")
		pub.add_child(UI.btn("发布", func():
			res.text = "请稍等…"
			_call("/api/market", POST, {"title": ft.text.strip_edges(), "desc": fd.text.strip_edges(), "spec": cur.spec}, func(ok: bool, _j: Dictionary, err: String):
				if is_instance_valid(res):
					res.text = "✓ 已发布" if ok else ("✕ " + err)
				if ok:
					market_refresh()), "primary", 24))
		pub.add_child(res)
	var mine: VBoxContainer = app._section(body, "我的收藏")
	if app.store.collection.is_empty():
		mine.add_child(UI.hint("还没有收藏。下面逛逛，点「收藏」把喜欢的伙伴带回家。"))
	for c in app.store.collection:
		var mid := String(c.get("mid", ""))
		var r := UI.hb(10)
		r.add_child(UI.grow(UI.label("%s　by %s" % [String(c.get("title", "")), String(c.get("author", ""))], 24, UI.TXT, true)))
		r.add_child(UI.btn("取消收藏", func():
			app.store.collection = app.store.collection.filter(func(x): return String(x.get("mid", "")) != mid)
			var mm: Array = app.store.settings.overlay.members
			mm.erase("col:" + mid)
			app.store.save_collection()
			app.store.save_settings()
			app.show_screen("market"), "flat", 20))
		mine.add_child(r)
	mine.add_child(UI.btn("管理桌面成员", func(): app.show_screen("members"), "ghost", 22))
	var br: VBoxContainer = app._section(body, "逛逛")
	br.add_child(UI.seg([["hot", "热门"], ["new", "最新"]], mk_sort, func(v):
		mk_sort = String(v)
		market_refresh()))
	var sr := UI.hb(10)
	var fq := UI.le("搜索名字或作者", mk_q)
	sr.add_child(fq)
	sr.add_child(UI.btn("搜索", func():
		mk_q = fq.text.strip_edges()
		market_refresh(), "ghost", 22))
	br.add_child(sr)
	mk_box = UI.vb(12)
	br.add_child(mk_box)
	market_refresh()

func market_refresh() -> void:
	if not is_instance_valid(mk_box):
		return
	for ch in mk_box.get_children():
		ch.queue_free()
	mk_box.add_child(UI.hint("加载中…"))
	_call("/api/market?sort=%s&q=%s" % [mk_sort, mk_q.uri_encode()], GET, {}, func(ok: bool, j: Dictionary, err: String):
		if not is_instance_valid(mk_box):
			return
		for ch in mk_box.get_children():
			ch.queue_free()
		if not ok:
			mk_box.add_child(UI.hint("✕ " + err))
			return
		var items: Array = j.get("items", [])
		if items.is_empty():
			mk_box.add_child(UI.hint("这里还空空的，快发布第一个吧。"))
		for it in items:
			_market_row(it))

func _market_row(it: Dictionary) -> void:
	var id := String(it.get("id", ""))
	var p := UI.panel(UI.BG.lightened(0.04), 18, 16)
	var v := UI.vb(8)
	p.add_child(v)
	v.add_child(UI.title(String(it.get("title", "")), 26))
	v.add_child(UI.label("作者 %s　♥ %d　收藏 %d" % [String(it.get("author", "")), int(it.get("likes", 0)), int(it.get("downloads", 0))], 20, UI.MUTED))
	var d := String(it.get("desc", ""))
	if d != "":
		v.add_child(UI.label(d, 22, UI.TXT, true))
	var fl := HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 10)
	fl.add_theme_constant_override("v_separation", 10)
	var have: bool = app.store.collected(id)
	fl.add_child(UI.btn("已收藏" if have else "收藏", func():
		_call("/api/market/" + id, GET, {}, func(ok: bool, j: Dictionary, err: String):
			if not ok:
				app.toast(err)
				return
			if not app.store.collected(id) and typeof(j.get("spec")) == TYPE_DICTIONARY:
				app.store.collection.append({"mid": id, "title": String(j.get("title", "")), "author": String(j.get("author", "")), "spec": j.spec})
				app.store.save_collection()
			app.toast("已收藏，去「桌面成员」里放到桌面")
			app.show_screen("market")), "primary" if not have else "ghost", 22))
	fl.add_child(UI.btn("作者主页", func(): show_profile(String(it.get("author", ""))), "ghost", 22))
	fl.add_child(UI.btn("♥ 点赞", func():
		_call("/api/market/%s/like" % id, POST, {}, func(_ok: bool, _j: Dictionary, _e: String): market_refresh()), "ghost", 22))
	if bool(it.get("mine", false)):
		fl.add_child(UI.btn("删除我发布的", func():
			_call("/api/market/" + id, HTTPClient.METHOD_DELETE, {}, func(_ok: bool, _j: Dictionary, _e: String): market_refresh()), "flat", 20))
	else:
		fl.add_child(UI.btn("举报", func():
			_call("/api/market/%s/report" % id, POST, {}, func(_ok: bool, _j: Dictionary, _e: String): app.toast("已举报")), "flat", 20))
	v.add_child(fl)
	mk_box.add_child(p)

# ================================================================== 桌面成员
func build_members(a) -> void:
	app = a
	var body: VBoxContainer = app._scroll_page("桌面成员", "settings")
	var ov: Dictionary = app.store.settings.overlay
	var mem: Array = ov.members
	var cur = app.store.current()
	var h: VBoxContainer = app._section(body, "")
	h.add_child(UI.label("选哪些伙伴一起出现在桌面悬浮窗里。当前选中的伙伴是「主角」，下面勾选的都会一起出现，在桌面上走动、互相聊天、闹着玩。可以放自己所有的伙伴，也可以放收藏来的别人的伙伴，最多同时 7 个。", 22, UI.MUTED, true))
	var own: VBoxContainer = app._section(body, "我的伙伴")
	var any_own := false
	for c in app.store.companions:
		if cur != null and String(c.id) == String(cur.id):
			continue
		any_own = true
		_member_row(own, String(c.id), String(c.spec.name), "")
	if not any_own:
		own.add_child(UI.hint("你只有一个伙伴。去「创造新伙伴」多养几个吧。"))
	var col: VBoxContainer = app._section(body, "收藏的伙伴")
	if app.store.collection.is_empty():
		col.add_child(UI.hint("还没有收藏。去伙伴市场逛逛。"))
		col.add_child(UI.btn("去伙伴市场", func(): app.show_screen("market"), "primary", 22))
	for c in app.store.collection:
		_member_row(col, "col:" + String(c.get("mid", "")), String(c.get("title", "")), String(c.get("author", "")))
	var rg: VBoxContainer = app._section(body, "它们之间")
	rg.add_child(UI.label("伙伴们会自己找话题聊天。要不要允许它们偶尔吵架、打闹（动画里的小打小闹，不会有真伤害）？", 22, UI.MUTED, true))
	rg.add_child(UI.seg([["on", "允许吵闹"], ["off", "只聊天和玩耍"]], "on" if bool(ov.get("rough", true)) else "off", func(v):
		ov.rough = (String(v) == "on")
		app.store.save_settings()))
	rg.add_child(UI.label("它们自己开口聊天的频率（每小时最多几次，每次消耗 1 点额度）", 22, UI.MUTED, true))
	rg.add_child(UI.seg([[0, "不主动"], [2, "2 次"], [4, "4 次"], [8, "8 次"]], int(ov.get("scene_per_hour", 3)) if int(ov.get("scene_per_hour", 3)) in [0, 2, 4, 8] else 2, func(v):
		ov.scene_per_hour = int(v)
		app.store.save_settings()))
	rg.add_child(UI.hint("设置好后，回到聊天页重新开启桌面悬浮。悬浮窗里点主角会出现「聊天 / 吵架 / 打闹 / 玩耍」按钮，可以由你来指定。"))

func _member_row(parent: Control, id: String, title: String, author: String) -> void:
	var mem: Array = app.store.settings.overlay.members
	var r := UI.hb(10)
	r.add_child(UI.grow(UI.label(title + ("　by " + author if author != "" else ""), 24, UI.TXT, true)))
	var on := mem.has(id)
	r.add_child(UI.btn("已在桌面（点击移除）" if on else "放到桌面", func():
		if mem.has(id):
			mem.erase(id)
		elif mem.size() >= 7:
			app.toast("桌面最多同时 7 个")
			return
		else:
			mem.append(id)
		app.store.save_settings()
		app.show_screen("members"), "ghost" if on else "primary", 22))
	parent.add_child(r)


# ================================================================== 个人主页 / 公开橱窗
func show_profile(name: String) -> void:
	var v: VBoxContainer = app._modal("%s 的主页" % name, 760.0)
	var lst := UI.vb(10)
	v.add_child(lst)
	lst.add_child(UI.hint("加载中…"))
	_call("/api/profile?name=" + name.uri_encode(), GET, {}, func(ok: bool, j: Dictionary, err: String):
		if not is_instance_valid(lst):
			return
		for ch in lst.get_children():
			ch.queue_free()
		if not ok:
			lst.add_child(UI.hint("✕ " + err))
			return
		lst.add_child(UI.title(String(j.get("name", "")), 32))
		var bio := String(j.get("bio", ""))
		if bio != "":
			lst.add_child(UI.label(bio, 22, UI.TXT, true))
		lst.add_child(UI.label("积分 %d　%d 胜 %d 负　好友 %d 个" % [int(j.get("score", 1000)), int(j.get("wins", 0)), int(j.get("losses", 0)), int(j.get("friends", 0))], 22, UI.MUTED, true))
		var uid := String(j.get("id", ""))
		var act := HFlowContainer.new()
		act.add_theme_constant_override("h_separation", 10)
		act.add_theme_constant_override("v_separation", 10)
		if not bool(j.get("self", false)):
			if bool(j.get("friend", false)):
				act.add_child(UI.btn("切磋 PK", func():
					app.close_modal()
					_pk_popup({"id": uid, "name": String(j.get("name", ""))}), "primary", 22))
			else:
				act.add_child(UI.btn("加好友", func():
					_call("/api/friend", POST, {"name": String(j.get("name", ""))}, func(ok2: bool, j2: Dictionary, err2: String):
						app.toast(("已发出申请" if String(j2.get("status", "")) == "sent" else "已经是好友") if ok2 else err2)), "primary", 22))
		lst.add_child(act)
		var sh: Array = j.get("show", [])
		lst.add_child(UI.title("公开的伙伴", 26))
		if sh.is_empty():
			lst.add_child(UI.hint("TA 还没有公开伙伴。"))
		for it in sh:
			var sid := String(it.get("sid", ""))
			var allow := bool(it.get("allow", false))
			var title := String(it.get("title", ""))
			var r := UI.panel(UI.BG.lightened(0.04), 16, 14)
			var rv := UI.vb(6)
			r.add_child(rv)
			rv.add_child(UI.title(title, 24))
			var dd := String(it.get("desc", ""))
			if dd != "":
				rv.add_child(UI.label(dd, 20, UI.TXT, true))
			var mid := "u%s_%s" % [uid, sid]
			if allow:
				var have: bool = app.store.collected(mid)
				rv.add_child(UI.btn("已收藏" if have else "收藏", func():
					_call("/api/profile/%s/show/%s" % [uid, sid], GET, {}, func(ok3: bool, j3: Dictionary, err3: String):
						if not ok3:
							app.toast(err3)
							return
						if not app.store.collected(mid) and typeof(j3.get("spec")) == TYPE_DICTIONARY:
							app.store.collection.append({"mid": mid, "title": title, "author": String(j3.get("author", "")), "spec": j3.spec})
							app.store.save_collection()
						app.toast("已收藏，去「桌面成员」里放到桌面")), "primary" if not have else "ghost", 22))
			else:
				rv.add_child(UI.hint("对方没有开放收藏这只伙伴"))
			lst.add_child(r))

var _sc_state := {}

func _showcase_section(body: VBoxContainer) -> void:
	var sec: VBoxContainer = app._section(body, "我的公开主页与隐私")
	sec.add_child(UI.hint("别人能在你的主页看到战绩和你选择公开的伙伴。每只伙伴可以单独设置：是否公开、是否允许别人收藏（收藏 = 复制外形和性格，不含你们的聊天记录和记忆）。"))
	var vis := ["all"]
	var lst := UI.vb(8)
	var segbox := UI.vb(0)
	sec.add_child(UI.label("谁能看我的主页", 22, UI.MUTED))
	sec.add_child(segbox)
	sec.add_child(UI.label("公开哪些伙伴", 22, UI.MUTED))
	sec.add_child(lst)
	var res := UI.hint("")
	# 先读出服务器上现在的设置
	_call("/api/me", GET, {}, func(ok: bool, j: Dictionary, _e: String):
		if not is_instance_valid(lst):
			return
		var u: Dictionary = j.get("user", {}) if ok else {}
		vis[0] = String(u.get("profile", "all"))
		var cur_show: Array = u.get("show", [])
		segbox.add_child(UI.seg([["all", "所有人可看"], ["friends", "仅好友"], ["none", "不公开主页"]], vis[0], func(x): vis[0] = String(x)))
		for c in app.store.companions:
			var cid := String(c.id)
			var sid := ""
			var on := false
			var allow := false
			for x in cur_show:
				if String(x.get("title", "")) == String(c.spec.name):
					sid = String(x.get("sid", ""))
					on = true
					allow = bool(x.get("allow", false))
			_sc_state[cid] = {"on": on, "allow": allow, "sid": sid}
			var r := UI.hb(10)
			r.add_child(UI.grow(UI.label(String(c.spec.name), 24, UI.TXT, true)))
			var b1 := CheckBox.new()
			b1.text = "公开"
			b1.button_pressed = on
			b1.toggled.connect(func(p: bool): _sc_state[cid].on = p)
			var b2 := CheckBox.new()
			b2.text = "允许收藏"
			b2.button_pressed = allow
			b2.toggled.connect(func(p: bool): _sc_state[cid].allow = p)
			r.add_child(b1)
			r.add_child(b2)
			lst.add_child(r))
	sec.add_child(UI.btn("保存", func():
		var items: Array = []
		for c in app.store.companions:
			var st: Dictionary = _sc_state.get(String(c.id), {})
			if bool(st.get("on", false)) and items.size() < 6:
				items.append({"sid": String(st.get("sid", "")), "title": String(c.spec.name), "desc": String(c.spec.get("personality", {}).get("desc", "")).left(60), "allow": bool(st.get("allow", false)), "spec": c.spec})
		res.text = "请稍等…"
		_call("/api/me", POST, {"profile": vis[0]}, func(ok1: bool, _j1: Dictionary, e1: String):
			if not ok1:
				if is_instance_valid(res):
					res.text = "✕ " + e1
				return
			_call("/api/showcase", POST, {"items": items}, func(ok2: bool, _j2: Dictionary, e2: String):
				if is_instance_valid(res):
					res.text = "✓ 已保存" if ok2 else ("✕ " + e2))), "primary", 24))
	sec.add_child(res)
