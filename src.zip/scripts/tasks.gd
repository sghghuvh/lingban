extends Node
# 灵伴：每日任务、连续打卡、好感度奖励。

signal task_done(task: Dictionary)

var app
var rng := RandomNumberGenerator.new()

const POOL := {
	"interact": [
		{"id": "chat5", "text": "和{n}聊 5 句天", "goal": 5, "kind": "chat"},
		{"id": "pet3", "text": "摸摸{n}的头 3 次", "goal": 3, "kind": "pet"},
		{"id": "voice1", "text": "用语音和{n}说一句话", "goal": 1, "kind": "voice"},
		{"id": "carry1", "text": "把{n}拎起来转一圈", "goal": 1, "kind": "carry"},
	],
	"fun": [
		{"id": "joke", "text": "让{n}讲一个笑话", "goal": 1, "kind": "joke"},
		{"id": "riddle", "text": "和{n}玩一次猜谜", "goal": 1, "kind": "riddle"},
		{"id": "share", "text": "跟{n}分享一件今天的小事", "goal": 1, "kind": "long"},
		{"id": "learn", "text": "让{n}教你一个新知识", "goal": 1, "kind": "learn"},
		{"id": "dance", "text": "让{n}跳一支舞", "goal": 1, "kind": "dance"},
	],
	"life": [
		{"id": "water", "text": "喝一杯水", "goal": 1, "kind": "life"},
		{"id": "walk", "text": "起来走动 5 分钟", "goal": 1, "kind": "life"},
		{"id": "stretch", "text": "伸个懒腰，放松肩膀", "goal": 1, "kind": "life"},
		{"id": "eyes", "text": "看看远处，让眼睛休息一分钟", "goal": 1, "kind": "life"},
		{"id": "tidy", "text": "整理一下桌面", "goal": 1, "kind": "life"},
		{"id": "early", "text": "今晚 12 点前睡觉", "goal": 1, "kind": "life"},
		{"id": "fruit", "text": "吃一份水果", "goal": 1, "kind": "life"},
	],
}

func setup(a) -> void:
	app = a
	rng.randomize()

func today() -> String:
	return Time.get_date_string_from_system()

func data() -> Dictionary:
	var d: Dictionary = app.store.tasks
	return d

func ensure_today() -> void:
	var d := data()
	var td := today()
	if String(d.get("date", "")) == td and d.has("list"):
		return
	# 连续天数
	var last := String(d.get("date", ""))
	var all_done := bool(d.get("all_done", false))
	var streak := int(d.get("streak", 0))
	if last != "":
		var yday := Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_system()) - 86400)
		if last == yday and all_done:
			pass
		elif last != td:
			streak = 0 if last != yday else streak
	var lst: Array = []
	for grp in ["interact", "fun", "life"]:
		var pool: Array = POOL[grp]
		var it: Dictionary = pool[rng.randi() % pool.size()].duplicate()
		it["done"] = false
		it["n"] = 0
		lst.append(it)
	d.date = td
	d.list = lst
	d.all_done = false
	d.streak = streak
	app.store.save_tasks()

func list() -> Array:
	ensure_today()
	return data().get("list", [])

func label(it: Dictionary, name: String) -> String:
	return String(it.text).replace("{n}", name)

func progress(kind: String, amount := 1) -> void:
	ensure_today()
	var changed := false
	for it in data().list:
		if it.done or String(it.kind) != kind:
			continue
		it.n = int(it.n) + amount
		changed = true
		if int(it.n) >= int(it.goal):
			_finish(it)
	if changed:
		app.store.save_tasks()

func complete(id: String) -> void:
	ensure_today()
	for it in data().list:
		if String(it.id) == id and not it.done:
			it.n = it.goal
			_finish(it)
	app.store.save_tasks()

func add_custom(text: String) -> void:
	ensure_today()
	var lst: Array = data().list
	lst.append({"id": "ai%d" % (randi() % 100000), "text": text, "goal": 1, "kind": "life", "done": false, "n": 0, "ai": true})
	app.store.save_tasks()

func _finish(it: Dictionary) -> void:
	it.done = true
	var d := data()
	var all := true
	for x in d.list:
		if not x.done:
			all = false
	if all and not bool(d.get("all_done", false)):
		d.all_done = true
		d.streak = int(d.get("streak", 0)) + 1
	task_done.emit(it)

func streak() -> int:
	ensure_today()
	return int(data().get("streak", 0))

func done_count() -> Array:
	var lst := list()
	var n := 0
	for it in lst:
		if it.done:
			n += 1
	return [n, lst.size()]
