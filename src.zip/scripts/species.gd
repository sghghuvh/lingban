extends RefCounted
# 灵伴：外形 / 性格的数据表、规范化、离线生成。
# 伙伴的一切都由一个 spec 字典描述（可以 AI 生成，也可以离线按关键词生成）。

const PLANS := ["humanoid", "animal", "plant", "object", "blob"]
const HEAD_SHAPES := ["round", "oval", "wide", "square", "heart"]
const BODY_SHAPES := ["round", "slim", "chubby", "tall", "square", "pear"]
const PATTERNS := ["none", "stripes", "dots", "belly", "star", "heart", "scales", "plaid"]
const EYE_STYLES := ["round", "anime", "sleepy", "cat", "dot", "sparkle", "sharp", "button", "gentle"]
const MOUTHS := ["smile", "cat", "fang", "small", "beak", "none"]
const BROWS := ["normal", "thick", "thin", "none"]
const HAIRS := ["none", "short", "long", "bob", "twintails", "ponytail", "spiky", "bun", "messy", "curly", "side", "fluffy"]
const EARS := ["none", "human", "cat", "dog", "fox", "rabbit", "bear", "elf", "mouse", "floppy", "fin"]
const TAILS := ["none", "cat", "fox", "dog", "rabbit", "dragon", "fluffy", "devil", "fish", "squirrel"]
const HORNS := ["none", "small", "curved", "unicorn", "antlers", "devil"]
const WINGS := ["none", "bird", "bat", "fairy", "angel", "butterfly"]
const HATS := ["none", "cap", "beret", "witch", "crown", "bow", "flower", "tophat", "beanie", "headphones", "halo", "leaf"]
const GLASSES := ["none", "round", "square", "sun", "monocle"]
const NECKS := ["none", "scarf", "bowtie", "collar", "necklace", "bell", "tie"]
const OUTFITS := ["none", "tshirt", "dress", "hoodie", "suit", "robe", "armor", "overalls", "kimono", "apron", "sweater"]
const OBJECT_KINDS := ["mug", "phone", "book", "lamp", "box", "ball", "star", "heart", "cloud", "robot", "teapot", "cake", "potato", "rock", "gem", "bottle", "toast", "pudding"]
const PLANT_KINDS := ["flower", "sprout", "cactus", "mushroom", "tree", "sunflower", "leafy", "tulip"]
const BLOB_KINDS := ["slime", "ghost", "spirit", "fish", "jelly", "marshmallow"]
const ANIMAL_KINDS := ["cat", "dog", "fox", "rabbit", "bear", "panda", "mouse", "hamster", "dragon", "bird", "penguin", "owl", "wolf", "tiger", "lion", "sheep", "deer", "pig", "cow", "frog", "monkey", "koala", "raccoon", "squirrel", "dino", "duck", "chick"]
const AURAS := ["none", "sparkle", "hearts", "glow", "snow", "fire", "notes", "bubbles", "petals"]
const EXTRAS := ["freckles", "whiskers", "snout", "beak", "fangs", "blush", "antenna", "scar", "star_mark", "mole", "bandage", "eyepatch", "panda_patches", "beard", "mask", "spots", "stripes_face"]
const MATERIALS := ["soft", "fur", "shiny", "metal", "glass", "wood", "stone"]
const EMOTIONS := ["neutral", "happy", "excited", "love", "shy", "sad", "angry", "surprised", "thinking", "sleepy", "smug", "scared"]
const GESTURES := ["none", "wave", "nod", "shake", "jump", "dance", "spin", "bow", "clap", "think", "shrug", "hug", "point", "stretch", "sleep", "cheer", "pout", "sit"]
const ARCHETYPES := ["gentle", "genki", "tsundere", "cool", "shy", "playful", "lazy", "wise"]
const ZONES := ["head", "face", "body", "hand", "tail", "spam", "carry", "drop", "wake"]

const EMO_CN := {"neutral": "平静", "happy": "开心", "excited": "兴奋", "love": "喜欢", "shy": "害羞", "sad": "难过", "angry": "生气", "surprised": "惊讶", "thinking": "思考", "sleepy": "困", "smug": "得意", "scared": "害怕"}
const ARCH_CN := {"gentle": "温柔", "genki": "元气", "tsundere": "傲娇", "cool": "高冷", "shy": "害羞", "playful": "调皮", "lazy": "慵懒", "wise": "沉稳睿智"}

# 颜色词（越具体的放越前面，避免“天蓝”被“蓝”抢先）
const COLOR_WORDS := [
	["天蓝", "#7cc4f0"], ["浅蓝", "#9fd3f5"], ["深蓝", "#2f4f8f"], ["藏青", "#2b3a67"], ["湖蓝", "#3aa6b9"],
	["浅粉", "#f9c6d6"], ["玫红", "#d6336c"], ["酒红", "#8e2c48"], ["橘红", "#ef6c43"],
	["墨绿", "#2f6b4f"], ["薄荷", "#98e2c6"], ["草绿", "#7cc35a"], ["浅紫", "#c7a8f0"], ["深紫", "#5b3a8c"],
	["奶油", "#f6e7c8"], ["咖啡", "#7a5236"], ["巧克力", "#5b3a29"], ["米白", "#f3ead7"], ["银白", "#dde1ea"],
	["金黄", "#f2c14e"], ["柠檬", "#f7e463"], ["彩虹", "#ff8fab"],
	["红", "#e8505b"], ["粉", "#f497b6"], ["橙", "#f39c4a"], ["橘", "#f39c4a"], ["黄", "#f4d35e"], ["金", "#e9c46a"],
	["绿", "#6cc070"], ["青", "#4fd1c5"], ["蓝", "#4a90e2"], ["紫", "#9b6ddf"], ["黑", "#2d2a32"], ["白", "#f5f3ef"],
	["灰", "#9aa0ac"], ["银", "#c8ccd6"], ["棕", "#8b5e3c"], ["褐", "#8b5e3c"], ["米", "#efe0c2"],
	["red", "#e8505b"], ["pink", "#f497b6"], ["orange", "#f39c4a"], ["yellow", "#f4d35e"], ["gold", "#e9c46a"],
	["green", "#6cc070"], ["cyan", "#4fd1c5"], ["blue", "#4a90e2"], ["purple", "#9b6ddf"], ["black", "#2d2a32"],
	["white", "#f5f3ef"], ["gray", "#9aa0ac"], ["grey", "#9aa0ac"], ["silver", "#c8ccd6"], ["brown", "#8b5e3c"],
]
const NAMED_COLORS := [
	["红色", Color("#e8505b")], ["粉色", Color("#f497b6")], ["橙色", Color("#f39c4a")], ["黄色", Color("#f4d35e")],
	["绿色", Color("#6cc070")], ["青色", Color("#4fd1c5")], ["蓝色", Color("#4a90e2")], ["紫色", Color("#9b6ddf")],
	["黑色", Color("#2d2a32")], ["白色", Color("#f5f3ef")], ["灰色", Color("#9aa0ac")], ["棕色", Color("#8b5e3c")],
	["米色", Color("#efe0c2")], ["深蓝", Color("#2f4f8f")], ["浅蓝", Color("#9fd3f5")], ["金色", Color("#e9c46a")],
	["肤色", Color("#ffe0c8")], ["墨绿", Color("#2f6b4f")], ["酒红", Color("#8e2c48")], ["浅紫", Color("#c7a8f0")],
]

# ------------------------------------------------------------------ 关键词表（离线生成用）
# 每项：[关键词列表, 覆盖字段]
const KW_HUMAN_MOD := [
	[["猫娘", "猫耳", "catgirl", "neko", "猫男", "猫系少"], {"plan": "humanoid", "kind": "catfolk", "ears": "cat", "tail": "cat"}],
	[["狐娘", "狐耳", "狐狸娘", "foxgirl", "狐妖"], {"plan": "humanoid", "kind": "foxfolk", "ears": "fox", "tail": "fox"}],
	[["兔娘", "兔耳", "兔女郎", "bunnygirl"], {"plan": "humanoid", "kind": "bunnyfolk", "ears": "rabbit", "tail": "rabbit"}],
	[["犬娘", "狗耳", "犬耳", "狼耳", "狼人", "doggirl"], {"plan": "humanoid", "kind": "dogfolk", "ears": "dog", "tail": "fluffy"}],
	[["龙娘", "龙女", "龙人"], {"plan": "humanoid", "kind": "dragonfolk", "horns": "curved", "tail": "dragon", "wings": "bat"}],
	[["天使", "angel"], {"plan": "humanoid", "kind": "angel", "wings": "angel", "hat": "halo"}],
	[["恶魔", "魅魔", "小恶魔", "devil", "demon"], {"plan": "humanoid", "kind": "devil", "horns": "devil", "tail": "devil", "wings": "bat"}],
	[["精灵族", "精灵耳", "elf", "精灵少女", "精灵公主"], {"plan": "humanoid", "kind": "elf", "ears": "elf"}],
	[["吸血鬼", "vampire"], {"plan": "humanoid", "kind": "vampire", "mouth": "fang", "neck": "collar", "outfit": "suit"}],
	[["魔法少女", "魔女", "巫师", "女巫", "法师", "魔法师", "witch", "wizard", "mage"], {"plan": "humanoid", "kind": "witch", "hat": "witch", "outfit": "robe"}],
	[["骑士", "战士", "勇者", "knight", "warrior"], {"plan": "humanoid", "kind": "knight", "outfit": "armor"}],
	[["女仆", "maid"], {"plan": "humanoid", "kind": "maid", "outfit": "apron", "hat": "bow"}],
	[["公主", "princess"], {"plan": "humanoid", "kind": "princess", "hat": "crown", "outfit": "dress"}],
	[["王子", "国王", "prince", "king"], {"plan": "humanoid", "kind": "prince", "hat": "crown", "outfit": "suit"}],
	[["忍者", "ninja"], {"plan": "humanoid", "kind": "ninja", "extras": ["mask"], "outfit": "kimono"}],
	[["学生", "同学", "student", "学霸"], {"plan": "humanoid", "kind": "student", "outfit": "suit", "neck": "tie"}],
	[["医生", "护士", "doctor", "nurse"], {"plan": "humanoid", "kind": "doctor", "outfit": "robe"}],
	[["厨师", "chef"], {"plan": "humanoid", "kind": "chef", "outfit": "apron"}],
	[["歌手", "偶像", "idol", "singer"], {"plan": "humanoid", "kind": "idol", "hat": "headphones", "aura": "notes"}],
	[["程序员", "极客", "programmer", "hacker"], {"plan": "humanoid", "kind": "coder", "outfit": "hoodie", "glasses": "square"}],
]
const KW_HUMAN := [
	[["老奶奶", "奶奶", "婆婆", "外婆", "grandma"], {"plan": "humanoid", "kind": "grandma", "hair": "bun", "hair_c": "#e8e6e3", "glasses": "round", "outfit": "sweater", "gender": "female", "age": "old"}],
	[["老爷爷", "爷爷", "老头", "大爷", "外公", "老人", "grandpa", "old man"], {"plan": "humanoid", "kind": "grandpa", "hair": "short", "hair_c": "#e8e6e3", "extras": ["beard"], "glasses": "round", "outfit": "sweater", "gender": "male", "age": "old"}],
	[["大叔", "叔叔", "uncle"], {"plan": "humanoid", "kind": "uncle", "hair": "short", "extras": ["beard"], "gender": "male", "age": "adult"}],
	[["御姐", "阿姨", "女士"], {"plan": "humanoid", "kind": "lady", "hair": "long", "gender": "female", "age": "adult"}],
	[["少女", "女孩", "女生", "姐姐", "妹妹", "女朋友", "女友", "女儿", "girl", "woman", "lady", "她"], {"plan": "humanoid", "kind": "girl", "hair": "long", "gender": "female"}],
	[["少年", "男孩", "男生", "哥哥", "弟弟", "男朋友", "男友", "儿子", "boy", "man", "guy"], {"plan": "humanoid", "kind": "boy", "hair": "short", "gender": "male"}],
	[["小孩", "宝宝", "幼儿", "小朋友", "kid", "child", "baby"], {"plan": "humanoid", "kind": "kid", "hair": "fluffy", "gender": "neutral", "age": "child", "size": 0.85}],
	[["人类", "人", "human", "person"], {"plan": "humanoid", "kind": "human"}],
]
const KW_ANIMAL := [
	[["熊猫", "panda"], {"kind": "panda", "ears": "bear", "tail": "none", "main": "#f5f3ef", "second": "#2d2a32", "extras": ["panda_patches"], "eyes": "dot"}],
	[["树袋熊", "考拉", "koala"], {"kind": "koala", "ears": "bear", "main": "#a7adb8", "second": "#e9e6e1", "extras": ["snout"]}],
	[["浣熊", "raccoon"], {"kind": "raccoon", "ears": "bear", "tail": "fluffy", "main": "#8f8f98", "second": "#e9e6e1", "extras": ["panda_patches"]}],
	[["仓鼠", "hamster"], {"kind": "hamster", "ears": "mouse", "tail": "none", "main": "#f2b56b", "second": "#fff4e2", "body": "chubby"}],
	[["柴犬", "shiba"], {"kind": "dog", "ears": "dog", "tail": "fluffy", "main": "#e8954a", "second": "#fff4e2", "extras": ["snout"]}],
	[["哈士奇", "husky"], {"kind": "wolf", "ears": "dog", "tail": "fluffy", "main": "#8f96a3", "second": "#f5f3ef", "eye": "#5fb2ff", "extras": ["snout"]}],
	[["企鹅", "penguin"], {"kind": "penguin", "ears": "none", "tail": "none", "main": "#2f3445", "second": "#f5f3ef", "mouth": "beak", "wings": "none", "extras": ["beak"]}],
	[["猫头鹰", "owl"], {"kind": "owl", "ears": "none", "tail": "none", "main": "#9b7653", "second": "#efe0c2", "mouth": "beak", "wings": "bird", "eyes": "round", "extras": ["beak"]}],
	[["小鸡", "鸡仔", "chick"], {"kind": "chick", "ears": "none", "tail": "none", "main": "#f7d94c", "mouth": "beak", "wings": "bird", "extras": ["beak"], "size": 0.85}],
	[["鸭", "duck"], {"kind": "duck", "ears": "none", "tail": "none", "main": "#f7e07a", "mouth": "beak", "wings": "bird", "extras": ["beak"]}],
	[["恐龙", "dino", "暴龙"], {"kind": "dino", "ears": "none", "tail": "dragon", "main": "#7cc35a", "second": "#e7f0b7", "pattern": "belly", "horns": "none", "mouth": "fang"}],
	[["龙", "dragon"], {"kind": "dragon", "ears": "fin", "tail": "dragon", "horns": "curved", "wings": "bat", "main": "#6c8fd8", "second": "#f2e6c9", "pattern": "belly"}],
	[["鸟", "鹦鹉", "麻雀", "bird", "parrot"], {"kind": "bird", "ears": "none", "tail": "none", "mouth": "beak", "wings": "bird", "extras": ["beak"]}],
	[["猫", "喵", "cat", "kitty", "kitten"], {"kind": "cat", "ears": "cat", "tail": "cat", "extras": ["whiskers"], "mouth": "cat"}],
	[["狐", "fox"], {"kind": "fox", "ears": "fox", "tail": "fox", "main": "#ef8a3c", "second": "#fff4e2", "extras": ["snout"]}],
	[["狼", "wolf"], {"kind": "wolf", "ears": "dog", "tail": "fluffy", "main": "#8f96a3", "second": "#e9e6e1", "extras": ["snout"]}],
	[["狗", "犬", "汪", "dog", "puppy", "doggo"], {"kind": "dog", "ears": "floppy", "tail": "dog", "extras": ["snout"]}],
	[["兔", "rabbit", "bunny"], {"kind": "rabbit", "ears": "rabbit", "tail": "rabbit", "main": "#f5f3ef", "second": "#f9c6d6"}],
	[["熊", "bear"], {"kind": "bear", "ears": "bear", "tail": "none", "main": "#9b6b47", "second": "#e7cfae", "extras": ["snout"]}],
	[["老鼠", "鼠", "mouse"], {"kind": "mouse", "ears": "mouse", "tail": "none", "main": "#b8bcc8", "second": "#f9c6d6", "extras": ["whiskers"]}],
	[["老虎", "虎", "tiger"], {"kind": "tiger", "ears": "cat", "tail": "cat", "main": "#f0953a", "second": "#fff4e2", "pattern": "stripes", "extras": ["whiskers", "stripes_face"]}],
	[["狮", "lion"], {"kind": "lion", "ears": "bear", "tail": "cat", "main": "#e7b35e", "hair": "fluffy", "hair_c": "#b36b2c", "extras": ["snout"]}],
	[["羊", "sheep", "lamb"], {"kind": "sheep", "ears": "floppy", "tail": "none", "main": "#f5f3ef", "hair": "curly", "hair_c": "#ffffff", "horns": "curved", "skin": "#e9d6c4"}],
	[["鹿", "deer"], {"kind": "deer", "ears": "floppy", "tail": "rabbit", "main": "#c58b52", "second": "#fff4e2", "horns": "antlers", "pattern": "dots"}],
	[["猪", "pig", "piggy"], {"kind": "pig", "ears": "floppy", "tail": "none", "main": "#f7b6c2", "extras": ["snout"]}],
	[["奶牛", "牛", "cow"], {"kind": "cow", "ears": "floppy", "tail": "none", "main": "#f5f3ef", "second": "#2d2a32", "horns": "small", "pattern": "dots", "extras": ["snout"]}],
	[["青蛙", "蛙", "frog"], {"kind": "frog", "ears": "none", "tail": "none", "main": "#7cc35a", "second": "#e7f0b7", "eyes": "round", "mouth": "smile", "pattern": "belly"}],
	[["猴", "monkey"], {"kind": "monkey", "ears": "human", "tail": "squirrel", "main": "#9b6b47", "second": "#f1d2b0"}],
	[["松鼠", "squirrel"], {"kind": "squirrel", "ears": "mouse", "tail": "squirrel", "main": "#c8743c", "second": "#fff4e2"}],
]
const KW_PLANT := [
	[["向日葵", "sunflower"], "sunflower"], [["郁金香", "tulip"], "tulip"], [["仙人掌", "多肉", "cactus", "succulent"], "cactus"],
	[["蘑菇", "菌", "mushroom"], "mushroom"], [["盆栽", "树", "tree", "bonsai"], "tree"], [["豆芽", "嫩芽", "发芽", "芽", "sprout", "种子"], "sprout"],
	[["龟背竹", "绿萝", "叶子", "叶", "leaf", "plant", "植物", "草"], "leafy"], [["花", "玫瑰", "樱花", "flower", "rose"], "flower"],
]
const KW_OBJECT := [
	[["马克杯", "杯子", "杯", "咖啡", "mug", "cup", "coffee"], "mug"], [["手机", "phone", "电话"], "phone"],
	[["书", "book", "笔记本"], "book"], [["台灯", "灯", "lamp", "灯泡"], "lamp"], [["纸箱", "箱", "盒", "box"], "box"],
	[["足球", "篮球", "皮球", "球", "ball"], "ball"], [["星星", "星", "star"], "star"], [["爱心", "心脏", "heart"], "heart"],
	[["云朵", "云", "cloud"], "cloud"], [["机器人", "机械", "robot", "android", "bot"], "robot"], [["茶壶", "teapot", "壶"], "teapot"],
	[["蛋糕", "cake"], "cake"], [["土豆", "马铃薯", "potato"], "potato"], [["石头", "岩石", "rock", "stone"], "rock"],
	[["宝石", "水晶", "钻石", "gem", "crystal"], "gem"], [["瓶子", "瓶", "可乐", "bottle"], "bottle"], [["吐司", "面包", "toast", "bread"], "toast"],
	[["布丁", "pudding"], "pudding"],
]
const KW_BLOB := [
	[["史莱姆", "slime", "果冻", "jelly bean"], "slime"], [["幽灵", "鬼魂", "鬼", "ghost"], "ghost"],
	[["小精灵", "元素", "灵体", "spirit", "火精灵", "wisp"], "spirit"], [["鱼", "fish", "金鱼"], "fish"],
	[["水母", "jellyfish"], "jelly"], [["棉花糖", "团子", "麻薯", "marshmallow", "mochi"], "marshmallow"],
]
const KW_PERSONA := [
	[["傲娇", "嘴硬", "tsundere"], {"sass": 0.85, "warm": 0.55, "arch": "tsundere", "desc": "傲娇，嘴上不饶人，心里其实很在乎你"}],
	[["温柔", "体贴", "暖", "gentle", "kind"], {"warm": 0.92, "sass": 0.08, "arch": "gentle", "desc": "温柔体贴，说话软软的"}],
	[["元气", "活泼", "开朗", "阳光", "热情", "energetic", "cheerful"], {"energy": 0.95, "extravert": 0.9, "arch": "genki", "desc": "元气满满，永远充满活力"}],
	[["高冷", "冷酷", "冷淡", "cool", "冷静"], {"extravert": 0.2, "warm": 0.35, "arch": "cool", "desc": "高冷寡言，但关键时刻很可靠"}],
	[["害羞", "内向", "胆小", "shy"], {"extravert": 0.2, "warm": 0.75, "arch": "shy", "desc": "害羞内向，熟了以后很黏人"}],
	[["毒舌", "吐槽"], {"sass": 0.92, "playful": 0.7, "arch": "tsundere", "desc": "毒舌爱吐槽，但刀子嘴豆腐心"}],
	[["调皮", "捣蛋", "淘气", "腹黑", "坏坏", "playful", "naughty"], {"playful": 0.92, "arch": "playful", "desc": "调皮捣蛋，喜欢逗你玩"}],
	[["懒", "慵懒", "佛系", "lazy"], {"energy": 0.15, "arch": "lazy", "desc": "慵懒佛系，能躺着绝不坐着"}],
	[["成熟", "稳重", "睿智", "智慧", "长者", "wise"], {"energy": 0.35, "warm": 0.75, "curious": 0.8, "arch": "wise", "desc": "成熟稳重，说话很有分寸"}],
	[["呆", "憨", "天然", "迷糊", "笨"], {"curious": 0.7, "playful": 0.6, "sass": 0.05, "desc": "有点呆萌迷糊，经常冒出奇怪的想法"}],
	[["话痨", "话多", "八卦"], {"extravert": 1.0, "desc": "话痨，什么都想跟你聊"}],
	[["中二"], {"playful": 0.85, "desc": "中二病，总觉得自己封印着强大的力量"}],
	[["聪明", "学霸", "博学", "smart"], {"curious": 0.95, "desc": "聪明博学，喜欢讲各种小知识"}],
	[["黏人", "粘人", "忠诚", "忠心", "loyal"], {"warm": 0.95, "independent": 0.15, "desc": "黏人又忠诚，一直陪着你"}],
	[["独立", "有主见", "independent"], {"independent": 0.92, "desc": "很有主见，不会什么都听你的"}],
	[["冷笑话", "幽默", "搞笑", "funny"], {"playful": 0.85, "desc": "幽默，最爱讲冷笑话"}],
]

# ------------------------------------------------------------------ 默认触碰台词（按性格原型）
const TOUCH_LINES := {
	"gentle": {
		"head": [["嗯……被摸头好安心。", "love"], ["你的手好暖和呀。", "happy"]],
		"face": [["怎么啦？我脸上有东西吗？", "surprised"], ["嘿嘿，戳到我啦。", "happy"]],
		"body": [["哎呀，好痒~", "shy"], ["要不要休息一下？", "happy"]],
		"hand": [["牵着手就不怕走丢了。", "love"], ["我在呢。", "happy"]],
		"tail": [["那、那里不能随便摸……", "shy"], ["轻一点哦。", "shy"]],
		"spam": [["好啦好啦，我知道你在啦。", "happy"], ["你今天是不是有点无聊呀？", "thinking"]],
		"carry": [["哇，要带我去哪里？", "surprised"], ["小心别摔着我哦。", "shy"]],
		"drop": [["谢谢你轻轻放下我。", "happy"], ["到啦~", "happy"]],
		"wake": [["唔……我刚才睡着了吗？", "sleepy"], ["早呀……", "sleepy"]],
	},
	"genki": {
		"head": [["嘿嘿！再摸一下！", "excited"], ["摸头充电完毕！", "happy"]],
		"face": [["哇！偷袭！", "surprised"], ["戳回去！嘿！", "excited"]],
		"body": [["哈哈哈好痒好痒！", "excited"], ["我可是很结实的！", "smug"]],
		"hand": [["击掌！耶！", "excited"], ["拉着我跑一圈吧！", "happy"]],
		"tail": [["尾巴摇起来啦！", "excited"], ["被抓到啦！", "surprised"]],
		"spam": [["哇啊啊别戳啦，我要晕啦！", "scared"], ["你是在给我按摩吗哈哈！", "excited"]],
		"carry": [["飞起来啦——！", "excited"], ["好高好高！", "excited"]],
		"drop": [["完美落地！", "smug"], ["再来一次！", "excited"]],
		"wake": [["我醒啦！今天也要元气满满！", "excited"], ["啊！我睡过头了吗？", "surprised"]],
	},
	"tsundere": {
		"head": [["哼，才、才没有很舒服呢……", "shy"], ["别以为摸摸头我就会原谅你！", "angry"]],
		"face": [["干嘛啦！不许戳！", "angry"], ["你、你看什么看！", "shy"]],
		"body": [["往哪摸呢！笨蛋！", "angry"], ["……就允许你一次。", "shy"]],
		"hand": [["只是怕你走丢才牵的！", "shy"], ["笨蛋，手这么凉。", "shy"]],
		"tail": [["喂！那里不行！", "angry"], ["再摸就咬你哦！", "angry"]],
		"spam": [["够了没有！再戳我就生气了！", "angry"], ["……你很闲是吧。", "smug"]],
		"carry": [["放、放我下来！", "shy"], ["哼，勉强让你抱一下。", "shy"]],
		"drop": [["哼，这还差不多。", "smug"], ["粗鲁！", "angry"]],
		"wake": [["吵死了……才没有在睡觉！", "angry"], ["哼，你终于想起我了？", "smug"]],
	},
	"cool": {
		"head": [["……随你。", "neutral"], ["还行吧。", "smug"]],
		"face": [["有事？", "neutral"], ["别闹。", "neutral"]],
		"body": [["……", "neutral"], ["你很无聊。", "smug"]],
		"hand": [["……走吧。", "neutral"], ["只此一次。", "shy"]],
		"tail": [["别碰。", "angry"], ["……", "shy"]],
		"spam": [["适可而止。", "angry"], ["你在测试我的耐心？", "smug"]],
		"carry": [["放下。", "neutral"], ["……我自己会走。", "neutral"]],
		"drop": [["嗯。", "neutral"], ["谢了。", "neutral"]],
		"wake": [["……我没睡。", "sleepy"], ["什么事。", "neutral"]],
	},
	"shy": {
		"head": [["唔、唔……谢谢……", "shy"], ["好、好害羞……", "shy"]],
		"face": [["呀！", "surprised"], ["脸、脸好烫……", "shy"]],
		"body": [["请、请不要这样……", "shy"], ["呜……", "scared"]],
		"hand": [["手……可以牵一下下。", "shy"], ["有你在就不怕了。", "love"]],
		"tail": [["那、那里很敏感……", "shy"], ["呜哇……", "scared"]],
		"spam": [["呜呜，我、我做错什么了吗……", "sad"], ["别、别戳了……", "scared"]],
		"carry": [["哇、哇啊……好高……", "scared"], ["别、别松手哦……", "shy"]],
		"drop": [["安、安全落地……", "shy"], ["谢谢……", "shy"]],
		"wake": [["对不起，我睡着了……", "shy"], ["唔……你来啦。", "shy"]],
	},
	"playful": {
		"head": [["再摸就要收费咯~", "smug"], ["嘿嘿，我是不是很可爱？", "smug"]],
		"face": [["抓到你的手指啦！", "excited"], ["略略略~", "smug"]],
		"body": [["哈哈，你猜我怕不怕痒？", "smug"], ["偷袭失败！", "smug"]],
		"hand": [["拉钩，不许反悔！", "happy"], ["抓住就不放啦~", "smug"]],
		"tail": [["尾巴攻击！", "excited"], ["想抓我尾巴？没门~", "smug"]],
		"spam": [["戳戳戳，那我也戳你！", "excited"], ["你是啄木鸟吗哈哈", "smug"]],
		"carry": [["哇哦，免费坐飞机！", "excited"], ["再高一点再高一点！", "excited"]],
		"drop": [["十分！满分落地！", "smug"], ["哼哼，帅吧？", "smug"]],
		"wake": [["我才没睡，我在装睡！", "smug"], ["你吵醒我了，要赔我一个笑话！", "smug"]],
	},
	"lazy": {
		"head": [["嗯……继续……", "sleepy"], ["好舒服……想睡了……", "sleepy"]],
		"face": [["别戳了，好麻烦……", "sleepy"], ["唔？", "sleepy"]],
		"body": [["哈欠……", "sleepy"], ["软软的吧……", "sleepy"]],
		"hand": [["牵着可以，但我不想走路……", "sleepy"], ["拉我起来……", "sleepy"]],
		"tail": [["……懒得动。", "sleepy"], ["随便摸吧……", "sleepy"]],
		"spam": [["……我装死了。", "sleepy"], ["好吵……", "angry"]],
		"carry": [["好耶，不用自己走了。", "happy"], ["就这样抱着吧……", "sleepy"]],
		"drop": [["啊，又要自己走了……", "sad"], ["……嗯。", "sleepy"]],
		"wake": [["再睡五分钟……", "sleepy"], ["……几点了？", "sleepy"]],
	},
	"wise": {
		"head": [["呵呵，好孩子。", "happy"], ["这把年纪还被摸头啊。", "happy"]],
		"face": [["嗯？有什么想问的吗？", "thinking"], ["呵呵。", "happy"]],
		"body": [["老骨头了，轻点。", "happy"], ["精神不错嘛。", "happy"]],
		"hand": [["来，慢慢走。", "happy"], ["你的手比我暖和。", "happy"]],
		"tail": [["哦？", "surprised"], ["年轻人真有活力。", "happy"]],
		"spam": [["别急，慢慢来。", "thinking"], ["心静一点。", "neutral"]],
		"carry": [["哎哟，慢点慢点。", "surprised"], ["好久没这么高了。", "happy"]],
		"drop": [["稳当。", "happy"], ["谢谢你啊。", "happy"]],
		"wake": [["打了个盹儿……", "sleepy"], ["人老了，容易困。", "sleepy"]],
	},
}
const GREET_LINES := {
	"gentle": ["你来啦，今天过得怎么样？", "欢迎回来，我一直在这里等你哦。"],
	"genki": ["哇！你来啦！今天要做什么好玩的？", "你终于来啦！我有好多话想跟你说！"],
	"tsundere": ["哼，你终于来了。我才没有在等你。", "……来了啊。随便坐吧。"],
	"cool": ["来了。", "嗯，你好。"],
	"shy": ["啊……你、你好。", "欢、欢迎回来……"],
	"playful": ["嘿！猜猜我刚刚在干嘛？", "哟~ 想我了吧？"],
	"lazy": ["唔……你来了啊……", "哈欠……欢迎……"],
	"wise": ["来啦，坐。", "今天也辛苦了。"],
}
const IDLE_LINES := {
	"gentle": ["今天有好好喝水吗？", "累了的话，就休息一会儿吧。", "我在想，你现在在做什么呢？"],
	"genki": ["好无聊啊！陪我玩嘛！", "我们来比赛谁先眨眼！", "今天有什么开心的事吗？快告诉我！"],
	"tsundere": ["……喂，你不打算理我了吗？", "我才没有觉得无聊呢。哼。", "笨蛋，记得按时吃饭。"],
	"cool": ["……", "在忙？", "需要帮忙就说。"],
	"shy": ["那个……你在忙吗？", "我、我可以跟你说说话吗？", "……我在这里哦。"],
	"playful": ["偷偷告诉你一个秘密……算了不告诉你~", "要不要听个冷笑话？", "我刚刚好像看到一只会飞的猪！"],
	"lazy": ["哈欠……好想睡觉……", "今天也什么都不想做呢……", "你也躺一会儿吧……"],
	"wise": ["休息是为了走更远的路。", "最近有什么烦心事吗？说出来会好受些。", "记得抬头看看窗外。"],
}
const JOKES := [
	"为什么企鹅只有肚子是白的？因为手短，只能洗到肚子。",
	"一个西瓜从楼上掉下来，它说了什么？我好甜（摔）呀！",
	"什么动物最爱问为什么？猪，因为它总是“为猪么”。",
	"有一天，番茄去约会，它羞红了脸。",
	"为什么数学书总是很忧郁？因为它有太多的问题。",
	"冰块最想做什么事？退伍，因为它当冰当太久了。",
]
const RIDDLES := [
	["什么东西越洗越脏？", "水"], ["什么东西有头没有脚？", "砖头"], ["什么门永远关不上？", "球门"],
	["什么东西你借了不用还？", "借光"], ["什么帽子不能戴？", "螺丝帽"],
]

# 默认喜好（按 kind）
const KIND_LIKES := {
	"cat": [["晒太阳", "小鱼干", "纸箱子"], ["洗澡", "吸尘器"]], "dog": [["散步", "飞盘", "被夸"], ["打雷", "独处"]],
	"fox": [["月亮", "油豆腐"], ["猎人"]], "rabbit": [["胡萝卜", "软垫子"], ["大声响"]], "bear": [["蜂蜜", "睡觉"], ["冬天被吵醒"]],
	"panda": [["竹子", "打滚"], ["早起"]], "dragon": [["宝石", "飞翔"], ["下雨天"]], "bird": [["唱歌", "种子"], ["猫"]],
	"plant": [["阳光", "浇水", "微风"], ["干旱", "被踩"]], "object": [["被好好使用", "干净"], ["被摔", "落灰"]],
	"blob": [["软乎乎的东西", "被轻轻戳"], ["太阳暴晒", "尖锐的东西"]], "humanoid": [["聊天", "甜点", "听歌"], ["无聊", "被冷落"]],
}

# ------------------------------------------------------------------ 默认 spec
static func default_spec() -> Dictionary:
	return {
		"v": 1, "name": "团子", "label": "软乎乎的小精灵", "plan": "blob", "kind": "marshmallow", "size": 1.0,
		"colors": {"main": "#f6e7c8", "second": "#fff7ea", "accent": "#f497b6", "skin": "#ffe0c8", "hair": "#5b4a3f", "eye": "#3a2f45", "line": ""},
		"head": {"shape": "round", "size": 1.0},
		"body": {"shape": "round", "pattern": "none"},
		"eyes": {"style": "round", "size": 1.0, "lashes": false},
		"mouth": "smile", "brows": "normal",
		"hair": {"style": "none"},
		"ears": "none", "tail": "none", "horns": "none", "wings": "none",
		"hat": "none", "glasses": "none", "neck": "none", "outfit": "none",
		"extras": ["blush"], "aura": "none", "material": "soft",
		"personality": {
			"archetype": "gentle", "desc": "温柔又有点调皮，喜欢陪你聊天",
			"traits": {"extravert": 0.6, "warm": 0.8, "playful": 0.55, "sass": 0.2, "independent": 0.45, "curious": 0.65, "energy": 0.6},
			"speech": "说话软软的，偶尔撒娇", "suffix": "", "catchphrases": ["嘿嘿"], "likes": ["软乎乎的东西", "听你说话"], "dislikes": ["被冷落"],
			"backstory": "从你手机的角落里诞生的小精灵。", "relation": "朋友", "call_user": "你",
		},
		"voice": {"gender": "female", "pitch": 1.25, "rate": 1.0, "api_voice": ""},
		"touch": {},
		"lines": {"greet": [], "idle": [], "bye": []},
	}

# ------------------------------------------------------------------ 规范化（任何来源的 spec 都过一遍，保证渲染器能画）
static func _pick(v, allowed: Array, dflt: String) -> String:
	var s := String(v).strip_edges().to_lower().replace(" ", "_").replace("-", "_")
	if s in allowed:
		return s
	var alias := {"twin_tails": "twintails", "twintail": "twintails", "pony": "ponytail", "pony_tail": "ponytail", "sunglasses": "sun",
		"glass": "round", "kitty": "cat", "bunny": "rabbit", "puppy": "dog", "cup": "mug", "coffee": "mug", "bread": "toast",
		"crystal": "gem", "stone": "rock", "smartphone": "phone", "angelic": "angel", "demon": "devil", "fairy_wings": "fairy",
		"curved_horns": "curved", "deer": "antlers", "flower_crown": "flower", "headphone": "headphones", "bow_tie": "bowtie",
		"t_shirt": "tshirt", "shirt": "tshirt", "jacket": "hoodie", "uniform": "suit", "gown": "dress", "skirt": "dress",
		"cute": "round", "big": "anime", "closed": "gentle", "happy": "gentle", "slit": "cat", "smiling": "smile", "open": "smile"}
	if alias.has(s) and alias[s] in allowed:
		return alias[s]
	return dflt

static func _col(v, dflt: String) -> String:
	var s := String(v).strip_edges()
	if s != "" and not s.begins_with("#") and s.length() in [3, 6, 8] and s.is_valid_hex_number():
		s = "#" + s
	if s != "" and Color.html_is_valid(s):
		return "#" + Color.html(s).to_html(false)
	# 也接受颜色词
	for cw in COLOR_WORDS:
		if s.find(cw[0]) >= 0:
			return cw[1]
	return dflt

static func _num(v, lo: float, hi: float, dflt: float) -> float:
	if typeof(v) in [TYPE_INT, TYPE_FLOAT]:
		return clampf(float(v), lo, hi)
	if typeof(v) == TYPE_STRING and String(v).is_valid_float():
		return clampf(String(v).to_float(), lo, hi)
	return dflt

static func _strs(v, maxn: int, maxlen := 24) -> Array:
	var out: Array = []
	if typeof(v) == TYPE_STRING and String(v) != "":
		v = String(v).replace("，", ",").replace("、", ",").split(",", false)
	if typeof(v) in [TYPE_ARRAY, TYPE_PACKED_STRING_ARRAY]:
		for x in v:
			var s := String(x).strip_edges().left(maxlen)
			if s != "" and not s in out:
				out.append(s)
			if out.size() >= maxn:
				break
	return out

static func normalize(src) -> Dictionary:
	var d := default_spec()
	if typeof(src) != TYPE_DICTIONARY:
		return d
	var s: Dictionary = src
	d.name = String(s.get("name", d.name)).strip_edges().left(12)
	if d.name == "":
		d.name = "团子"
	d.label = String(s.get("label", d.label)).strip_edges().left(24)
	d.plan = _pick(s.get("plan", d.plan), PLANS, "humanoid")
	var kind := String(s.get("kind", "")).strip_edges().to_lower()
	match d.plan:
		"object":
			d.kind = _pick(kind, OBJECT_KINDS, "mug")
		"plant":
			d.kind = _pick(kind, PLANT_KINDS, "sprout")
		"blob":
			d.kind = _pick(kind, BLOB_KINDS, "slime")
		"animal":
			d.kind = kind if kind != "" else "cat"
		_:
			d.kind = kind if kind != "" else "human"
	d.size = _num(s.get("size", 1.0), 0.7, 1.3, 1.0)
	var c: Dictionary = s.get("colors", {}) if typeof(s.get("colors", {})) == TYPE_DICTIONARY else {}
	for k in d.colors.keys():
		d.colors[k] = _col(c.get(k, ""), d.colors[k])
	var hd = s.get("head", {})
	if typeof(hd) == TYPE_DICTIONARY:
		d.head.shape = _pick(hd.get("shape", "round"), HEAD_SHAPES, "round")
		d.head.size = _num(hd.get("size", 1.0), 0.8, 1.25, 1.0)
	var bd = s.get("body", {})
	if typeof(bd) == TYPE_DICTIONARY:
		d.body.shape = _pick(bd.get("shape", "round"), BODY_SHAPES, "round")
		d.body.pattern = _pick(bd.get("pattern", "none"), PATTERNS, "none")
	var ey = s.get("eyes", {})
	if typeof(ey) == TYPE_DICTIONARY:
		d.eyes.style = _pick(ey.get("style", "round"), EYE_STYLES, "round")
		d.eyes.size = _num(ey.get("size", 1.0), 0.7, 1.4, 1.0)
		d.eyes.lashes = bool(ey.get("lashes", false))
	elif typeof(ey) == TYPE_STRING:
		d.eyes.style = _pick(ey, EYE_STYLES, "round")
	d.mouth = _pick(s.get("mouth", "smile"), MOUTHS, "smile")
	d.brows = _pick(s.get("brows", "normal"), BROWS, "normal")
	var hr = s.get("hair", {})
	if typeof(hr) == TYPE_DICTIONARY:
		d.hair.style = _pick(hr.get("style", "none"), HAIRS, "none")
	elif typeof(hr) == TYPE_STRING:
		d.hair.style = _pick(hr, HAIRS, "none")
	d.ears = _pick(s.get("ears", "none"), EARS, "none")
	d.tail = _pick(s.get("tail", "none"), TAILS, "none")
	d.horns = _pick(s.get("horns", "none"), HORNS, "none")
	d.wings = _pick(s.get("wings", "none"), WINGS, "none")
	d.hat = _pick(s.get("hat", "none"), HATS, "none")
	d.glasses = _pick(s.get("glasses", "none"), GLASSES, "none")
	d.neck = _pick(s.get("neck", "none"), NECKS, "none")
	d.outfit = _pick(s.get("outfit", "none"), OUTFITS, "none")
	var ex: Array = []
	for e in _strs(s.get("extras", []), 8):
		var e2 := String(e).to_lower()
		if e2 in EXTRAS and not e2 in ex:
			ex.append(e2)
	d.extras = ex
	d.aura = _pick(s.get("aura", "none"), AURAS, "none")
	d.material = _pick(s.get("material", "soft"), MATERIALS, "soft")
	# 性格
	var p = s.get("personality", {})
	if typeof(p) == TYPE_DICTIONARY:
		var tr = p.get("traits", {})
		if typeof(tr) == TYPE_DICTIONARY:
			for k in d.personality.traits.keys():
				d.personality.traits[k] = _num(tr.get(k, d.personality.traits[k]), 0.0, 1.0, d.personality.traits[k])
		d.personality.desc = String(p.get("desc", d.personality.desc)).strip_edges().left(80)
		d.personality.speech = String(p.get("speech", d.personality.speech)).strip_edges().left(80)
		d.personality.suffix = String(p.get("suffix", "")).strip_edges().left(4)
		d.personality.catchphrases = _strs(p.get("catchphrases", []), 4, 16)
		d.personality.likes = _strs(p.get("likes", []), 6, 16)
		d.personality.dislikes = _strs(p.get("dislikes", []), 6, 16)
		d.personality.backstory = String(p.get("backstory", d.personality.backstory)).strip_edges().left(160)
		d.personality.relation = String(p.get("relation", "朋友")).strip_edges().left(12)
		d.personality.call_user = String(p.get("call_user", "你")).strip_edges().left(8)
		if d.personality.call_user == "":
			d.personality.call_user = "你"
		var ar := String(p.get("archetype", "")).to_lower()
		d.personality.archetype = ar if ar in ARCHETYPES else _calc_arch(d.personality.traits)
	# 声音
	var vo = s.get("voice", {})
	if typeof(vo) == TYPE_DICTIONARY:
		d.voice.gender = _pick(vo.get("gender", "female"), ["female", "male", "neutral"], "neutral")
		d.voice.pitch = _num(vo.get("pitch", 1.0), 0.5, 2.0, 1.0)
		d.voice.rate = _num(vo.get("rate", 1.0), 0.6, 1.6, 1.0)
		d.voice.api_voice = String(vo.get("api_voice", "")).strip_edges().left(64)
	# 触碰台词
	var tc = s.get("touch", {})
	if typeof(tc) == TYPE_DICTIONARY:
		for z in ZONES:
			var arr = tc.get(z, [])
			var lines: Array = []
			if typeof(arr) == TYPE_ARRAY:
				for it in arr:
					if typeof(it) == TYPE_ARRAY and it.size() >= 1:
						var em := String(it[1]) if it.size() > 1 else "happy"
						lines.append([String(it[0]).left(40), em if em in EMOTIONS else "happy"])
					elif typeof(it) == TYPE_DICTIONARY:
						var em2 := String(it.get("emotion", "happy"))
						lines.append([String(it.get("say", it.get("text", ""))).left(40), em2 if em2 in EMOTIONS else "happy"])
					elif typeof(it) == TYPE_STRING:
						lines.append([String(it).left(40), "happy"])
			lines = lines.filter(func(l): return String(l[0]) != "")
			if not lines.is_empty():
				d.touch[z] = lines.slice(0, 4)
	var ln = s.get("lines", {})
	if typeof(ln) == TYPE_DICTIONARY:
		for k in ["greet", "idle", "bye"]:
			d.lines[k] = _strs(ln.get(k, []), 5, 50)
	return d

static func _calc_arch(t: Dictionary) -> String:
	if t.sass >= 0.65 and t.warm >= 0.3:
		return "tsundere"
	if t.extravert <= 0.3 and t.warm <= 0.45:
		return "cool"
	if t.extravert <= 0.35:
		return "shy"
	if t.energy <= 0.25:
		return "lazy"
	if t.energy >= 0.75 and t.extravert >= 0.65:
		return "genki"
	if t.playful >= 0.7:
		return "playful"
	if t.warm >= 0.65:
		return "gentle"
	return "playful"

static func archetype(spec: Dictionary) -> String:
	var a := String(spec.get("personality", {}).get("archetype", "gentle"))
	return a if a in ARCHETYPES else "gentle"

# 取一句触碰台词：优先用伙伴自己的（AI 生成的），否则用性格原型默认台词
static func touch_line(spec: Dictionary, zone: String, rng: RandomNumberGenerator) -> Array:
	var own = spec.get("touch", {}).get(zone, [])
	if typeof(own) == TYPE_ARRAY and not own.is_empty() and rng.randf() < 0.85:
		var it: Array = own[rng.randi() % own.size()]
		return [_suffix(spec, String(it[0]), rng), String(it[1])]
	var tbl: Dictionary = TOUCH_LINES.get(archetype(spec), TOUCH_LINES.gentle)
	var arr: Array = tbl.get(zone, tbl.head)
	var pick: Array = arr[rng.randi() % arr.size()]
	return [_suffix(spec, String(pick[0]), rng), String(pick[1])]

static func _suffix(spec: Dictionary, text: String, rng: RandomNumberGenerator) -> String:
	var suf := String(spec.get("personality", {}).get("suffix", ""))
	if suf == "":
		return text
	var t := text
	var tail := ""
	while t.length() > 0 and t[t.length() - 1] in "。！？~…!?.，,":
		tail = t[t.length() - 1] + tail
		t = t.substr(0, t.length() - 1)
	if t.ends_with(suf) or t.find(suf + "，") >= 0 or rng.randf() < 0.35:
		return text
	return t + suf + tail

static func line_from(spec: Dictionary, key: String, rng: RandomNumberGenerator) -> String:
	var own: Array = spec.get("lines", {}).get(key, [])
	if not own.is_empty() and rng.randf() < 0.8:
		return _suffix(spec, String(own[rng.randi() % own.size()]), rng)
	var tbl: Dictionary = GREET_LINES if key == "greet" else IDLE_LINES
	if key == "bye":
		return _suffix(spec, ["路上小心哦。", "下次见！", "早点回来哦。"][rng.randi() % 3], rng)
	var arr: Array = tbl.get(archetype(spec), tbl.gentle)
	return _suffix(spec, String(arr[rng.randi() % arr.size()]), rng)

static func color_name(hex: String) -> String:
	var c := Color(hex)
	var best := "彩色"
	var bd := 99.0
	for nc in NAMED_COLORS:
		var o: Color = nc[1]
		var dd := Vector3(c.r - o.r, c.g - o.g, c.b - o.b).length()
		if dd < bd:
			bd = dd
			best = nc[0]
	return best

# 给提示词和名片用的外形简述
static func appearance_summary(s: Dictionary) -> String:
	var parts: Array = []
	var cl: Dictionary = s.colors
	match s.plan:
		"humanoid":
			parts.append("人形（%s）" % s.kind)
			if s.hair.style != "none":
				parts.append("%s%s头发" % [color_name(cl.hair), {"short": "短", "long": "长", "bob": "波波", "twintails": "双马尾", "ponytail": "马尾", "spiky": "刺猬", "bun": "丸子头", "messy": "凌乱", "curly": "卷", "side": "侧分", "fluffy": "蓬松"}.get(s.hair.style, "")])
			if s.outfit != "none":
				parts.append("穿%s的%s" % [color_name(cl.main), {"tshirt": "T恤", "dress": "裙子", "hoodie": "卫衣", "suit": "制服", "robe": "长袍", "armor": "盔甲", "overalls": "背带裤", "kimono": "和服", "apron": "围裙", "sweater": "毛衣"}.get(s.outfit, "衣服")])
		"animal":
			parts.append("%s的%s" % [color_name(cl.main), s.kind])
		"plant":
			parts.append("%s植物（%s）" % [color_name(cl.main), s.kind])
		"object":
			parts.append("%s的%s" % [color_name(cl.main), s.kind])
		"blob":
			parts.append("%s的%s" % [color_name(cl.main), s.kind])
	parts.append("%s眼睛" % color_name(cl.eye))
	for k in ["ears", "tail", "horns", "wings", "hat", "glasses", "neck"]:
		if String(s[k]) != "none":
			parts.append("%s:%s" % [k, s[k]])
	if not s.extras.is_empty():
		parts.append("特征:" + ",".join(s.extras))
	return "，".join(parts)

# ------------------------------------------------------------------ 离线生成：按关键词拼一个伙伴
static func _has_any(d: String, words: Array) -> bool:
	for w in words:
		if d.find(String(w)) >= 0:
			return true
	return false

static func offline_spec(desc: String, name_hint := "", seed := 0) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed if seed != 0 else hash(desc + str(Time.get_ticks_usec()))
	var d := desc.to_lower()
	var s := default_spec()
	var over := {}
	var found := false
	# 1) 先看有没有“动物特征的人形”
	for it in KW_HUMAN_MOD:
		if _has_any(d, it[0]):
			over.merge(it[1], true)
			found = true
			break
	# 2) 物品 / 植物 / 史莱姆（比动物优先：“猫咪杯子”是杯子）
	if not found:
		for it in KW_OBJECT:
			if _has_any(d, it[0]):
				over = {"plan": "object", "kind": it[1]}
				found = true
				break
	if not found:
		for it in KW_PLANT:
			if _has_any(d, it[0]):
				over = {"plan": "plant", "kind": it[1]}
				found = true
				break
	if not found:
		for it in KW_BLOB:
			if _has_any(d, it[0]):
				over = {"plan": "blob", "kind": it[1]}
				found = true
				break
	if not found:
		for it in KW_ANIMAL:
			if _has_any(d, it[0]):
				over = it[1].duplicate(true)
				over["plan"] = "animal"
				found = true
				break
	# 3) 人类基础属性（性别/年龄）——也会叠加到上面的人形上
	for it in KW_HUMAN:
		if _has_any(d, it[0]):
			if not found:
				over = it[1].duplicate(true)
				found = true
			elif String(over.get("plan", "")) == "humanoid":
				for k in it[1]:
					if not over.has(k) or k in ["gender", "age", "hair", "hair_c"]:
						over[k] = it[1][k]
			break
	if not found:
		# 什么都没认出来：随机给一个可爱的形象
		var pool := [{"plan": "blob", "kind": "slime"}, {"plan": "animal", "kind": "cat", "ears": "cat", "tail": "cat", "extras": ["whiskers"], "mouth": "cat"},
			{"plan": "blob", "kind": "spirit"}, {"plan": "humanoid", "kind": "girl", "hair": "bob", "gender": "female"}, {"plan": "plant", "kind": "sprout"}]
		over = pool[rng.randi() % pool.size()].duplicate(true)
	# 写入外形
	s.plan = String(over.get("plan", "humanoid"))
	s.kind = String(over.get("kind", "human"))
	for k in ["ears", "tail", "horns", "wings", "hat", "glasses", "neck", "outfit", "mouth", "aura"]:
		if over.has(k):
			s[k] = over[k]
	if over.has("eyes"):
		s.eyes.style = over.eyes
	if over.has("pattern"):
		s.body.pattern = over.pattern
	if over.has("body"):
		s.body.shape = over.body
	if over.has("size"):
		s.size = over.size
	if over.has("extras"):
		s.extras = over.extras.duplicate()
	s.hair.style = String(over.get("hair", "none"))
	# 默认配色
	var palettes := [["#f4a259", "#fff4e2", "#e85d75"], ["#7cc4f0", "#f5f3ef", "#f497b6"], ["#9b6ddf", "#f3ead7", "#f4d35e"],
		["#6cc070", "#f6f1d1", "#e8505b"], ["#f497b6", "#fff7ea", "#7cc4f0"], ["#4a90e2", "#f5f3ef", "#f39c4a"], ["#e8505b", "#2d2a32", "#f4d35e"]]
	var pal: Array = palettes[rng.randi() % palettes.size()]
	s.colors.main = String(over.get("main", pal[0]))
	s.colors.second = String(over.get("second", pal[1]))
	s.colors.accent = pal[2]
	s.colors.eye = ["#3a2f45", "#4a90e2", "#2f6b4f", "#8e2c48", "#7a5236", "#9b6ddf", "#d18a1d"][rng.randi() % 7]
	if over.has("eye"):
		s.colors.eye = over.eye
	s.colors.hair = String(over.get("hair_c", ["#3b2f2f", "#5b4a3f", "#e9c46a", "#2d2a32", "#c8743c", "#f5f3ef"][rng.randi() % 6]))
	if over.has("skin"):
		s.colors.skin = over.skin
	match s.plan:
		"humanoid":
			s.extras.append("blush")
			if s.outfit == "none":
				s.outfit = ["tshirt", "hoodie", "dress", "sweater", "overalls"][rng.randi() % 5]
			if s.hair.style == "none":
				s.hair.style = ["short", "long", "bob", "messy"][rng.randi() % 4]
			s.eyes.style = ["anime", "round", "sparkle", "gentle"][rng.randi() % 4]
			s.eyes.lashes = String(over.get("gender", "")) == "female"
			if String(over.get("gender", "")) == "female" and s.outfit in ["tshirt", "overalls"] and rng.randf() < 0.5:
				s.outfit = "dress"
		"plant":
			s.colors.main = String(over.get("main", ["#f497b6", "#f4d35e", "#e8505b", "#9b6ddf"][rng.randi() % 4]))
			s.colors.second = "#6cc070"
			if s.kind in ["cactus", "sprout", "leafy", "tree"]:
				s.colors.main = "#6cc070"
				s.colors.second = "#c8693a"
			s.extras = ["blush"]
		"object":
			s.extras = ["blush"]
		"blob":
			s.extras = ["blush"]
			if s.kind == "ghost":
				s.colors.main = "#eef0ff"
	# 颜色词：区分“发/毛”“眼/瞳”与主色
	var assigned_main := false
	var used := {}
	for cw in COLOR_WORDS:
		var w: String = cw[0]
		var pos := d.find(w)
		while pos >= 0:
			var key := "%d" % pos
			if not used.has(key):
				var tail := d.substr(pos + w.length(), 6)
				var colr: String = cw[1]
				var span_used := false
				if tail.begins_with("色"):
					tail = tail.substr(1)
				var cut := tail.length()
				for pc in ["，", ",", "。", "、", " ", "的龙", "的猫"]:
					var pi := tail.find(pc)
					if pi >= 0 and pi < cut:
						cut = pi
				var win := tail.substr(0, mini(cut, 4))
				var ih := win.find("发")
				if ih < 0:
					ih = win.find("毛")
				var ie := win.find("眼")
				if ie < 0:
					ie = win.find("瞳")
				if ih >= 0 and (ie < 0 or ih < ie):
					s.colors.hair = colr
					span_used = true
				elif ie >= 0:
					s.colors.eye = colr
					span_used = true
				elif not assigned_main:
					s.colors.main = colr
					assigned_main = true
					span_used = true
				elif s.colors.accent == pal[2]:
					s.colors.accent = colr
					span_used = true
				if span_used:
					for i in w.length():
						used["%d" % (pos + i)] = true
			pos = d.find(w, pos + w.length())
	# 性格
	var tr: Dictionary = s.personality.traits
	var arch := ""
	var descs: Array = []
	for it in KW_PERSONA:
		if _has_any(d, it[0]):
			for k in it[1]:
				if k == "arch":
					if arch == "":
						arch = it[1][k]
				elif k == "desc":
					descs.append(it[1][k])
				else:
					tr[k] = it[1][k]
	if descs.is_empty():
		for k in tr:
			tr[k] = clampf(tr[k] + rng.randf_range(-0.25, 0.25), 0.05, 0.95)
	s.personality.archetype = arch if arch != "" else _calc_arch(tr)
	s.personality.desc = "，".join(descs) if not descs.is_empty() else ARCH_CN[s.personality.archetype] + "，喜欢陪在你身边"
	if s.kind in ["grandpa", "grandma", "uncle"] and arch == "":
		s.personality.archetype = "wise"
	# 口癖
	var suf := ""
	for sw in [["喵", "喵"], ["汪", "汪"], ["哒", "哒"], ["呢", "呢"], ["捏", "捏"], ["desu", "desu"], ["啾", "啾"], ["嘎", "嘎"]]:
		if d.find("带" + sw[0]) >= 0 or d.find("句尾" + sw[0]) >= 0 or d.find("“" + sw[0]) >= 0 or d.find("\"" + sw[0]) >= 0 or d.find("说" + sw[0]) >= 0:
			suf = sw[1]
			break
	if suf == "" and s.kind in ["cat", "catfolk"] and rng.randf() < 0.6:
		suf = "喵"
	if suf == "" and s.kind == "dog" and rng.randf() < 0.4:
		suf = "汪"
	s.personality.suffix = suf
	var re := RegEx.new()
	re.compile("(?:说话带|句尾带|口头禅是|口头禅)[“\"「]?([^\\s，。,\\.\"」”]{1,6})")
	var m := re.search(desc)
	if m:
		s.personality.catchphrases = [m.get_string(1)]
	s.personality.speech = {"gentle": "说话温柔，常常关心对方", "genki": "说话充满活力，常用感叹号", "tsundere": "嘴硬心软，常说“哼”和“才不是”",
		"cool": "话很少，简短冷静", "shy": "说话有点结巴，声音小小的", "playful": "爱开玩笑，喜欢逗人", "lazy": "说话慢吞吞，常打哈欠", "wise": "说话沉稳，偶尔讲点道理"}[s.personality.archetype]
	if suf != "":
		s.personality.speech += "，句尾常带“%s”" % suf
	var lk_key: String = s.kind if KIND_LIKES.has(s.kind) else s.plan
	if KIND_LIKES.has(lk_key):
		s.personality.likes = KIND_LIKES[lk_key][0].duplicate()
		s.personality.dislikes = KIND_LIKES[lk_key][1].duplicate()
	# 名字
	var nm := name_hint.strip_edges()
	if nm == "":
		re.compile("(?:叫做|名叫|名字是|名字叫|叫)[“\"「]?([^\\s，。,\\.\"」”的]{1,6})")
		m = re.search(desc)
		if m:
			nm = m.get_string(1)
	if nm == "":
		var names := {"cat": ["年糕", "煤球", "橘子", "咪咪"], "dog": ["豆豆", "旺财", "可乐"], "rabbit": ["棉花", "糯米"], "panda": ["圆圆", "滚滚"],
			"fox": ["小狐", "阿离"], "dragon": ["小焰", "阿龙"], "bear": ["熊熊", "布丁"], "plant": ["小芽", "绿绿", "阿花"], "object": ["小器", "叮当", "咕噜"],
			"blob": ["团子", "啵啵", "软软"], "humanoid": ["小雪", "阿澈", "星野", "千夏", "小鹿"]}
		var key2: String = s.kind if names.has(s.kind) else s.plan
		var arr: Array = names.get(key2, names.blob)
		nm = arr[rng.randi() % arr.size()]
	s.name = nm.left(12)
	s.label = desc.strip_edges().left(18) if desc.strip_edges() != "" else "神秘的小家伙"
	# 声音
	var gender := String(over.get("gender", ""))
	if gender == "":
		gender = "female" if _has_any(d, ["女", "她", "girl", "娘", "妹", "姐"]) else ("male" if _has_any(d, ["男", "他", "boy", "哥", "弟", "叔", "爷"]) else "neutral")
	var age := String(over.get("age", ""))
	var pitch := 1.1
	match gender:
		"female":
			pitch = 1.28
		"male":
			pitch = 0.86
	if age == "child":
		pitch = 1.5
	elif age == "old":
		pitch = 0.72 if gender == "male" else 0.95
	if s.plan in ["object", "blob", "plant"] and age == "":
		pitch = 1.35
	if s.kind in ["dragon", "bear", "dino", "lion"]:
		pitch = 0.75
	match s.personality.archetype:
		"cool":
			pitch -= 0.08
		"genki":
			pitch += 0.08
	var rate: float = {"genki": 1.15, "lazy": 0.85, "wise": 0.9, "shy": 0.95, "cool": 0.95}.get(s.personality.archetype, 1.0)
	s.voice = {"gender": gender, "pitch": clampf(pitch, 0.5, 2.0), "rate": rate, "api_voice": ""}
	if s.plan == "humanoid" and gender == "male" and s.hair.style == "long":
		s.hair.style = "short"
	return normalize(s)

# 给 AI 看的“外形字段说明”，用于生成和修改伙伴
static func schema_text() -> String:
	return """输出一个 JSON 对象，字段如下（枚举值必须从列表里选）：
{
 "name": "名字(2-6字)", "label": "一句话身份，如“银发猫耳少女”",
 "plan": %s,
 "kind": "具体种类：plan=animal 时写动物英文名(cat,dog,fox,rabbit,bear,panda,dragon,bird,penguin,owl,wolf,tiger,lion,sheep,deer,pig,cow,frog,monkey,hamster等)；plan=object 时从 %s 选；plan=plant 时从 %s 选；plan=blob 时从 %s 选；humanoid 写 girl/boy/elf/witch 等",
 "size": 0.8-1.2,
 "colors": {"main":"#hex 主色(人形=衣服,动物=毛色,物品=本体)","second":"#hex 副色(肚皮/内衬)","accent":"#hex 点缀色","skin":"#hex 肤色","hair":"#hex 发色","eye":"#hex 眼睛颜色","line":"#hex 描边色，可留空"},
 "head": {"shape": %s, "size": 0.9-1.15},
 "body": {"shape": %s, "pattern": %s},
 "eyes": {"style": %s, "size": 0.8-1.3, "lashes": true/false},
 "mouth": %s, "brows": %s,
 "hair": {"style": %s},
 "ears": %s, "tail": %s, "horns": %s, "wings": %s,
 "hat": %s, "glasses": %s, "neck": %s, "outfit": %s,
 "extras": 从 %s 里选0-4个,
 "aura": %s, "material": %s,
 "personality": {"archetype": %s, "desc": "性格描述(30字内)", "traits": {"extravert":0-1,"warm":0-1,"playful":0-1,"sass":0-1,"independent":0-1,"curious":0-1,"energy":0-1}, "speech": "说话方式", "suffix": "句尾口癖(可空，如喵)", "catchphrases": ["口头禅"], "likes": ["喜欢的东西"], "dislikes": ["讨厌的东西"], "backstory": "一两句来历", "relation": "和用户的关系，默认朋友", "call_user": "怎么称呼用户，默认你"},
 "voice": {"gender": "female/male/neutral", "pitch": 0.6-1.8 (1=正常,越大越尖细), "rate": 0.8-1.3},
 "touch": {"head":[["被摸头时说的话","情绪"]x2],"face":[...x2],"body":[...x2],"hand":[...x2],"tail":[...x2],"spam":[被连续猛戳时x2],"carry":[被拎起来x2],"drop":[被放下x2],"wake":[被叫醒x2]},
 "lines": {"greet": ["打招呼x3"], "idle": ["主动搭话x4"], "bye": ["道别x2"]}
}
情绪从 %s 选。台词要完全符合角色性格和口癖，每句不超过20字。""" % [JSON.stringify(PLANS), JSON.stringify(OBJECT_KINDS), JSON.stringify(PLANT_KINDS), JSON.stringify(BLOB_KINDS),
		JSON.stringify(HEAD_SHAPES), JSON.stringify(BODY_SHAPES), JSON.stringify(PATTERNS), JSON.stringify(EYE_STYLES), JSON.stringify(MOUTHS), JSON.stringify(BROWS),
		JSON.stringify(HAIRS), JSON.stringify(EARS), JSON.stringify(TAILS), JSON.stringify(HORNS), JSON.stringify(WINGS), JSON.stringify(HATS), JSON.stringify(GLASSES),
		JSON.stringify(NECKS), JSON.stringify(OUTFITS), JSON.stringify(EXTRAS), JSON.stringify(AURAS), JSON.stringify(MATERIALS), JSON.stringify(ARCHETYPES), JSON.stringify(EMOTIONS)]
