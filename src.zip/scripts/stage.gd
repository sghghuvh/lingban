extends Control
# 灵伴：伙伴脚下的小舞台。天空随真实时间变化（清晨/白天/傍晚/夜晚），有星星、云朵和小山坡。

var t := 0.0
var _stars: Array = []
var _clouds: Array = []
var pal := {}
var _last_h := -1
var compact := false
var custom_mode := "sky"      # sky（默认动态天空）/ image（自定义图片）
var custom_tex: Texture2D = null
var effect := "none"          # none/petals/snow/stars/fireflies/bubbles/leaves
var _fx: Array = []
var _fx_seeded := ""

func set_background(mode: String, tex: Texture2D) -> void:
	custom_mode = mode
	custom_tex = tex
	queue_redraw()

func set_effect(e: String) -> void:
	effect = e
	_fx_seeded = ""
	queue_redraw()

const FX_CN := {"none": "无", "petals": "樱花", "snow": "雪花", "stars": "星光", "fireflies": "萤火虫", "bubbles": "气泡", "leaves": "落叶"}

func _seed_fx() -> void:
	_fx.clear()
	var r := RandomNumberGenerator.new()
	r.seed = 7
	var n := 0 if effect == "none" else (34 if effect in ["snow", "stars", "petals"] else 22)
	for i in n:
		_fx.append({"x": r.randf(), "y": r.randf(), "s": r.randf_range(0.6, 1.5), "ph": r.randf() * TAU, "sp": r.randf_range(0.5, 1.3)})
	_fx_seeded = effect

func _draw_fx(w: float, h: float) -> void:
	if effect == "none":
		return
	if _fx_seeded != effect:
		_seed_fx()
	for p in _fx:
		var sp: float = p.sp
		var yy := fposmod(p.y + t * 0.05 * sp * (-1.0 if effect in ["bubbles"] else 1.0), 1.0)
		var xx := fposmod(p.x + sin(t * 0.4 * sp + p.ph) * 0.03, 1.0)
		var px := xx * w
		var py := yy * h
		var sc: float = p.s
		match effect:
			"snow":
				draw_circle(Vector2(px, py), 3.0 * sc, Color(1, 1, 1, 0.8))
			"stars":
				var a := 0.4 + 0.5 * absf(sin(t * 1.5 + p.ph))
				draw_circle(Vector2(px, py), 2.2 * sc, Color(1, 1, 0.95, a))
			"fireflies":
				var a2 := 0.25 + 0.6 * absf(sin(t * 2.0 + p.ph))
				draw_circle(Vector2(px, py), 6.0 * sc, Color(1.0, 0.95, 0.5, a2 * 0.25))
				draw_circle(Vector2(px, py), 2.6 * sc, Color(1.0, 0.98, 0.6, a2))
			"bubbles":
				draw_arc(Vector2(px, py), 7.0 * sc, 0, TAU, 14, Color(0.8, 0.95, 1.0, 0.5), 1.5)
			"petals", "leaves":
				var col := Color(1.0, 0.75, 0.85, 0.85) if effect == "petals" else Color(0.9, 0.6, 0.3, 0.85)
				var rot: float = t * 1.2 * sp + p.ph
				var a0 := Vector2(px, py)
				var pts := PackedVector2Array()
				for k in 5:
					var ang: float = rot + k * TAU / 5.0
					pts.append(a0 + Vector2(cos(ang), sin(ang) * 0.6).rotated(rot * 0.3) * 6.0 * sc)
				draw_colored_polygon(pts, col)

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	var r := RandomNumberGenerator.new()
	r.seed = 42
	for i in 40:
		_stars.append([Vector2(r.randf(), r.randf() * 0.7), r.randf_range(1.0, 2.6), r.randf() * TAU])
	for i in 4:
		_clouds.append([r.randf(), r.randf_range(0.08, 0.4), r.randf_range(0.6, 1.3), r.randf_range(4.0, 10.0)])
	_update_palette()

func _update_palette() -> void:
	var h: int = Time.get_datetime_dict_from_system().hour
	if h == _last_h:
		return
	_last_h = h
	if h >= 5 and h < 8:
		pal = {"top": Color("#f5a27a"), "bot": Color("#ffe1c4"), "h1": Color("#e9a985"), "h2": Color("#d68c6c"), "night": false, "sun": Color("#fff2c4")}
	elif h >= 8 and h < 17:
		pal = {"top": Color("#6fbcef"), "bot": Color("#d4efff"), "h1": Color("#97d48c"), "h2": Color("#73bf74"), "night": false, "sun": Color("#fff6cf")}
	elif h >= 17 and h < 19:
		pal = {"top": Color("#7b5ea7"), "bot": Color("#ffa77a"), "h1": Color("#c07a8f"), "h2": Color("#9b6283"), "night": false, "sun": Color("#ffd27a")}
	else:
		pal = {"top": Color("#0e1430"), "bot": Color("#2f3363"), "h1": Color("#2a2f57"), "h2": Color("#222649"), "night": true, "sun": Color("#f4f1d0")}

func ground_y() -> float:
	return size.y - (24.0 if compact else 36.0)

func _process(delta: float) -> void:
	t += delta
	if fmod(t, 30.0) < delta:
		_update_palette()
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 2 or h < 2:
		return
	if custom_mode == "image" and custom_tex != null:
		# 自定义背景：等比铺满整块舞台（cover），底部压一层暗角让人物更清楚
		var tw := float(custom_tex.get_width())
		var th := float(custom_tex.get_height())
		if tw > 1.0 and th > 1.0:
			var sc := maxf(w / tw, h / th)
			var dw := tw * sc
			var dh := th * sc
			draw_texture_rect(custom_tex, Rect2((w - dw) * 0.5, (h - dh) * 0.5, dw, dh), false)
		else:
			draw_rect(Rect2(0, 0, w, h), Color("#2a2f57"))
		draw_rect(Rect2(0, h - 70, w, 70), Color(0, 0, 0, 0.0))
		var gpts := PackedVector2Array([Vector2(0, h - 90), Vector2(w, h - 90), Vector2(w, h), Vector2(0, h)])
		draw_polygon(gpts, PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0, 0, 0, 0.28), Color(0, 0, 0, 0.28)]))
		_draw_fx(w, h)
		return
	var pts := PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h), Vector2(0, h)])
	draw_polygon(pts, PackedColorArray([pal.top, pal.top, pal.bot, pal.bot]))
	if pal.night:
		for s in _stars:
			var a := 0.45 + 0.45 * sin(t * 1.6 + s[2])
			draw_circle(Vector2(s[0].x * w, s[0].y * h), s[1], Color(1, 1, 0.9, a))
		draw_circle(Vector2(w * 0.82, h * 0.2), minf(w, h) * 0.07, pal.sun)
		draw_circle(Vector2(w * 0.82 + minf(w, h) * 0.03, h * 0.2 - minf(w, h) * 0.02), minf(w, h) * 0.06, pal.top.lerp(pal.bot, 0.15))
	else:
		var sc := Vector2(w * 0.82, h * 0.2)
		var sr := minf(w, h) * 0.07
		for i in 4:
			draw_circle(sc, sr * (1.0 + i * 0.35), Color(pal.sun, 0.12))
		draw_circle(sc, sr, pal.sun)
		for c in _clouds:
			var x := fmod(c[0] * w + t * c[3], w + 260.0) - 130.0
			var y: float = c[1] * h
			var k: float = c[2] * minf(w, h) / 600.0
			for o in [Vector2(-40, 6), Vector2(0, -10), Vector2(40, 6), Vector2(-14, 12), Vector2(18, 12)]:
				draw_circle(Vector2(x, y) + o * k * 1.4, 34.0 * k, Color(1, 1, 1, 0.75))
	# 远山 + 近坡
	var gy := ground_y()
	var far := PackedVector2Array()
	far.append(Vector2(0, h))
	for i in 25:
		var u := float(i) / 24.0
		far.append(Vector2(u * w, gy - 60.0 - sin(u * 5.0 + 1.0) * 26.0 - sin(u * 11.0) * 10.0))
	far.append(Vector2(w, h))
	draw_colored_polygon(far, pal.h2)
	var near := PackedVector2Array()
	near.append(Vector2(0, h))
	for i in 25:
		var u2 := float(i) / 24.0
		near.append(Vector2(u2 * w, gy - 18.0 - sin(u2 * 3.0 + 2.0) * 12.0))
	near.append(Vector2(w, h))
	draw_colored_polygon(near, pal.h1)
	draw_rect(Rect2(0, gy, w, h - gy), pal.h1.darkened(0.08))
	_draw_fx(w, h)
