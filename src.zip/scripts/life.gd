extends RefCounted
# 桌宠物语：生物特性——会饿、会困、会生病。关掉 App 时也在慢慢变化（回来时补算）。
# 数值都在 0~100：hunger 越高越饱，energy 越高越有精神，health 越高越健康。

const OFFLINE_CAP := 36.0 * 3600.0

static func body(st: Dictionary) -> Dictionary:
	var b = st.get("body", {})
	if typeof(b) != TYPE_DICTIONARY:
		b = {}
	if not b.has("hunger"):
		b["hunger"] = 80.0
	if not b.has("energy"):
		b["energy"] = 80.0
	if not b.has("health"):
		b["health"] = 100.0
	if not b.has("sick"):
		b["sick"] = false
	if not b.has("t"):
		b["t"] = int(Time.get_unix_time_from_system())
	st["body"] = b
	return b

# 推进 dt 秒。sleeping=睡着（精力恢复、饿得慢）。返回事件："sick" / "recover" / ""
static func tick(st: Dictionary, dt: float, sleeping: bool, rng: RandomNumberGenerator) -> String:
	var b := body(st)
	var h := dt / 3600.0
	b.hunger = clampf(float(b.hunger) - (3.0 if sleeping else 5.0) * h, 0.0, 100.0)
	if sleeping:
		b.energy = clampf(float(b.energy) + 25.0 * h, 0.0, 100.0)
	else:
		b.energy = clampf(float(b.energy) - 6.0 * h, 0.0, 100.0)
	var hp := float(b.health)
	if float(b.hunger) < 15.0:
		hp -= 6.0 * h
	if float(b.energy) < 10.0:
		hp -= 3.0 * h
	if float(b.hunger) > 50.0 and float(b.energy) > 30.0:
		hp += (1.5 if bool(b.sick) else 4.0) * h
	b.health = clampf(hp, 0.0, 100.0)
	if not bool(b.sick):
		# 身体差时容易生病；平时偶尔小感冒（平均几十天一次）
		var p := (0.25 if float(b.health) < 45.0 else 0.0015) * h
		if rng.randf() < p:
			b.sick = true
			b.health = minf(float(b.health), 60.0)
			return "sick"
	elif float(b.health) >= 75.0:
		b.sick = false
		return "recover"
	return ""

# 回到 App 时补算离开期间的变化（离开时当作在睡觉）
static func catch_up(st: Dictionary, now: int, rng: RandomNumberGenerator) -> String:
	var b := body(st)
	var dt := clampf(float(now - int(b.t)), 0.0, OFFLINE_CAP)
	b.t = now
	var ev := ""
	while dt > 0.0:
		var d := minf(1800.0, dt)
		var e := tick(st, d, true, rng)
		if e != "":
			ev = e
		dt -= d
	b.hunger = maxf(float(b.hunger), 10.0)
	return ev

static func status_text(st: Dictionary) -> String:
	var b := body(st)
	var parts: Array = []
	if bool(b.sick):
		parts.append("生病了")
	var hu := float(b.hunger)
	if hu < 20.0:
		parts.append("好饿")
	elif hu < 40.0:
		parts.append("有点饿")
	var en := float(b.energy)
	if en < 15.0:
		parts.append("好困")
	elif en < 30.0:
		parts.append("有点累")
	return "、".join(parts)

# 给 AI 的一句话（很短，省 token）
static func prompt_line(st: Dictionary) -> String:
	var t := status_text(st)
	if t == "":
		return ""
	return "\n【身体】你现在%s，自然地流露出来（撒娇要吃的、打哈欠、没精神等），别每句都提。" % t

# 情绪底色：没有别的情绪时，脸上带着身体状态
static func base_emotion(st: Dictionary) -> String:
	var b := body(st)
	if bool(b.sick):
		return "sad"
	if float(b.energy) < 15.0:
		return "sleepy"
	if float(b.hunger) < 20.0:
		return "sad"
	return "neutral"

static func feed(st: Dictionary) -> Dictionary:
	var b := body(st)
	if float(b.hunger) > 90.0:
		return {"ok": false, "say": "吃不下啦，肚子圆滚滚的～", "emo": "smug", "ges": "shake"}
	b.hunger = minf(100.0, float(b.hunger) + 35.0)
	if bool(b.sick):
		b.health = minf(100.0, float(b.health) + 5.0)
	var lines := ["好吃！谢谢你～", "嗯嗯，吃饱饱了！", "嘿嘿，你最好了～", "啊呜——好香！"]
	return {"ok": true, "say": lines[randi() % lines.size()], "emo": "happy", "ges": "clap"}

static func care(st: Dictionary) -> Dictionary:
	var b := body(st)
	if bool(b.sick):
		b.health = minf(100.0, float(b.health) + 30.0)
		if float(b.health) >= 75.0:
			b.sick = false
			return {"cured": true, "say": "我好啦！谢谢你一直照顾我～", "emo": "love", "ges": "hug"}
		return {"cured": false, "say": "呜……有你在真好，好像舒服一点了。", "emo": "love", "ges": "none"}
	if float(b.energy) < 30.0:
		b.energy = minf(100.0, float(b.energy) + 15.0)
		return {"cured": false, "say": "摸摸头就有精神了……一点点。", "emo": "sleepy", "ges": "nod"}
	return {"cured": false, "say": "我很健康哦！抱抱～", "emo": "happy", "ges": "hug"}
