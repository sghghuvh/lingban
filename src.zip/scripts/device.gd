extends Node
# 灵伴：帮用户操作手机。每种操作都要经过权限（禁止 / 每次询问 / 总是允许）。
# 安卓上用 Godot 4.4+ 的 AndroidRuntime + JavaClassWrapper 直接调用系统接口。
# 注意：真正点击“别的 App 里面的按钮”需要无障碍服务（原生代码），这一版不做。

var app
var _app_cache: Dictionary = {}
var _cache_ready := false
var test_mode := false
var last_log := ""

const CAPS := {
	"open_app": "打开应用", "web": "上网搜索、打开网页和地图", "phone": "打开拨号和短信界面", "clock": "设置闹钟和计时器",
	"flashlight": "开关手电筒", "volume": "调节音量", "settings": "打开系统设置页面", "camera": "打开相机", "share": "分享和复制文字",
}
const CAP_ORDER := ["open_app", "web", "phone", "clock", "flashlight", "volume", "settings", "camera", "share"]

# 常用 App 的包名（找不到时再扫描已安装应用）
const PKG := {
	"微信": "com.tencent.mm", "wechat": "com.tencent.mm", "qq": "com.tencent.mobileqq", "支付宝": "com.eg.android.AlipayGphone",
	"抖音": "com.ss.android.ugc.aweme", "tiktok": "com.zhiliaoapp.musically", "快手": "com.smile.gifmaker", "淘宝": "com.taobao.taobao",
	"京东": "com.jingdong.app.mall", "拼多多": "com.xunmeng.pinduoduo", "美团": "com.sankuai.meituan", "饿了么": "me.ele",
	"哔哩哔哩": "tv.danmaku.bili", "b站": "tv.danmaku.bili", "bilibili": "tv.danmaku.bili", "小红书": "com.xingin.xhs", "微博": "com.sina.weibo",
	"知乎": "com.zhihu.android", "网易云音乐": "com.netease.cloudmusic", "网易云": "com.netease.cloudmusic", "qq音乐": "com.tencent.qqmusic",
	"酷狗": "com.kugou.android", "高德地图": "com.autonavi.minimap", "高德": "com.autonavi.minimap", "百度地图": "com.baidu.BaiduMap",
	"百度": "com.baidu.searchbox", "chrome": "com.android.chrome", "谷歌浏览器": "com.android.chrome", "youtube": "com.google.android.youtube",
	"telegram": "org.telegram.messenger", "电报": "org.telegram.messenger", "steam": "com.valvesoftware.android.steam.community",
	"github": "com.github.android", "spotify": "com.spotify.music", "tidal": "com.aspiro.tidal", "gmail": "com.google.android.gm",
	"谷歌地图": "com.google.android.apps.maps", "google": "com.google.android.googlequicksearchbox", "godot": "org.godotengine.editor.v4",
	"钉钉": "com.alibaba.android.rimet", "飞书": "com.ss.android.lark", "腾讯会议": "com.tencent.wemeet.app", "爱奇艺": "com.qiyi.video",
	"优酷": "com.youku.phone", "腾讯视频": "com.tencent.qqlive", "12306": "com.MobileTicket", "携程": "ctrip.android.view", "滴滴": "com.sdu.didi.psnger",
	"kimi": "com.moonshot.kimichat", "豆包": "com.larus.nova", "deepseek": "com.deepseek.chat", "notion": "notion.id", "claude": "com.anthropic.claude",
	"设置": "com.android.settings",
}
# 找不到包名时，用网址协议打开
const SCHEME := {"微信": "weixin://", "支付宝": "alipays://", "淘宝": "taobao://", "抖音": "snssdk1128://", "哔哩哔哩": "bilibili://", "b站": "bilibili://",
	"qq": "mqq://", "网易云音乐": "orpheus://", "高德地图": "androidamap://", "京东": "openapp.jdmobile://", "美团": "imeituan://", "微博": "sinaweibo://", "知乎": "zhihu://"}

func setup(a) -> void:
	app = a

func cap_of(type: String) -> String:
	match type:
		"open_app":
			return "open_app"
		"web_search", "open_url", "map":
			return "web"
		"dial", "sms", "email":
			return "phone"
		"alarm", "timer":
			return "clock"
		"flashlight":
			return "flashlight"
		"volume":
			return "volume"
		"settings":
			return "settings"
		"camera":
			return "camera"
		"share", "copy":
			return "share"
	return ""

func describe(a: Dictionary) -> String:
	var t := String(a.get("type", ""))
	match t:
		"open_app":
			return "打开「%s」" % String(a.get("name", "?"))
		"web_search":
			return "搜索“%s”" % String(a.get("query", ""))
		"open_url":
			return "打开网页 %s" % String(a.get("url", "")).left(40)
		"map":
			return "在地图上找“%s”" % String(a.get("query", ""))
		"dial":
			return "打开拨号界面：%s（不会直接拨出）" % String(a.get("number", ""))
		"sms":
			return "给 %s 写短信" % String(a.get("number", ""))
		"email":
			return "写邮件给 %s" % String(a.get("to", ""))
		"alarm":
			return "设一个 %02d:%02d 的闹钟%s" % [int(a.get("hour", 7)), int(a.get("minute", 0)), ("（%s）" % a.label) if String(a.get("label", "")) != "" else ""]
		"timer":
			var s := int(a.get("seconds", 60))
			return "开始计时 %s" % (("%d 分钟" % (s / 60)) if s >= 60 and s % 60 == 0 else ("%d 秒" % s))
		"flashlight":
			return "打开手电筒" if bool(a.get("on", true)) else "关闭手电筒"
		"volume":
			return {"up": "把音量调大", "down": "把音量调小", "mute": "静音"}.get(String(a.get("dir", "up")), "调节音量")
		"settings":
			return "打开%s设置" % {"wifi": "无线网络", "bluetooth": "蓝牙", "display": "显示", "sound": "声音", "battery": "电池", "main": "系统"}.get(String(a.get("page", "main")), "系统")
		"camera":
			return "打开相机"
		"share":
			return "分享一段文字"
		"copy":
			return "复制文字到剪贴板"
	return "执行操作：%s" % t

func perm_of(a: Dictionary) -> String:
	var cap := cap_of(String(a.get("type", "")))
	if cap == "":
		return "deny"
	return String(app.store.settings.perms.get(cap, "ask"))

# ---------------------------------------------------------------- 安卓桥
func is_android() -> bool:
	return OS.get_name() == "Android" and Engine.has_singleton("AndroidRuntime")

func _rt():
	return Engine.get_singleton("AndroidRuntime") if Engine.has_singleton("AndroidRuntime") else null

func _activity():
	var rt = _rt()
	return rt.getActivity() if rt != null else null

func _on_ui(c: Callable) -> void:
	var rt = _rt()
	var act = _activity()
	if rt == null or act == null:
		c.call()
		return
	act.runOnUiThread(rt.createRunnableFromGodotCallable(c))

func _start_intent(it) -> bool:
	var act = _activity()
	if act == null or it == null:
		return false
	it.addFlags(0x10000000)
	_on_ui(func(): act.startActivity(it))
	return true

func _intent_uri(uri: String) -> bool:
	var IntentC = JavaClassWrapper.wrap("android.content.Intent")
	if IntentC == null:
		return false
	var it = IntentC.parseUri(uri, 0)
	return _start_intent(it)

func _launch_pkg(pkg: String) -> bool:
	var act = _activity()
	if act == null:
		return false
	var pm = act.getPackageManager()
	if pm == null:
		return false
	var it = pm.getLaunchIntentForPackage(pkg)
	if it == null:
		return false
	return _start_intent(it)

func _scan_apps() -> void:
	if _cache_ready:
		return
	_cache_ready = true
	var act = _activity()
	if act == null:
		return
	var pm = act.getPackageManager()
	if pm == null:
		return
	var lst = pm.getInstalledApplications(0)
	if lst == null:
		return
	var n := int(lst.size())
	for i in mini(n, 600):
		var ai = lst.get(i)
		if ai == null:
			continue
		var lab = pm.getApplicationLabel(ai)
		var label := String(lab.toString()) if lab != null and typeof(lab) == TYPE_OBJECT else String(lab)
		var desc := String(ai.toString())
		var pkg := desc.substr(desc.rfind(" ") + 1).replace("}", "").strip_edges()
		if label != "" and pkg.find(".") > 0:
			_app_cache[label.to_lower()] = pkg

func find_package(name: String) -> String:
	var n := name.strip_edges().to_lower()
	if PKG.has(n):
		return PKG[n]
	for k in PKG:
		if n.find(String(k)) >= 0 or String(k).find(n) >= 0 and n.length() >= 2:
			return PKG[k]
	if is_android():
		_scan_apps()
		if _app_cache.has(n):
			return _app_cache[n]
		for lab in _app_cache:
			if String(lab).find(n) >= 0 or (n.find(String(lab)) >= 0 and String(lab).length() >= 2):
				return _app_cache[lab]
	return ""

# ---------------------------------------------------------------- 执行
func _open(url: String) -> bool:
	if test_mode:
		last_log = "open:" + url
		return true
	return OS.shell_open(url) == OK

func search_url(q: String) -> String:
	var eng := String(app.store.settings.behavior.get("search", "bing"))
	match eng:
		"baidu":
			return "https://www.baidu.com/s?wd=" + q.uri_encode()
		"google":
			return "https://www.google.com/search?q=" + q.uri_encode()
	return "https://www.bing.com/search?q=" + q.uri_encode()

# 返回 {"ok": bool, "msg": String}
func execute(a: Dictionary) -> Dictionary:
	var t := String(a.get("type", ""))
	match t:
		"web_search":
			var q := String(a.get("query", "")).strip_edges()
			if q == "":
				return {"ok": false, "msg": "没有搜索内容"}
			return {"ok": _open(search_url(q)), "msg": "已打开搜索"}
		"open_url":
			var u := String(a.get("url", "")).strip_edges()
			if not (u.begins_with("http://") or u.begins_with("https://")):
				return {"ok": false, "msg": "只能打开 http/https 网页"}
			return {"ok": _open(u), "msg": "已打开网页"}
		"map":
			var q2 := String(a.get("query", "")).strip_edges()
			if is_android() or test_mode:
				return {"ok": _open("geo:0,0?q=" + q2.uri_encode()), "msg": "已打开地图"}
			return {"ok": _open("https://www.bing.com/maps?q=" + q2.uri_encode()), "msg": "已打开地图"}
		"dial":
			var num := String(a.get("number", "")).strip_edges()
			var clean := ""
			for ch in num:
				if ch in "0123456789+*#":
					clean += ch
			if clean == "":
				return {"ok": false, "msg": "号码不对"}
			return {"ok": _open("tel:" + clean), "msg": "已打开拨号界面"}
		"sms":
			var num2 := String(a.get("number", "")).strip_edges()
			return {"ok": _open("sms:%s?body=%s" % [num2, String(a.get("text", "")).uri_encode()]), "msg": "已打开短信"}
		"email":
			return {"ok": _open("mailto:%s?subject=%s&body=%s" % [String(a.get("to", "")), String(a.get("subject", "")).uri_encode(), String(a.get("body", "")).uri_encode()]), "msg": "已打开邮件"}
		"copy":
			DisplayServer.clipboard_set(String(a.get("text", "")))
			return {"ok": true, "msg": "已复制到剪贴板"}
	if test_mode:
		last_log = "android:" + JSON.stringify(a)
		return {"ok": true, "msg": "（测试）" + describe(a)}
	if not is_android():
		return {"ok": false, "msg": "这个操作只能在安卓手机上用"}
	match t:
		"open_app":
			var name := String(a.get("name", ""))
			var pkg := find_package(name)
			if pkg != "" and _launch_pkg(pkg):
				return {"ok": true, "msg": "已打开 " + name}
			var n := name.strip_edges().to_lower()
			for k in SCHEME:
				if n.find(String(k)) >= 0:
					if OS.shell_open(SCHEME[k]) == OK:
						return {"ok": true, "msg": "已打开 " + name}
			return {"ok": false, "msg": "没找到「%s」，可能没安装" % name}
		"alarm":
			var lab := String(a.get("label", "灵伴闹钟")).uri_encode()
			var uri := "intent:#Intent;action=android.intent.action.SET_ALARM;i.android.intent.extra.alarm.HOUR=%d;i.android.intent.extra.alarm.MINUTES=%d;S.android.intent.extra.alarm.MESSAGE=%s;end" % [clampi(int(a.get("hour", 7)), 0, 23), clampi(int(a.get("minute", 0)), 0, 59), lab]
			return {"ok": _intent_uri(uri), "msg": "已打开闹钟设置"}
		"timer":
			var lab2 := String(a.get("label", "灵伴计时")).uri_encode()
			var uri2 := "intent:#Intent;action=android.intent.action.SET_TIMER;i.android.intent.extra.alarm.LENGTH=%d;S.android.intent.extra.alarm.MESSAGE=%s;B.android.intent.extra.alarm.SKIP_UI=false;end" % [clampi(int(a.get("seconds", 60)), 1, 86400), lab2]
			return {"ok": _intent_uri(uri2), "msg": "已开始计时"}
		"settings":
			var act_name: String = {"wifi": "android.settings.WIFI_SETTINGS", "bluetooth": "android.settings.BLUETOOTH_SETTINGS", "display": "android.settings.DISPLAY_SETTINGS",
				"sound": "android.settings.SOUND_SETTINGS", "battery": "android.intent.action.POWER_USAGE_SUMMARY", "main": "android.settings.SETTINGS"}.get(String(a.get("page", "main")), "android.settings.SETTINGS")
			return {"ok": _intent_uri("intent:#Intent;action=%s;end" % act_name), "msg": "已打开设置"}
		"camera":
			return {"ok": _intent_uri("intent:#Intent;action=android.media.action.STILL_IMAGE_CAMERA;end"), "msg": "已打开相机"}
		"share":
			var IntentC = JavaClassWrapper.wrap("android.content.Intent")
			if IntentC == null:
				return {"ok": false, "msg": "分享失败"}
			var it = IntentC.Intent()
			it.setAction("android.intent.action.SEND")
			it.putExtra("android.intent.extra.TEXT", String(a.get("text", "")))
			it.setType("text/plain")
			return {"ok": _start_intent(it), "msg": "已打开分享"}
		"flashlight":
			var act = _activity()
			var cm = act.getSystemService("camera") if act != null else null
			if cm == null:
				return {"ok": false, "msg": "这台设备不能控制手电筒"}
			var ids = cm.getCameraIdList()
			if ids == null or ids.size() == 0:
				return {"ok": false, "msg": "没有找到闪光灯"}
			var on := bool(a.get("on", true))
			var id0 := String(ids[0])
			_on_ui(func(): cm.setTorchMode(id0, on))
			return {"ok": true, "msg": "手电筒已" + ("打开" if on else "关闭")}
		"volume":
			var act2 = _activity()
			var am = act2.getSystemService("audio") if act2 != null else null
			if am == null:
				return {"ok": false, "msg": "无法调节音量"}
			var dirv: int = {"up": 1, "down": -1, "mute": -100}.get(String(a.get("dir", "up")), 1)
			_on_ui(func(): am.adjustStreamVolume(3, dirv, 1))
			return {"ok": true, "msg": "音量已调整"}
	return {"ok": false, "msg": "不认识这个操作"}
