extends Node
# 桌宠物语：房间。多人把自己的（或收藏的）伙伴放进同一个场景，AI 导演让它们聊天、玩耍、吵闹，带身体反应。
# 同一个房间里每个人看到的是同一场戏（客户端轮询服务器的事件，各自演出来）。

const UI = preload("res://scripts/ui.gd")
const CR = preload("res://scripts/creature.gd")
const SP = preload("res://scripts/species.gd")
const SOCIAL = preload("res://scripts/social.gd")
const StageScript = preload("res://scripts/stage.gd")
const GET := HTTPClient.METHOD_GET
const POST := HTTPClient.METHOD_POST

const THEMES := [["sky", "晴空"], ["petals", "樱花"], ["snow", "雪夜"], ["stars", "星空"], ["fireflies", "萤火虫"], ["bubbles", "泡泡"], ["leaves", "落叶"]]
const KINDS := [["chat", "聊天"], ["play", "玩耍"], ["party", "派对"], ["argue", "吵架"], ["fight", "打闹"]]
const ITEMS := ["蛋糕", "零食", "鲜花", "玩具球", "冷水", "辣椒", "鞭炮"]

var app
var code := ""
var info: Dictionary = {}
var stage
var layer: Control
var actors := {}        # id -> {c, name, uid, owner, bub, lbl, until}
var loading := {}
var seq := 0
var castv := -1
var queue: Array = []
var playing := false
var poll: Timer
var title_lbl: Label
var mem_lbl: Label
var busy_poll := false

func _call(path: String, method: int, body: Dictionary, cb: Callable) -> void:
	app.llm.srv_call(path, method, body, cb)

# ================================================================== 大厅：创建 / 加入 / 公开房间
func build_lobby(a) -> void:
	app = a
	var body: VBoxContainer = app._scroll_page("房间", "settings")
	app.screen_root.add_child(self)
	if not app.store.shared():
		var s0: VBoxContainer = app._section(body, "")
		s0.add_child(UI.label("先到 设置 → 账号与共享服务 注册或登录，才能进房间。", 24, UI.TXT, true))
		s0.add_child(UI.btn("去设置", func(): app.show_screen("settings"), "primary", 24))
		return
	var h: VBoxContainer = app._section(body, "")
	h.add_child(UI.label("房间是一个多人场景：房主开房间，朋友用房间号加入，每个人把自己的伙伴放进去，伙伴们会在一起聊天、玩耍、吵闹。房主和成员都可以出题（比如「来一场生日派对」「突然停电了」）让它们现场演，也可以投喂东西看反应。", 22, UI.MUTED, true))
	var cr: VBoxContainer = app._section(body, "开一个房间")
	var fn := UI.le("房间名字", "")
	cr.add_child(fn)
	var theme := ["sky"]
	cr.add_child(UI.seg(THEMES, "sky", func(v): theme[0] = String(v)))
	var pub := [false]
	cr.add_child(UI.seg([[false, "仅限房间号加入"], [true, "公开（别人能在列表里看到）"]], false, func(v): pub[0] = bool(v)))
	var res := UI.hint("")
	cr.add_child(UI.btn("创建房间", func():
		res.text = "请稍等…"
		_call("/api/room", POST, {"name": fn.text.strip_edges(), "theme": theme[0], "public": pub[0]}, func(ok: bool, j: Dictionary, err: String):
			if not is_instance_valid(res):
				return
			if not ok:
				res.text = "✕ " + err
				return
			_enter(String(j.get("code", "")))), "primary", 24))
	cr.add_child(res)
	var jn: VBoxContainer = app._section(body, "用房间号加入")
	var jr := UI.hb(10)
	var fc := UI.le("6 位房间号")
	jr.add_child(fc)
	var jres := UI.hint("")
	jr.add_child(UI.btn("加入", func(): _join(fc.text.strip_edges(), jres), "primary", 24))
	jn.add_child(jr)
	jn.add_child(jres)
	var pb: VBoxContainer = app._section(body, "公开房间")
	var lst := UI.vb(10)
	pb.add_child(lst)
	lst.add_child(UI.hint("加载中…"))
	_call("/api/rooms", GET, {}, func(ok: bool, j: Dictionary, err: String):
		if not is_instance_valid(lst):
			return
		for ch in lst.get_children():
			ch.queue_free()
		if not ok:
			lst.add_child(UI.hint("✕ " + err))
			return
		var arr: Array = j.get("list", [])
		if arr.is_empty():
			lst.add_child(UI.hint("现在没有公开的房间，自己开一个吧。"))
		for r in arr:
			var rc := String(r.code)
			var row := UI.hb(10)
			row.add_child(UI.grow(UI.label("%s　房主 %s　%d 人 · %d 只伙伴" % [String(r.name), String(r.host), int(r.members), int(r.cast)], 22, UI.TXT, true)))
			row.add_child(UI.btn("加入", func(): _join(rc, null), "ghost", 22))
			lst.add_child(row))

func _join(c: String, res) -> void:
	if c == "":
		return
	if res != null:
		res.text = "请稍等…"
	_call("/api/room/join", POST, {"code": c}, func(ok: bool, j: Dictionary, err: String):
		if not ok:
			if res != null and is_instance_valid(res):
				res.text = "✕ " + err
			else:
				app.toast(err)
			return
		_enter(String(j.get("code", c))))

func _enter(c: String) -> void:
	app.room_code = c
	app.show_screen("room")

# ================================================================== 房间内
func build_room(a) -> void:
	app = a
	code = String(app.room_code)
	app.screen_root.add_child(self)
	var root := UI.vb(0)
	app._full(root)
	var bar := UI.hb(10)
	bar.custom_minimum_size.y = 92
	bar.add_child(UI.gap(1, 8))
	bar.add_child(UI.icon_btn("back", func(): app.show_screen("rooms"), 64, "flat"))
	var tv := UI.vb(0)
	tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_lbl = UI.title("房间 " + code, 28)
	mem_lbl = UI.label("", 20, UI.MUTED)
	tv.add_child(title_lbl)
	tv.add_child(mem_lbl)
	bar.add_child(tv)
	bar.add_child(UI.btn("复制房间号", func():
		DisplayServer.clipboard_set(code)
		app.toast("房间号 %s 已复制，发给朋友就能加入" % code), "ghost", 20))
	bar.add_child(UI.gap(1, 8))
	root.add_child(bar)
	stage = StageScript.new()
	stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stage.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(stage)
	layer = Control.new()
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	stage.add_child(layer)
	var bb := HFlowContainer.new()
	bb.add_theme_constant_override("h_separation", 10)
	bb.add_theme_constant_override("v_separation", 8)
	bb.add_child(UI.btn("放入伙伴", func(): _cast_popup(), "primary", 22))
	bb.add_child(UI.btn("导演（出题）", func(): _director_popup(), "primary", 22))
	bb.add_child(UI.btn("投喂", func(): _feed_popup(), "ghost", 22))
	bb.add_child(UI.btn("房间设置", func(): _settings_popup(), "ghost", 22))
	root.add_child(UI.margin(bb, 14, 8, 14, 12))
	poll = Timer.new()
	poll.wait_time = 2.5
	poll.autostart = true
	add_child(poll)
	poll.timeout.connect(_poll)
	_poll()

func _process(_dt: float) -> void:
	if layer == null or not is_instance_valid(layer):
		return
	var now := Time.get_ticks_msec() / 1000.0
	for id in actors:
		var a: Dictionary = actors[id]
		var c = a.c
		if not is_instance_valid(c):
			continue
		var bub: Control = a.bub
		if now > float(a.until):
			bub.visible = false
		else:
			bub.visible = true
			var hp: Vector2 = c.head_top_global() - layer.get_global_rect().position
			bub.reset_size()
			bub.position = Vector2(clampf(hp.x - bub.size.x * 0.5, 4.0, maxf(4.0, layer.size.x - bub.size.x - 4.0)), maxf(2.0, hp.y - bub.size.y - 8.0))

func _input(ev: InputEvent) -> void:
	if app == null or app.modal != null or layer == null or not is_instance_valid(layer):
		return
	for id in actors:
		var c = actors[id].c
		if is_instance_valid(c) and c.visible and c.handle_input(ev):
			get_viewport().set_input_as_handled()
			return

# ------------------------------------------------------------------ 同步服务器状态
func _poll() -> void:
	if busy_poll or code == "":
		return
	busy_poll = true
	_call("/api/room/%s?since=%d" % [code, seq], GET, {}, func(ok: bool, j: Dictionary, err: String):
		busy_poll = false
		if not is_instance_valid(self) or not is_instance_valid(stage):
			return
		if not ok:
			if err.find("关闭") >= 0 or err.find("没加入") >= 0 or err.find("还没加入") >= 0:
				app.toast(err)
				app.show_screen("rooms")
			return
		info = j
		title_lbl.text = "%s　#%s" % [String(j.get("name", "房间")), code]
		mem_lbl.text = "房主 %s · %s" % [String(j.get("host", "")), "、".join(j.get("members", []))]
		stage.set_effect(String(j.get("theme", "sky")) if String(j.get("theme", "sky")) != "sky" else "none")
		_sync_cast(j.get("cast", []))
		castv = int(j.get("castv", 0))
		for e in j.get("events", []):
			if int(e.get("seq", 0)) > seq:
				seq = int(e.seq)
				queue.append(e)
		seq = maxi(seq, int(j.get("seq", 0)) if queue.is_empty() and not playing else seq)
		_play_queue())

func _scale() -> float:
	return clampf(stage.size.y / 520.0, 0.35, 1.1)

func _sync_cast(list: Array) -> void:
	var present := {}
	for m in list:
		var id := String(m.id)
		present[id] = true
		if not actors.has(id) and not loading.has(id):
			_load_actor(m)
		elif actors.has(id):
			var a: Dictionary = actors[id]
			var c = a.c
			if is_instance_valid(c) and not bool(c.carried) and String(m.uid) != String(app.store.srv_uid()) and not playing:
				c.walk_to(_x_of(float(m.get("x", 0.5))))
	for id in actors.keys():
		if not present.has(id):
			_remove_actor(String(id))

func _x_of(ratio: float) -> float:
	var s := _scale()
	return 70.0 * s + clampf(ratio, 0.0, 1.0) * maxf(10.0, stage.size.x - 140.0 * s)

func _load_actor(m: Dictionary) -> void:
	var id := String(m.id)
	loading[id] = true
	_call("/api/room/%s/cast/%s" % [code, id], GET, {}, func(ok: bool, j: Dictionary, _e: String):
		loading.erase(id)
		if not ok or not is_instance_valid(layer) or actors.has(id):
			return
		var c = CR.new()
		c.font = app.font
		c.set_spec(j.get("spec", {}))
		var s := _scale()
		c.scale = Vector2.ONE * s
		c.wander = true
		c.position = Vector2(_x_of(float(m.get("x", 0.5))), stage.ground_y())
		layer.add_child(c)
		c.set_ground(stage.ground_y(), 60.0 * s, maxf(120.0, stage.size.x - 60.0 * s))
		var bub := UI.panel(Color("#F4F1FA"), 14, 8)
		bub.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var lbl := UI.label("", 21, Color("#2b2b3a"), true)
		lbl.custom_minimum_size.x = 120
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		bub.add_child(lbl)
		bub.visible = false
		layer.add_child(bub)
		var nm := UI.label(String(m.get("name", "")), 18, Color(1, 1, 1, 0.85))
		nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.touched.connect(func(_z: String, kind: String):
			if kind == "drop" and String(m.get("uid", "")) == String(app.store.srv_uid()):
				var ratio := clampf((c.position.x - 70.0 * s) / maxf(10.0, stage.size.x - 140.0 * s), 0.0, 1.0)
				_call("/api/room/%s/move" % code, POST, {"id": id, "x": ratio}, func(_a: bool, _b: Dictionary, _d: String): pass))
		actors[id] = {"c": c, "name": String(m.get("name", "")), "uid": String(m.get("uid", "")), "owner": String(m.get("owner", "")), "bub": bub, "lbl": lbl, "until": 0.0}
		c.react("happy", "wave", 2.5))

func _remove_actor(id: String) -> void:
	if not actors.has(id):
		return
	var a: Dictionary = actors[id]
	if is_instance_valid(a.c):
		a.c.queue_free()
	if is_instance_valid(a.bub):
		a.bub.queue_free()
	actors.erase(id)

# ------------------------------------------------------------------ 演出：事件队列
func _play_queue() -> void:
	if playing:
		return
	playing = true
	while not queue.is_empty() and is_instance_valid(self):
		var e: Dictionary = queue.pop_front()
		match String(e.get("type", "")):
			"scene":
				await _play_scene(e)
			"feed":
				await _play_feed(e)
			"join":
				if actors.has(String(e.get("who", ""))):
					actors[String(e.who)].c.react("happy", "wave", 2.5)
			"leave":
				pass
	playing = false
	if is_instance_valid(self):
		for id in actors:
			if is_instance_valid(actors[id].c):
				actors[id].c.wander = true

func _wait(s: float) -> void:
	await get_tree().create_timer(s).timeout

func _say(id: String, text: String, secs: float) -> void:
	if not actors.has(id):
		return
	var a: Dictionary = actors[id]
	a.lbl.text = text
	a.until = Time.get_ticks_msec() / 1000.0 + secs + 0.6
	a.c.set_speaking(true)
	get_tree().create_timer(secs).timeout.connect(func():
		if is_instance_valid(a.c):
			a.c.set_speaking(false))

func _face(a, b) -> void:
	if is_instance_valid(a) and is_instance_valid(b):
		a.facing = 1.0 if b.position.x > a.position.x else -1.0

func _arrive(c, timeout := 5.0) -> void:
	var t0 := Time.get_ticks_msec()
	while is_instance_valid(c) and c.walk_target != INF and (Time.get_ticks_msec() - t0) < int(timeout * 1000.0):
		await get_tree().process_frame

func _play_scene(e: Dictionary) -> void:
	for id in actors:
		actors[id].c.wander = false
	var kind_txt := String(e.get("topic", ""))
	if kind_txt != "":
		mem_lbl.text = "导演（%s）：%s" % [String(e.get("by", "")), kind_txt]
	for l in e.get("lines", []):
		var wid := String(l.get("who", ""))
		if not actors.has(wid):
			continue
		var w = actors[wid].c
		var tid := String(l.get("tgt", "")) if l.get("tgt") != null else ""
		var t = actors[tid].c if tid != "" and actors.has(tid) else null
		var act := String(l.get("act", "无"))
		var spd: float = 110.0
		if t != null and act in ["走近", "抱", "攻击", "追"]:
			var side := -1.0 if w.position.x < t.position.x else 1.0
			w.walk_speed = spd * (2.6 if act in ["攻击", "追"] else 1.3)
			w.walk_to(t.position.x + side * 90.0 * _scale())
			await _arrive(w, 5.0)
			w.walk_speed = spd
			_face(w, t)
			_face(t, w)
		elif act == "躲":
			w.walk_speed = spd * 2.6
			w.walk_to(0.0 if w.position.x > stage.size.x * 0.5 else stage.size.x)
		var emo := String(l.get("emo", "happy"))
		var txt := String(l.get("text", ""))
		var gest: String = {"跳": "jump", "挥手": "wave", "点头": "nod", "摇头": "shake", "耸肩": "shrug", "鼓掌": "clap", "跳舞": "dance", "鞠躬": "bow", "赌气": "pout", "抱": "hug", "攻击": "jump"}.get(act, "none")
		w.react(emo, gest, 3.0)
		if act == "背过身" and t != null:
			w.facing = -1.0 if t.position.x > w.position.x else 1.0
		var dur := maxf(2.3, txt.length() * 0.21)
		_say(wid, txt, dur)
		if t != null:
			if act == "攻击":
				var dir := 1.0 if t.position.x > w.position.x else -1.0
				t.airborne = true
				t.vel = Vector2(dir * 520.0, -640.0)
				t.react("scared" if randi() % 2 == 0 else "angry", "shake", 2.5)
			elif act == "追":
				t.walk_speed = spd * 2.2
				t.walk_to(0.0 if t.position.x < w.position.x else stage.size.x)
				t.react("scared", "none", 2.5)
			elif act == "抱":
				t.react("love", "hug", 2.5)
			else:
				_face(t, w)
		for oid in actors:
			if oid != wid and oid != tid and randi() % 100 < 40:
				var rs := ["surprised", "thinking", "smug", "happy", "shy"]
				actors[oid].c.react(rs[randi() % rs.size()], "none", 1.8)
				_face(actors[oid].c, w)
		await _wait(dur + 0.3)
		for id2 in actors:
			actors[id2].c.walk_speed = spd
	mem_lbl.text = "房主 %s · %s" % [String(info.get("host", "")), "、".join(info.get("members", []))]

func _play_feed(e: Dictionary) -> void:
	var id := String(e.get("who", ""))
	if not actors.has(id):
		return
	var c = actors[id].c
	var item := String(e.get("item", ""))
	var by := String(e.get("by", ""))
	match item:
		"蛋糕", "零食":
			c.react("love", "cheer", 3.0)
			_say(id, "哇，%s给的%s！好好吃" % [by, item], 2.2)
		"鲜花":
			c.react("shy", "bow", 3.0)
			_say(id, "送我的吗……谢谢", 2.2)
		"玩具球":
			c.react("excited", "jump", 3.0)
			_say(id, "球球！来玩来玩", 2.2)
		"冷水":
			c.airborne = true
			c.vel = Vector2(0, -520.0)
			c.react("surprised", "shake", 3.0)
			_say(id, "呀！好凉！", 1.8)
		"辣椒":
			c.react("angry", "shake", 3.5)
			_say(id, "好辣好辣好辣！", 2.0)
		"鞭炮":
			c.airborne = true
			c.vel = Vector2(randf_range(-400.0, 400.0), -780.0)
			c.react("scared", "shake", 3.0)
			_say(id, "砰！吓死我了", 1.8)
		_:
			c.react("happy", "wave", 2.0)
	await _wait(2.4)

# ------------------------------------------------------------------ 弹窗
func _cast_popup() -> void:
	var v: VBoxContainer = app._modal("放入伙伴", 700.0)
	v.add_child(UI.hint("每人最多放 3 只，可以放自己的，也可以放收藏来的。"))
	var res := UI.hint("")
	var add := func(title: String, spec: Dictionary, persona: String):
		res.text = "请稍等…"
		_call("/api/room/%s/cast" % code, POST, {"name": title, "spec": spec, "persona": persona}, func(ok: bool, _j: Dictionary, err: String):
			if not is_instance_valid(res):
				return
			if not ok:
				res.text = "✕ " + err
				return
			app.close_modal()
			_poll())
	for c in app.store.companions:
		var cc: Dictionary = c
		var r := UI.hb(10)
		r.add_child(UI.grow(UI.label(String(cc.spec.name), 24, UI.TXT, true)))
		r.add_child(UI.btn("放进去", func(): add.call(String(cc.spec.name), cc.spec, String(SOCIAL.card_of(cc).get("persona", ""))), "primary", 22))
		v.add_child(r)
	for m in app.store.collection:
		var mc: Dictionary = app.store.col_comp(String(m.get("mid", "")))
		if mc.is_empty():
			continue
		var r2 := UI.hb(10)
		r2.add_child(UI.grow(UI.label("%s　（收藏）" % String(m.get("title", "")), 24, UI.TXT, true)))
		r2.add_child(UI.btn("放进去", func(): add.call(String(mc.spec.name), mc.spec, String(SOCIAL.card_of(mc).get("persona", ""))), "ghost", 22))
		v.add_child(r2)
	v.add_child(res)
	if not actors.is_empty():
		v.add_child(UI.title("请走我放的伙伴", 24))
		for id in actors:
			if String(actors[id].uid) == String(app.store.srv_uid()) or bool(info.get("mine", false)):
				var rid := String(id)
				var r3 := UI.hb(10)
				r3.add_child(UI.grow(UI.label(String(actors[id].name) + "（" + String(actors[id].owner) + "）", 22, UI.TXT, true)))
				r3.add_child(UI.btn("请走", func():
					_call("/api/room/%s/uncast" % code, POST, {"id": rid}, func(_a: bool, _b: Dictionary, _d: String): _poll())
					app.close_modal(), "flat", 20))
				v.add_child(r3)

func _director_popup() -> void:
	var v: VBoxContainer = app._modal("导演：让它们演一幕", 700.0)
	v.add_child(UI.hint("选场景，再写个题目（可不填），伙伴们会按各自性格现场演。每次消耗你 1~2 点额度，两幕之间要隔 20 秒。"))
	var kind := ["chat"]
	v.add_child(UI.seg(KINDS, "chat", func(x): kind[0] = String(x)))
	var ft := UI.le("题目，例如：来一场生日派对 / 突然停电了 / 谁偷吃了蛋糕", "")
	v.add_child(ft)
	var res := UI.hint("")
	v.add_child(UI.btn("开演", func():
		res.text = "导演正在写剧本…"
		_call("/api/room/%s/scene" % code, POST, {"kind": kind[0], "topic": ft.text.strip_edges()}, func(ok: bool, _j: Dictionary, err: String):
			if not is_instance_valid(res):
				return
			if not ok:
				res.text = "✕ " + err
				return
			app.close_modal()
			_poll()), "primary", 24))
	v.add_child(res)

func _feed_popup() -> void:
	var v: VBoxContainer = app._modal("投喂 / 捣蛋", 700.0)
	if actors.is_empty():
		v.add_child(UI.hint("房间里还没有伙伴。"))
		return
	v.add_child(UI.hint("选一样东西，再点要给谁。大家都会看到它的反应。"))
	var item := [ITEMS[0]]
	var opts: Array = []
	for it in ITEMS:
		opts.append([it, it])
	v.add_child(UI.seg(opts, ITEMS[0], func(x): item[0] = String(x)))
	for id in actors:
		var aid := String(id)
		v.add_child(UI.btn("给 %s" % String(actors[id].name), func():
			_call("/api/room/%s/feed" % code, POST, {"id": aid, "item": item[0]}, func(_a: bool, _b: Dictionary, _d: String): _poll())
			app.close_modal(), "ghost", 22))

func _settings_popup() -> void:
	var v: VBoxContainer = app._modal("房间设置", 700.0)
	var host: bool = bool(info.get("mine", false))
	v.add_child(UI.label("房间号：%s　（发给朋友，他们在「房间」里输入就能加入）" % code, 22, UI.TXT, true))
	if host:
		v.add_child(UI.title("场景主题", 24))
		v.add_child(UI.seg(THEMES, String(info.get("theme", "sky")), func(x):
			_call("/api/room/%s/set" % code, POST, {"theme": String(x)}, func(_a: bool, _b: Dictionary, _d: String): _poll())))
		v.add_child(UI.title("没人指挥时", 24))
		v.add_child(UI.seg([[true, "伙伴们自己演（算房主额度，每天最多 20 幕）"], [false, "只在有人出题时演"]], bool(info.get("auto", true)), func(x):
			_call("/api/room/%s/set" % code, POST, {"auto": bool(x)}, func(_a: bool, _b: Dictionary, _d: String): _poll())))
		v.add_child(UI.seg([[false, "仅限房间号"], [true, "公开"]], bool(info.get("public", false)), func(x):
			_call("/api/room/%s/set" % code, POST, {"public": bool(x)}, func(_a: bool, _b: Dictionary, _d: String): _poll())))
	v.add_child(UI.btn("关闭房间" if host else "离开房间", func():
		_call("/api/room/%s/leave" % code, POST, {}, func(_a: bool, _b: Dictionary, _d: String):
			app.show_screen("rooms")), "ghost", 24))
