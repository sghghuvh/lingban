extends Node
# 灵伴：声音。
# 说话：系统语音（免费，用手机自带的 TTS）或 API 语音（更自然，需要 Key）。
# 听：录音后交给语音识别 API；没设置的话，可以用输入法自带的语音输入。
# 通话模式：说完自动听、听完自动回，像打电话一样。

signal speaking_changed(on: bool)
signal heard(text: String)
signal listen_state(state: String, info: String)  # idle / recording / processing / error

const SP = preload("res://scripts/species.gd")
const LLM = preload("res://scripts/llm.gd")

var app
var player: AudioStreamPlayer
var mic: AudioStreamPlayer
var rec_bus := -1
var rec: AudioEffectRecord
var recording := false
var call_mode := false
var _speaking := false
var _sys_speaking := false
var _api_wait := false
var _rec_t := 0.0
var _vad_heard := false
var _vad_loud := 0.0
var _vad_quiet := 0.0
var _resume_t := -1.0
var _perm_pending := false
var tts_ok := true

func setup(a) -> void:
	app = a
	player = AudioStreamPlayer.new()
	add_child(player)
	player.finished.connect(func(): _set_speaking(false))
	# 录音总线：Record -> Sink(静音)，这样录音不会从喇叭里放出来
	var sink := AudioServer.bus_count
	AudioServer.add_bus(sink)
	AudioServer.set_bus_name(sink, "LBSink")
	AudioServer.set_bus_mute(sink, true)
	rec_bus = AudioServer.bus_count
	AudioServer.add_bus(rec_bus)
	AudioServer.set_bus_name(rec_bus, "LBRecord")
	AudioServer.set_bus_send(rec_bus, "LBSink")
	rec = AudioEffectRecord.new()
	rec.format = AudioStreamWAV.FORMAT_16_BITS
	AudioServer.add_bus_effect(rec_bus, rec)
	mic = AudioStreamPlayer.new()
	mic.bus = "LBRecord"
	add_child(mic)
	if get_tree() != null and not get_tree().on_request_permissions_result.is_connected(_on_perm):
		get_tree().on_request_permissions_result.connect(_on_perm)
	tts_ok = DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH)
	_voices_cache = []
	if tts_ok:
		for v in DisplayServer.tts_get_voices():
			if typeof(v) == TYPE_DICTIONARY:
				_voices_cache.append(v)
		if _voices_cache.is_empty() and OS.get_name() != "Android":
			tts_ok = false

# ---------------------------------------------------------------- 说
static func clean_text(t: String) -> String:
	var s := t
	var re := RegEx.new()
	re.compile("[（(][^）)]{0,30}[）)]")
	s = re.sub(s, "", true)
	re.compile("[*_#`~>]+")
	s = re.sub(s, "", true)
	var out := ""
	for ch in s:
		var c := ch.unicode_at(0)
		if c >= 0x1F000 or (c >= 0x2600 and c < 0x2800 and not ch in "★☆♥♡♪♫"):
			continue
		out += ch
	return out.strip_edges().left(300)

var _voices_cache: Array = []
func sys_voices() -> Array:
	if not tts_ok:
		return []
	if _voices_cache.is_empty():
		for v in DisplayServer.tts_get_voices():
			if typeof(v) == TYPE_DICTIONARY:
				_voices_cache.append(v)
	return _voices_cache

func _pick_sys_voice() -> String:
	var want := String(app.store.settings.tts.get("sys_voice", ""))
	if want != "":
		return want
	var all := sys_voices()
	for v in all:
		if String(v.get("language", "")).to_lower().begins_with("zh"):
			return String(v.get("id", ""))
	return String(all[0].get("id", "")) if not all.is_empty() else ""

func api_voice_for(spec: Dictionary) -> String:
	var ts: Dictionary = app.store.settings.tts
	var v := String(ts.get("voice", "")).strip_edges()
	var own := String(spec.get("voice", {}).get("api_voice", "")).strip_edges()
	if own != "":
		v = own
	var model := String(ts.get("model", ""))
	var gender := String(spec.get("voice", {}).get("gender", "neutral"))
	var arch := SP.archetype(spec)
	if LLM.is_dashscope_tts(ts):
		var dm := LLM.ds_model(ts)
		var pitchv := float(spec.get("voice", {}).get("pitch", 1.0))
		if dm.begins_with("cosyvoice"):
			if v == "" or not (v.begins_with("long") or v.begins_with("loong")):
				var f := {"gentle": "longanrou_v3", "genki": "longanhuan", "tsundere": "longanling_v3", "cool": "longyingjing_v3", "shy": "longwan_v3", "playful": "longanqin_v3", "lazy": "longxing_v3", "wise": "longanya_v3"}
				var m := {"gentle": "longanyun_v3", "genki": "longanyang", "tsundere": "longzhe_v3", "cool": "longtian_v3", "shy": "longyingxun_v3", "playful": "longyichen_v3", "lazy": "longsanshu_v3", "wise": "longanzhi_v3"}
				if gender == "male":
					v = String(m.get(arch, "longanyang"))
				elif gender == "female":
					v = String(f.get(arch, "longanhuan"))
					if pitchv >= 1.5 and arch in ["playful", "genki", "shy"]:
						v = "longhuhu_v3"
				else:
					v = "longpaopao_v3" if pitchv >= 1.05 else "longanlang_v3"
			return v
		if v == "" or v.find(":") >= 0 or v.find("/") >= 0 or v == v.to_lower():
			var f2 := {"gentle": "Serena", "genki": "Cherry", "tsundere": "Vivian", "cool": "Maia", "shy": "Nini", "playful": "Chelsie", "lazy": "Stella", "wise": "Mia"}
			var m2 := {"gentle": "Kai", "genki": "Ethan", "tsundere": "Moon", "cool": "Neil", "shy": "Mochi", "playful": "Pip", "lazy": "Arthur", "wise": "Eldric Sage"}
			if gender == "male":
				v = String(m2.get(arch, "Ethan"))
			elif gender == "female":
				v = String(f2.get(arch, "Cherry"))
				if pitchv >= 1.5 and arch in ["playful", "genki"]:
					v = "Bunny"
			else:
				v = "Pip" if pitchv >= 1.05 else "Kai"
		return v
	if v == "":
		if String(ts.get("base", "")).find("openai") >= 0:
			v = {"female": "nova", "male": "onyx"}.get(gender, "alloy")
			if gender == "female" and arch in ["cool", "wise"]:
				v = "shimmer"
		else:
			var name := "bella"
			if gender == "male":
				name = {"cool": "charles", "wise": "david", "gentle": "benjamin"}.get(arch, "alex")
			elif gender == "female":
				name = {"gentle": "claire", "shy": "diana", "lazy": "diana", "cool": "anna", "wise": "anna"}.get(arch, "bella")
			else:
				name = "bella" if float(spec.get("voice", {}).get("pitch", 1.0)) >= 1.05 else "alex"
			v = name
	if model.find("CosyVoice") >= 0 and v.find(":") < 0 and not v.begins_with("speech:"):
		v = model + ":" + v
	return v

func speak(text: String, spec: Dictionary) -> void:
	var t := clean_text(text)
	if t == "" or t == "……":
		return
	var mode := String(app.store.settings.tts.get("mode", "system"))
	if mode == "off":
		return
	stop_speaking()
	if call_mode and recording:
		_stop_record(false)
	var vol := clampi(int(app.store.settings.tts.get("volume", 80)), 0, 100)
	var vo: Dictionary = spec.get("voice", {})
	if mode == "api" and app.llm.has_tts_api():
		_api_wait = true
		_set_speaking(true)
		app.llm.speech(t, api_voice_for(spec), float(vo.get("rate", 1.0)), func(ok: bool, data: PackedByteArray, err: String):
			_api_wait = false
			if not ok or data.size() < 100:
				app.notify_voice_error("语音合成失败：%s（改用系统语音）" % err)
				_speak_sys(t, vo, vol)
				return
			var st = _make_stream(data)
			if st == null:
				app.notify_voice_error("语音合成失败：声音格式看不懂（改用系统语音）")
				_speak_sys(t, vo, vol)
				return
			player.stream = st
			player.volume_db = linear_to_db(maxf(vol / 100.0, 0.01))
			player.play()
			_set_speaking(true))
		return
	_speak_sys(t, vo, vol)

# 把下载到的声音变成可播放的流：WAV（阿里云）或 MP3（硅基流动等）
func _make_stream(data: PackedByteArray):
	if data.size() > 44 and data.slice(0, 4).get_string_from_ascii() == "RIFF":
		var pos := 12
		var rate := 24000
		var chans := 1
		var bits := 16
		while pos + 8 <= data.size():
			var id := data.slice(pos, pos + 4).get_string_from_ascii()
			var sz := data.decode_u32(pos + 4)
			if id == "fmt ":
				chans = data.decode_u16(pos + 10)
				rate = data.decode_u32(pos + 12)
				bits = data.decode_u16(pos + 22)
			elif id == "data":
				var end := mini(pos + 8 + sz, data.size())
				if sz == 0 or sz == 0xFFFFFFFF:
					end = data.size()
				var w := AudioStreamWAV.new()
				w.format = AudioStreamWAV.FORMAT_16_BITS if bits == 16 else AudioStreamWAV.FORMAT_8_BITS
				w.mix_rate = rate
				w.stereo = chans == 2
				w.data = data.slice(pos + 8, end)
				return w
			pos += 8 + sz + (sz % 2)
		return null
	var st := AudioStreamMP3.new()
	st.data = data
	return st

func _speak_sys(t: String, vo: Dictionary, vol: int) -> void:
	if not tts_ok:
		_fake_speak(t)
		return
	var vid := _pick_sys_voice()
	if vid == "":
		_fake_speak(t)
		return
	DisplayServer.tts_speak(t, vid, vol, clampf(float(vo.get("pitch", 1.0)), 0.5, 2.0), clampf(float(vo.get("rate", 1.0)), 0.6, 1.8), 0, true)
	_sys_speaking = true
	_set_speaking(true)

var _fake_until := 0.0
func _fake_speak(t: String) -> void:
	# 没有语音引擎时，只做嘴型动画
	_fake_until = Time.get_ticks_msec() / 1000.0 + clampf(t.length() * 0.18, 0.8, 8.0)
	_set_speaking(true)

func stop_speaking() -> void:
	if tts_ok and _sys_speaking:
		DisplayServer.tts_stop()
	_sys_speaking = false
	_fake_until = 0.0
	if player.playing:
		player.stop()
	_set_speaking(false)

func is_speaking() -> bool:
	return _speaking

func _set_speaking(on: bool) -> void:
	if on == _speaking:
		return
	_speaking = on
	speaking_changed.emit(on)
	if not on and call_mode:
		_resume_t = 0.5

# ---------------------------------------------------------------- 听
func can_listen() -> bool:
	return app.llm.has_stt()

func start_listen() -> void:
	if recording:
		return
	if not can_listen():
		listen_state.emit("error", "还没设置语音识别。可以用输入法键盘上的话筒说话，或去设置里填写语音识别 API。")
		return
	if OS.get_name() == "Android":
		if not OS.request_permission("RECORD_AUDIO"):
			_perm_pending = true
			listen_state.emit("error", "需要麦克风权限，请在弹窗里允许后再点一次。")
			return
	_begin_record()

func _on_perm(permission: String, granted: bool) -> void:
	if not _perm_pending:
		return
	if permission.find("RECORD_AUDIO") >= 0:
		_perm_pending = false
		if granted:
			_begin_record()
		else:
			listen_state.emit("error", "没有麦克风权限，没法听你说话。")
			call_mode = false

func _begin_record() -> void:
	stop_speaking()
	if not mic.playing:
		mic.stream = AudioStreamMicrophone.new()
		mic.play()
	rec.set_recording_active(true)
	recording = true
	_rec_t = 0.0
	_vad_heard = false
	_vad_loud = 0.0
	_vad_quiet = 0.0
	listen_state.emit("recording", "")

func stop_listen(send := true) -> void:
	_stop_record(send)

func _stop_record(send: bool) -> void:
	if not recording:
		return
	recording = false
	rec.set_recording_active(false)
	var wav: AudioStreamWAV = rec.get_recording()
	if not call_mode:
		mic.stop()
	if not send or wav == null or _rec_t < 0.4:
		listen_state.emit("idle", "")
		return
	if _peak(wav) < 250:
		listen_state.emit("error", "没录到声音：请在手机设置里允许本 App 使用麦克风；如果刚刚才允许，请把 App 完全关掉再打开一次。")
		if call_mode:
			_resume_t = 2.0
		return
	var bytes := to_wav16k(wav)
	if bytes.size() < 3200:
		listen_state.emit("idle", "")
		return
	listen_state.emit("processing", "")
	app.llm.transcribe(bytes, func(ok: bool, text: String, err: String):
		if not ok:
			listen_state.emit("error", "语音识别失败：" + err)
			if call_mode:
				_resume_t = 1.5
			return
		listen_state.emit("idle", "")
		if text.strip_edges() == "":
			if call_mode:
				_resume_t = 0.3
			return
		heard.emit(text))

func set_call_mode(on: bool) -> void:
	call_mode = on
	if on:
		start_listen()
	else:
		if recording:
			_stop_record(false)
		mic.stop()
		listen_state.emit("idle", "")

func _process(delta: float) -> void:
	if _sys_speaking and tts_ok and not DisplayServer.tts_is_speaking():
		_sys_speaking = false
		_set_speaking(false)
	if _fake_until > 0.0 and Time.get_ticks_msec() / 1000.0 > _fake_until:
		_fake_until = 0.0
		_set_speaking(false)
	if _resume_t >= 0.0:
		_resume_t -= delta
		if _resume_t < 0.0 and call_mode and not recording and not _speaking:
			start_listen()
	if recording:
		_rec_t += delta
		if _rec_t > 25.0:
			_stop_record(true)
			return
		if call_mode:
			var sens := float(app.store.settings.behavior.get("vad", 0.5))
			var thr := lerpf(-28.0, -46.0, sens)
			var db := AudioServer.get_bus_peak_volume_left_db(rec_bus, 0)
			if db > thr:
				_vad_loud += delta
				_vad_quiet = 0.0
				if _vad_loud > 0.18:
					_vad_heard = true
			else:
				_vad_quiet += delta
				_vad_loud = maxf(_vad_loud - delta, 0.0)
			if _vad_heard and _vad_quiet > 1.1:
				_stop_record(true)
			elif not _vad_heard and _rec_t > 12.0:
				# 一直没人说话：重新开始录，避免文件太大
				rec.set_recording_active(false)
				rec.set_recording_active(true)
				_rec_t = 0.0

# 录音的最大音量（抽样看，快）：几乎是 0 说明麦克风没声音
static func _peak(w: AudioStreamWAV) -> int:
	var d := w.data
	var mx := 0
	var i := 0
	while i + 1 < d.size():
		var v := absi(d.decode_s16(i))
		if v > mx:
			mx = v
		i += 32
	return mx

# 把录音转成 16kHz 单声道 16 位 WAV（体积小，识别快）
static func to_wav16k(w: AudioStreamWAV) -> PackedByteArray:
	var data := w.data
	var stereo := w.stereo
	var src_rate := float(w.mix_rate)
	var ch := 2 if stereo else 1
	var frames := data.size() / (2 * ch)
	var ratio := src_rate / 16000.0
	var out_n := int(frames / ratio)
	var pcm := PackedByteArray()
	pcm.resize(out_n * 2)
	for i in out_n:
		var fi := int(i * ratio)
		var o := fi * 2 * ch
		if o + 1 >= data.size():
			break
		var l := data.decode_s16(o)
		var v := l
		if stereo and o + 3 < data.size():
			v = (l + data.decode_s16(o + 2)) / 2
		pcm.encode_s16(i * 2, clampi(v, -32768, 32767))
	var hdr := PackedByteArray()
	hdr.resize(44)
	hdr.encode_u32(0, 0x46464952)
	hdr.encode_u32(4, 36 + pcm.size())
	hdr.encode_u32(8, 0x45564157)
	hdr.encode_u32(12, 0x20746d66)
	hdr.encode_u32(16, 16)
	hdr.encode_u16(20, 1)
	hdr.encode_u16(22, 1)
	hdr.encode_u32(24, 16000)
	hdr.encode_u32(28, 32000)
	hdr.encode_u16(32, 2)
	hdr.encode_u16(34, 16)
	hdr.encode_u32(36, 0x61746164)
	hdr.encode_u32(40, pcm.size())
	hdr.append_array(pcm)
	return hdr
