extends RefCounted
# 灵伴：精致立绘。把 AI 画的动漫立绘（纯绿背景）抠成透明图，并读成贴图给 creature.gd 使用。

static func load_for(comp: Dictionary) -> Dictionary:
	var st = comp.get("state", {})
	if typeof(st) != TYPE_DICTIONARY:
		return {}
	var a = st.get("art", {})
	if typeof(a) != TYPE_DICTIONARY or String(a.get("base", "")) == "":
		return {}
	var base := _tex(String(a.base))
	if base == null:
		return {}
	var tex := {}
	var em = a.get("emo", {})
	if typeof(em) == TYPE_DICTIONARY:
		for k in em:
			var t := _tex(String(em[k]))
			if t != null:
				tex[String(k)] = t
	return {"base": base, "tex": tex}

static func _tex(p: String) -> ImageTexture:
	if p == "" or not FileAccess.file_exists(p):
		return null
	var im := Image.load_from_file(p)
	if im == null or im.is_empty():
		return null
	im.convert(Image.FORMAT_RGBA8)
	im.generate_mipmaps()
	return ImageTexture.create_from_image(im)

# 抠图：背景按四个角的颜色判断。绿幕用“绿色突出程度”，其他纯色用颜色距离。可在线程里调用。
static func chroma(src: Image, w: int, h: int) -> Image:
	var img: Image = src.duplicate()
	img.convert(Image.FORMAT_RGBA8)
	if img.get_width() != w or img.get_height() != h:
		img.resize(w, h, Image.INTERPOLATE_LANCZOS)
	var d: PackedByteArray = img.get_data()
	var sr := 0
	var sg := 0
	var sb := 0
	var cnt := 0
	for cx in [2, w - 12]:
		for cy in [2, h - 12]:
			for dx in range(0, 8, 2):
				for dy in range(0, 8, 2):
					var o0: int = ((cy + dy) * w + cx + dx) * 4
					sr += d[o0]
					sg += d[o0 + 1]
					sb += d[o0 + 2]
					cnt += 1
	var br := sr / cnt
	var bg := sg / cnt
	var bb := sb / cnt
	var green_bg: bool = (bg - maxi(br, bb)) > 40
	var n := w * h
	for i in n:
		var o := i * 4
		var r: int = d[o]
		var g: int = d[o + 1]
		var b: int = d[o + 2]
		var a := 255
		if green_bg:
			var m := maxi(r, b)
			var dd := g - m
			if dd > 70:
				a = 0
			elif dd > 22:
				a = int(255.0 * float(70 - dd) / 48.0)
				d[o + 1] = m
			elif dd > 6:
				d[o + 1] = m + 3
		else:
			var dist := absi(r - br) + absi(g - bg) + absi(b - bb)
			if dist < 36:
				a = 0
			elif dist < 90:
				a = int(255.0 * float(dist - 36) / 54.0)
		if a < 18:
			a = 0
		d[o + 3] = a
	return Image.create_from_data(w, h, false, Image.FORMAT_RGBA8, d)
