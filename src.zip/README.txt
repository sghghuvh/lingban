灵伴 LingBan（悬浮版源码）
上传到 GitHub 公开仓库 → Actions → build-apk → Run workflow → 下载 LingBan-apk
